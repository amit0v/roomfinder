import { Task, WebScraperConfig } from "@shared/schema";
import fetch from "node-fetch";
import * as cheerio from "cheerio";

export class WebScraper {
  private task: Task;
  private config: WebScraperConfig;
  private onProgress: (progress: number) => void;
  private isStopped: boolean = false;
  
  constructor(task: Task, onProgress: (progress: number) => void) {
    this.task = task;
    this.config = task.configuration as WebScraperConfig;
    this.onProgress = onProgress;
  }
  
  async start(): Promise<{ success: boolean; data?: any[] }> {
    try {
      if (!this.config.url) {
        throw new Error("URL is required");
      }
      
      const data = await this.scrape(this.config.url);
      return { success: true, data };
    } catch (error) {
      console.error("Web scraper error:", error);
      return { success: false };
    }
  }
  
  async stop(): Promise<void> {
    this.isStopped = true;
  }
  
  private async scrape(url: string): Promise<any[]> {
    // Report starting progress
    this.onProgress(0);
    
    if (this.isStopped) {
      return [];
    }
    
    // Fetch the page content
    const response = await fetch(url);
    const html = await response.text();
    
    // Load HTML into cheerio
    const $ = cheerio.load(html);
    
    // Extract data based on selectors
    const results: any[] = [];
    const items = this.config.followPagination 
      ? $(this.findCommonParentSelector() || "body") 
      : $("body");
    
    let itemCount = 0;
    let totalItems = items.length || 1;
    
    items.each((_, element) => {
      if (this.isStopped) {
        return false; // Stop scraping
      }
      
      const item: Record<string, any> = {};
      
      // Process each field
      this.config.fields.forEach(field => {
        const fieldElement = $(element).find(field.selector);
        item[field.name] = fieldElement.text().trim();
        
        // If it's a number, try to parse it
        if (!isNaN(Number(item[field.name]))) {
          const num = parseFloat(item[field.name]);
          if (!isNaN(num)) {
            item[field.name] = num;
          }
        }
      });
      
      // Add the item if it has any non-empty values
      if (Object.values(item).some(v => v !== "")) {
        results.push(item);
      }
      
      // Update progress
      itemCount++;
      this.onProgress(Math.floor((itemCount / totalItems) * 100));
    });
    
    // Handle pagination if enabled
    if (this.config.followPagination && !this.isStopped) {
      const nextPageUrl = this.findNextPageUrl($, url);
      if (nextPageUrl && results.length < 1000) { // Limit to 1000 items for safety
        const nextPageResults = await this.scrape(nextPageUrl);
        results.push(...nextPageResults);
      }
    }
    
    // Final progress update
    this.onProgress(100);
    
    return results;
  }
  
  private findCommonParentSelector(): string | null {
    // This method attempts to find a common parent selector for all fields
    // In a real implementation, this would use more sophisticated logic
    
    if (this.config.fields.length === 0) {
      return null;
    }
    
    // Simple approach: use the first field's selector and try to find a parent
    const firstSelector = this.config.fields[0].selector;
    
    // If selector contains a class, use it as a potential container
    const classMatch = firstSelector.match(/\.([\w-]+)/);
    if (classMatch) {
      return `.${classMatch[1]}`;
    }
    
    // If selector contains an ID, use its parent
    const idMatch = firstSelector.match(/#([\w-]+)/);
    if (idMatch) {
      return `#${idMatch[1]} > *`;
    }
    
    // Fallback to common container elements
    return "div.item, div.product, li.item, tr";
  }
  
  private findNextPageUrl($: cheerio.CheerioAPI, currentUrl: string): string | null {
    // Common patterns for pagination links
    const nextLinkSelectors = [
      "a.next", 
      "a[rel=next]", 
      ".pagination a:contains('Next')", 
      ".pagination a:contains('»')",
      "a[aria-label='Next page']",
      ".next a"
    ];
    
    // Try each selector
    for (const selector of nextLinkSelectors) {
      const nextLink = $(selector).first();
      if (nextLink.length) {
        const href = nextLink.attr("href");
        if (href) {
          // Handle relative URLs
          if (href.startsWith("/")) {
            const urlObj = new URL(currentUrl);
            return `${urlObj.protocol}//${urlObj.host}${href}`;
          } else if (!href.startsWith("http")) {
            return new URL(href, currentUrl).toString();
          }
          return href;
        }
      }
    }
    
    return null;
  }
}
