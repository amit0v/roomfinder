import { Link, useLocation } from "wouter";

export default function MobileNav() {
  const [location] = useLocation();
  
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-2 flex items-center justify-around z-20">
      <Link href="/">
        <a className="flex flex-col items-center text-primary">
          <i className="ri-dashboard-line text-xl"></i>
          <span className="text-xs mt-1">Dashboard</span>
        </a>
      </Link>
      
      <Link href="/history">
        <a className="flex flex-col items-center text-gray-500 dark:text-gray-400">
          <i className="ri-history-line text-xl"></i>
          <span className="text-xs mt-1">History</span>
        </a>
      </Link>
      
      <button className="flex flex-col items-center relative">
        <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center text-white -mt-5">
          <i className="ri-add-line text-xl"></i>
        </div>
      </button>
      
      <Link href="/api-keys">
        <a className="flex flex-col items-center text-gray-500 dark:text-gray-400">
          <i className="ri-key-2-line text-xl"></i>
          <span className="text-xs mt-1">API Keys</span>
        </a>
      </Link>
      
      <Link href="/settings">
        <a className="flex flex-col items-center text-gray-500 dark:text-gray-400">
          <i className="ri-settings-4-line text-xl"></i>
          <span className="text-xs mt-1">Settings</span>
        </a>
      </Link>
    </div>
  );
}
