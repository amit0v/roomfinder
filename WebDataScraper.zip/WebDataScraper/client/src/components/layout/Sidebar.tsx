import { Link, useLocation } from "wouter";

interface SidebarProps {
  isOpen: boolean;
  closeSidebar: () => void;
}

export default function Sidebar({ isOpen, closeSidebar }: SidebarProps) {
  const [location] = useLocation();
  
  if (!isOpen) return null;
  
  return (
    <aside className="lg:block w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 fixed lg:relative inset-y-0 left-0 z-30">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-2">
          <div className="text-primary text-2xl">
            <i className="ri-database-2-line"></i>
          </div>
          <h1 className="text-lg font-bold">DataHarvest</h1>
        </div>
        <button 
          onClick={closeSidebar}
          className="lg:hidden text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
        >
          <i className="ri-close-line text-xl"></i>
        </button>
      </div>
      
      <div className="p-4">
        <div className="mb-4">
          <div className="flex items-center space-x-3 mb-3">
            <div className="h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary">
              <i className="ri-user-line"></i>
            </div>
            <div>
              <p className="font-medium">Alex Developer</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">alex@example.com</p>
            </div>
          </div>
        </div>
        
        <div className="space-y-1">
          <Link href="/">
            <a className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg ${location === '/' ? 'bg-primary-50 dark:bg-primary-900/20 text-primary font-medium' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
              <i className="ri-dashboard-line"></i>
              <span>Dashboard</span>
            </a>
          </Link>
          
          <Link href="/history">
            <a className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg ${location === '/history' ? 'bg-primary-50 dark:bg-primary-900/20 text-primary font-medium' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
              <i className="ri-history-line"></i>
              <span>Scrape History</span>
            </a>
          </Link>
          
          <Link href="/api-keys">
            <a className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg ${location === '/api-keys' ? 'bg-primary-50 dark:bg-primary-900/20 text-primary font-medium' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
              <i className="ri-key-2-line"></i>
              <span>API Keys</span>
            </a>
          </Link>
          
          <Link href="/settings">
            <a className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg ${location === '/settings' ? 'bg-primary-50 dark:bg-primary-900/20 text-primary font-medium' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
              <i className="ri-settings-4-line"></i>
              <span>Settings</span>
            </a>
          </Link>
        </div>
        
        <div className="mt-8">
          <h2 className="text-xs font-medium uppercase text-gray-500 dark:text-gray-400 mb-2">Data Sources</h2>
          <div className="space-y-1">
            <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
              <i className="ri-global-line"></i>
              <span>Web Scraper</span>
            </button>
            <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
              <i className="ri-twitter-x-line"></i>
              <span>Twitter/X</span>
            </button>
            <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
              <i className="ri-linkedin-box-line"></i>
              <span>LinkedIn</span>
            </button>
            <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
              <i className="ri-instagram-line"></i>
              <span>Instagram</span>
            </button>
          </div>
        </div>
      </div>
      
      <div className="mt-auto p-4 border-t border-gray-200 dark:border-gray-700">
        <button className="w-full flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
          <i className="ri-logout-box-line"></i>
          <span>Log Out</span>
        </button>
      </div>
    </aside>
  );
}
