import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  HomeIcon,
  SearchIcon,
  UserIcon,
  MessageSquareIcon,
  HeartIcon,
  LogOutIcon,
  MenuIcon,
  ChevronDownIcon,
  SettingsIcon,
  PlusIcon,
  ShieldCheckIcon,
  BuildingIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [location, navigate] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);

  // Fetch user data
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/user/profile'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/user/profile');
        if (!res.ok) throw new Error('Failed to fetch user profile');
        return res.json();
      } catch (error) {
        // Not logged in
        return null;
      }
    }
  });

  // Check for unread messages
  const { data: chatRooms = [] } = useQuery({
    queryKey: ['/api/chats'],
    queryFn: async () => {
      if (!user) return [];
      try {
        const res = await fetch('/api/chats');
        if (!res.ok) throw new Error('Failed to fetch chats');
        return res.json();
      } catch (error) {
        return [];
      }
    },
    enabled: !!user
  });

  // Check for scroll position to add shadow to navbar
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Check if there are any unread messages
  const hasUnreadMessages = chatRooms.some((room: any) => 
    room.messages && room.messages.some((msg: any) => 
      !msg.isRead && msg.senderId !== user?.id
    )
  );

  // Logout function
  const handleLogout = async () => {
    try {
      const res = await fetch('/api/auth/logout', {
        method: 'POST',
      });
      if (res.ok) {
        navigate('/');
        window.location.reload();
      }
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // Navigation items for the header
  const navItems = [
    {
      name: 'Home',
      href: '/',
      icon: <HomeIcon className="h-4 w-4 mr-2" />,
    },
    {
      name: 'Properties',
      href: '/properties',
      icon: <SearchIcon className="h-4 w-4 mr-2" />,
    },
    ...(user ? [
      {
        name: 'Messages',
        href: '/chat',
        icon: <MessageSquareIcon className="h-4 w-4 mr-2" />,
        badge: hasUnreadMessages,
      },
      {
        name: 'Favorites',
        href: '/favorites',
        icon: <HeartIcon className="h-4 w-4 mr-2" />,
      },
    ] : []),
  ];

  // Owner-specific navigation items
  const ownerNavItems = [
    {
      name: 'My Properties',
      href: '/owner/dashboard',
      icon: <BuildingIcon className="h-4 w-4 mr-2" />,
    },
    {
      name: 'Add Property',
      href: '/owner/property/add',
      icon: <PlusIcon className="h-4 w-4 mr-2" />,
    },
    {
      name: 'Verification',
      href: '/owner/verification',
      icon: <ShieldCheckIcon className="h-4 w-4 mr-2" />,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header 
        className={`bg-white/95 backdrop-blur-sm border-b sticky top-0 z-20 transition-all duration-200 ${
          isScrolled ? 'shadow-md' : ''
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white h-8 w-8 rounded-lg flex items-center justify-center mr-3">
                <HomeIcon className="h-5 w-5" />
              </div>
              <span className="font-bold text-xl bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">RoomFinder</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-2">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <Button 
                    variant={location === item.href ? "default" : "ghost"} 
                    className={`relative transition-all duration-200 rounded-lg ${
                      location === item.href 
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md hover:shadow-lg' 
                        : 'hover:text-indigo-600'
                    }`}
                  >
                    {item.icon}
                    {item.name}
                    {item.badge && (
                      <Badge 
                        variant="destructive" 
                        className="absolute -top-1 -right-1 h-2 w-2 p-0 animate-pulse"
                      />
                    )}
                  </Button>
                </Link>
              ))}
              
              {/* Owner-specific Navigation */}
              {user && user.userType === 'owner' && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="border-indigo-200 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-300 transition-all duration-200"
                    >
                      <BuildingIcon className="h-4 w-4 mr-2" />
                      Property Owner
                      <ChevronDownIcon className="h-4 w-4 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 p-1 border-indigo-100 shadow-lg rounded-lg">
                    {ownerNavItems.map((item) => (
                      <DropdownMenuItem 
                        key={item.href} 
                        onClick={() => navigate(item.href)}
                        className="rounded-md hover:bg-indigo-50 py-2"
                      >
                        {item.icon}
                        {item.name}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </nav>

            {/* Authentication / User Menu */}
            <div className="flex items-center">
              {isLoadingUser ? (
                <Button variant="ghost" disabled className="opacity-50">
                  <span className="animate-pulse">Loading...</span>
                </Button>
              ) : user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="ghost" 
                      className="flex items-center gap-2 hover:bg-indigo-50"
                    >
                      <Avatar className="h-8 w-8 border-2 border-indigo-100">
                        <AvatarImage src={user.profileImage} />
                        <AvatarFallback className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-medium">
                          {user.fullName?.charAt(0) || user.username?.charAt(0) || "U"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="hidden sm:block text-left">
                        <p className="text-sm font-medium line-clamp-1">{user.fullName || user.username}</p>
                        <p className="text-xs text-gray-500">{user.userType === 'owner' ? 'Property Owner' : 'Student'}</p>
                      </div>
                      <ChevronDownIcon className="h-4 w-4 ml-1 text-gray-400" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-64 p-1.5 border-indigo-100 shadow-lg rounded-lg">
                    <div className="px-3 py-2 border-b mb-1">
                      <p className="text-sm font-medium">Signed in as</p>
                      <p className="text-indigo-600 font-semibold">{user.username}</p>
                    </div>
                    <DropdownMenuItem 
                      onClick={() => navigate('/profile')}
                      className="rounded-md hover:bg-indigo-50 py-2"
                    >
                      <UserIcon className="h-4 w-4 mr-2 text-indigo-500" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => navigate('/chat')}
                      className="rounded-md hover:bg-indigo-50 py-2"
                    >
                      <MessageSquareIcon className="h-4 w-4 mr-2 text-indigo-500" />
                      <span>Messages</span>
                      {hasUnreadMessages && (
                        <Badge 
                          variant="destructive" 
                          className="ml-auto"
                        >
                          New
                        </Badge>
                      )}
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => navigate('/favorites')}
                      className="rounded-md hover:bg-indigo-50 py-2"
                    >
                      <HeartIcon className="h-4 w-4 mr-2 text-indigo-500" />
                      <span>Favorites</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => navigate('/settings')}
                      className="rounded-md hover:bg-indigo-50 py-2"
                    >
                      <SettingsIcon className="h-4 w-4 mr-2 text-indigo-500" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                    <div className="px-1 py-2 mt-1 border-t">
                      <DropdownMenuItem 
                        onClick={handleLogout}
                        className="rounded-md text-red-600 hover:bg-red-50 py-2"
                      >
                        <LogOutIcon className="h-4 w-4 mr-2" />
                        <span>Log out</span>
                      </DropdownMenuItem>
                    </div>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="flex items-center space-x-3">
                  <Link href="/login">
                    <Button variant="outline" className="border-indigo-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all duration-200">
                      Login
                    </Button>
                  </Link>
                  <Link href="/register">
                    <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-md transition-all duration-200">
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}

              {/* Mobile Menu Button */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="ml-2 md:hidden">
                    <MenuIcon className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <SheetHeader className="mb-4">
                    <SheetTitle>Menu</SheetTitle>
                    <SheetDescription>
                      Navigate to different sections of the application
                    </SheetDescription>
                  </SheetHeader>
                  <ScrollArea className="h-[calc(100vh-120px)]">
                    <div className="flex flex-col space-y-1 py-2">
                      {navItems.map((item) => (
                        <SheetClose asChild key={item.href}>
                          <Link href={item.href}>
                            <Button 
                              variant={location === item.href ? "default" : "ghost"} 
                              className="justify-start w-full"
                            >
                              {item.icon}
                              {item.name}
                              {item.badge && (
                                <Badge 
                                  variant="destructive" 
                                  className="ml-auto"
                                >
                                  New
                                </Badge>
                              )}
                            </Button>
                          </Link>
                        </SheetClose>
                      ))}

                      {/* Owner-specific Mobile Navigation */}
                      {user && user.userType === 'owner' && (
                        <>
                          <div className="mt-2 mb-1 px-2 text-sm font-medium text-gray-500">
                            Property Owner
                          </div>
                          {ownerNavItems.map((item) => (
                            <SheetClose asChild key={item.href}>
                              <Link href={item.href}>
                                <Button 
                                  variant={location === item.href ? "default" : "ghost"} 
                                  className="justify-start w-full"
                                >
                                  {item.icon}
                                  {item.name}
                                </Button>
                              </Link>
                            </SheetClose>
                          ))}
                        </>
                      )}

                      {/* User options in mobile menu */}
                      {user && (
                        <>
                          <div className="mt-2 mb-1 px-2 text-sm font-medium text-gray-500">
                            User
                          </div>
                          <SheetClose asChild>
                            <Link href="/profile">
                              <Button 
                                variant={location === '/profile' ? "default" : "ghost"} 
                                className="justify-start w-full"
                              >
                                <UserIcon className="h-4 w-4 mr-2" />
                                Profile
                              </Button>
                            </Link>
                          </SheetClose>
                          <SheetClose asChild>
                            <Link href="/settings">
                              <Button 
                                variant={location === '/settings' ? "default" : "ghost"} 
                                className="justify-start w-full"
                              >
                                <SettingsIcon className="h-4 w-4 mr-2" />
                                Settings
                              </Button>
                            </Link>
                          </SheetClose>
                          <Button 
                            variant="ghost" 
                            className="justify-start w-full mt-2"
                            onClick={handleLogout}
                          >
                            <LogOutIcon className="h-4 w-4 mr-2" />
                            Log out
                          </Button>
                        </>
                      )}

                      {/* Auth links in mobile menu for logged out users */}
                      {!user && !isLoadingUser && (
                        <div className="mt-4 space-y-2 pt-4 border-t">
                          <SheetClose asChild>
                            <Link href="/login">
                              <Button className="w-full">Login</Button>
                            </Link>
                          </SheetClose>
                          <SheetClose asChild>
                            <Link href="/register">
                              <Button variant="outline" className="w-full">Sign Up</Button>
                            </Link>
                          </SheetClose>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 bg-gray-50">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-bold mb-4">RoomFinder</h3>
              <p className="text-gray-300">Find your perfect student accommodation with RoomFinder.</p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-300 hover:text-white">Home</Link></li>
                <li><Link href="/properties" className="text-gray-300 hover:text-white">Browse Properties</Link></li>
                <li><Link href="/login" className="text-gray-300 hover:text-white">Login</Link></li>
                <li><Link href="/register" className="text-gray-300 hover:text-white">Sign Up</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Contact</h3>
              <p className="text-gray-300">Email: info@roomfinder.com</p>
              <p className="text-gray-300">Phone: (123) 456-7890</p>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-300">
            <p>© {new Date().getFullYear()} RoomFinder. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}