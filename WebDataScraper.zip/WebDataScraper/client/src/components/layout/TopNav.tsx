import { useTheme } from "@/components/ThemeProvider";

interface TopNavProps {
  toggleSidebar: () => void;
}

export default function TopNav({ toggleSidebar }: TopNavProps) {
  const { theme, setTheme } = useTheme();
  
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };
  
  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center lg:w-64">
          <button 
            onClick={toggleSidebar}
            className="lg:hidden mr-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <i className="ri-menu-line text-xl"></i>
          </button>
          <div className="lg:hidden flex items-center space-x-2">
            <div className="text-primary text-xl">
              <i className="ri-database-2-line"></i>
            </div>
            <h1 className="text-lg font-bold">DataHarvest</h1>
          </div>
        </div>
        
        <div className="flex-1 max-w-3xl mx-auto px-4">
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search scraped data or create new task..." 
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
            <div className="absolute left-3 top-2.5 text-gray-400">
              <i className="ri-search-line"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
            <i className="ri-notification-3-line text-xl"></i>
            <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-primary"></span>
          </button>
          
          <div className="w-0.5 h-6 bg-gray-200 dark:bg-gray-700"></div>
          
          <button 
            onClick={toggleTheme}
            className="flex items-center space-x-1 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
          >
            <i className={`${theme === 'dark' ? 'ri-sun-line' : 'ri-moon-line'} text-lg`}></i>
          </button>
        </div>
      </div>
    </header>
  );
}
