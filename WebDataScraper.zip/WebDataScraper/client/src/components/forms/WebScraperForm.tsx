import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { WebScraperConfig, TaskFrequency, DataFormat, ScraperField } from "@/types";

interface WebScraperFormProps {
  onChange: (data: Partial<WebScraperConfig>, isValid: boolean) => void;
}

export default function WebScraperForm({ onChange }: WebScraperFormProps) {
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [frequency, setFrequency] = useState<TaskFrequency>("once");
  const [fields, setFields] = useState<ScraperField[]>([
    { name: "", selector: "" }
  ]);
  const [useProxy, setUseProxy] = useState(false);
  const [executeJavascript, setExecuteJavascript] = useState(false);
  const [followPagination, setFollowPagination] = useState(false);
  const [exportFormat, setExportFormat] = useState<DataFormat>("json");
  
  useEffect(() => {
    const formData = {
      name,
      url,
      frequency,
      fields,
      useProxy,
      executeJavascript,
      followPagination,
      exportFormat
    };
    
    const isValid = 
      name.trim() !== "" && 
      isValidUrl(url) && 
      fields.length > 0 && 
      fields.every(field => field.name.trim() !== "" && field.selector.trim() !== "");
    
    onChange(formData, isValid);
  }, [name, url, frequency, fields, useProxy, executeJavascript, followPagination, exportFormat]);
  
  const isValidUrl = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };
  
  const handleAddField = () => {
    setFields([...fields, { name: "", selector: "" }]);
  };
  
  const handleRemoveField = (index: number) => {
    setFields(fields.filter((_, i) => i !== index));
  };
  
  const handleFieldChange = (index: number, key: keyof ScraperField, value: string) => {
    const newFields = [...fields];
    newFields[index] = { ...newFields[index], [key]: value };
    setFields(newFields);
  };
  
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Scraper Name</Label>
        <Input 
          id="name" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter a name for this scraper"
          className="mt-1" 
        />
      </div>
      
      <div>
        <Label htmlFor="url">Target URL</Label>
        <Input 
          id="url" 
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://example.com/data"
          className="mt-1" 
        />
      </div>
      
      <div>
        <Label htmlFor="frequency">Frequency</Label>
        <Select value={frequency} onValueChange={(value: TaskFrequency) => setFrequency(value)}>
          <SelectTrigger id="frequency" className="mt-1">
            <SelectValue placeholder="Select frequency" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="once">Once</SelectItem>
            <SelectItem value="hourly">Hourly</SelectItem>
            <SelectItem value="daily">Daily</SelectItem>
            <SelectItem value="weekly">Weekly</SelectItem>
            <SelectItem value="monthly">Monthly</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label>CSS Selectors</Label>
        <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-4 mt-1 overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-medium">Data Fields</h4>
            <Button 
              size="sm" 
              variant="default"
              onClick={handleAddField}
              className="h-7 px-2 text-xs"
            >
              + Add Field
            </Button>
          </div>
          <div className="space-y-3">
            {fields.map((field, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Input 
                  placeholder="Field name" 
                  value={field.name}
                  onChange={(e) => handleFieldChange(index, "name", e.target.value)}
                  className="flex-1 h-8 text-sm" 
                />
                <Input 
                  placeholder="CSS Selector" 
                  value={field.selector}
                  onChange={(e) => handleFieldChange(index, "selector", e.target.value)}
                  className="flex-1 h-8 text-sm" 
                />
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8"
                  onClick={() => handleRemoveField(index)}
                  disabled={fields.length === 1}
                >
                  <i className="ri-delete-bin-line text-gray-500"></i>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div>
        <Label>Advanced Options</Label>
        <div className="space-y-2 mt-1">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="useProxy" 
              checked={useProxy}
              onCheckedChange={(checked) => setUseProxy(checked as boolean)}
            />
            <Label htmlFor="useProxy" className="text-sm font-normal cursor-pointer">
              Use proxy rotation
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="javascript" 
              checked={executeJavascript}
              onCheckedChange={(checked) => setExecuteJavascript(checked as boolean)}
            />
            <Label htmlFor="javascript" className="text-sm font-normal cursor-pointer">
              Execute JavaScript
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="pagination" 
              checked={followPagination}
              onCheckedChange={(checked) => setFollowPagination(checked as boolean)}
            />
            <Label htmlFor="pagination" className="text-sm font-normal cursor-pointer">
              Follow pagination
            </Label>
          </div>
        </div>
      </div>
      
      <div>
        <Label>Data Export Format</Label>
        <div className="flex space-x-4 mt-1">
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="json" 
              name="format" 
              checked={exportFormat === "json"}
              onChange={() => setExportFormat("json")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="json" className="text-sm font-normal cursor-pointer">
              JSON
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="csv" 
              name="format" 
              checked={exportFormat === "csv"}
              onChange={() => setExportFormat("csv")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="csv" className="text-sm font-normal cursor-pointer">
              CSV
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="database" 
              name="format" 
              checked={exportFormat === "database"}
              onChange={() => setExportFormat("database")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="database" className="text-sm font-normal cursor-pointer">
              Database
            </Label>
          </div>
        </div>
      </div>
    </div>
  );
}
