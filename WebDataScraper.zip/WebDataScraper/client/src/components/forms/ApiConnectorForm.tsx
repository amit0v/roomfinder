import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ApiConnectorConfig, TaskFrequency, DataFormat } from "@/types";

interface ApiConnectorFormProps {
  onChange: (data: Partial<ApiConnectorConfig>, isValid: boolean) => void;
}

export default function ApiConnectorForm({ onChange }: ApiConnectorFormProps) {
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [method, setMethod] = useState<"GET" | "POST">("GET");
  const [headers, setHeaders] = useState<Record<string, string>>({});
  const [headerKey, setHeaderKey] = useState("");
  const [headerValue, setHeaderValue] = useState("");
  const [body, setBody] = useState("");
  const [frequency, setFrequency] = useState<TaskFrequency>("once");
  const [exportFormat, setExportFormat] = useState<DataFormat>("json");
  
  useEffect(() => {
    const formData = {
      name,
      url,
      method,
      headers,
      body: method === "POST" ? body : undefined,
      frequency,
      exportFormat
    };
    
    const isValid = name.trim() !== "" && isValidUrl(url);
    
    onChange(formData, isValid);
  }, [name, url, method, headers, body, frequency, exportFormat]);
  
  const isValidUrl = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };
  
  const handleAddHeader = () => {
    if (headerKey.trim() !== "") {
      setHeaders({
        ...headers,
        [headerKey]: headerValue
      });
      setHeaderKey("");
      setHeaderValue("");
    }
  };
  
  const handleRemoveHeader = (key: string) => {
    const newHeaders = { ...headers };
    delete newHeaders[key];
    setHeaders(newHeaders);
  };
  
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Connector Name</Label>
        <Input 
          id="name" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter a name for this API connector"
          className="mt-1" 
        />
      </div>
      
      <div>
        <Label htmlFor="url">API URL</Label>
        <Input 
          id="url" 
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://api.example.com/data"
          className="mt-1" 
        />
      </div>
      
      <div>
        <Label htmlFor="method">HTTP Method</Label>
        <Select value={method} onValueChange={(value: "GET" | "POST") => setMethod(value)}>
          <SelectTrigger id="method" className="mt-1">
            <SelectValue placeholder="Select HTTP method" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="GET">GET</SelectItem>
            <SelectItem value="POST">POST</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label>HTTP Headers</Label>
        <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-4 mt-1">
          <div className="flex space-x-2 mb-3">
            <Input 
              placeholder="Header name" 
              value={headerKey}
              onChange={(e) => setHeaderKey(e.target.value)}
              className="flex-1" 
            />
            <Input 
              placeholder="Value" 
              value={headerValue}
              onChange={(e) => setHeaderValue(e.target.value)}
              className="flex-1" 
            />
            <button 
              className="px-4 py-2 bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 dark:hover:bg-gray-700 rounded-lg text-sm font-medium"
              onClick={handleAddHeader}
            >
              Add
            </button>
          </div>
          
          {Object.keys(headers).length > 0 ? (
            <div className="space-y-2">
              {Object.entries(headers).map(([key, value]) => (
                <div key={key} className="flex justify-between items-center p-2 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700">
                  <div className="flex-1">
                    <span className="text-sm font-medium">{key}:</span>{" "}
                    <span className="text-sm text-gray-600 dark:text-gray-400">{value}</span>
                  </div>
                  <button 
                    className="text-red-500 hover:text-red-700"
                    onClick={() => handleRemoveHeader(key)}
                  >
                    <i className="ri-delete-bin-line"></i>
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-2 text-sm text-gray-500">
              No headers added yet
            </div>
          )}
        </div>
      </div>
      
      {method === "POST" && (
        <div>
          <Label htmlFor="body">Request Body (JSON)</Label>
          <Textarea 
            id="body" 
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder='{"key": "value"}'
            rows={4}
            className="mt-1 font-mono text-sm" 
          />
        </div>
      )}
      
      <div>
        <Label htmlFor="frequency">Frequency</Label>
        <Select value={frequency} onValueChange={(value: TaskFrequency) => setFrequency(value)}>
          <SelectTrigger id="frequency" className="mt-1">
            <SelectValue placeholder="Select frequency" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="once">Once</SelectItem>
            <SelectItem value="hourly">Hourly</SelectItem>
            <SelectItem value="daily">Daily</SelectItem>
            <SelectItem value="weekly">Weekly</SelectItem>
            <SelectItem value="monthly">Monthly</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label>Data Export Format</Label>
        <div className="flex space-x-4 mt-1">
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="json" 
              name="format" 
              checked={exportFormat === "json"}
              onChange={() => setExportFormat("json")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="json" className="text-sm font-normal cursor-pointer">
              JSON
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="csv" 
              name="format" 
              checked={exportFormat === "csv"}
              onChange={() => setExportFormat("csv")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="csv" className="text-sm font-normal cursor-pointer">
              CSV
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="database" 
              name="format" 
              checked={exportFormat === "database"}
              onChange={() => setExportFormat("database")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="database" className="text-sm font-normal cursor-pointer">
              Database
            </Label>
          </div>
        </div>
      </div>
    </div>
  );
}
