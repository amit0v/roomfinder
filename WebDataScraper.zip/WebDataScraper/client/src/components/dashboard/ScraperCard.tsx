interface ScraperCardProps {
  title: string;
  description: string;
  icon: string;
  color: "primary" | "blue" | "green" | "purple" | "amber" | "red";
  onClick: () => void;
}

export default function ScraperCard({ title, description, icon, color, onClick }: ScraperCardProps) {
  const getColorClass = (color: string) => {
    switch (color) {
      case "primary":
        return "bg-primary";
      case "blue":
        return "bg-blue-500";
      case "green":
        return "bg-green-500";
      case "purple":
        return "bg-purple-500";
      case "amber":
        return "bg-amber-500";
      case "red":
        return "bg-red-500";
      default:
        return "bg-primary";
    }
  };
  
  const getIconColorClass = (color: string) => {
    switch (color) {
      case "primary":
        return "bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400";
      case "blue":
        return "bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400";
      case "green":
        return "bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400";
      case "purple":
        return "bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400";
      case "amber":
        return "bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400";
      case "red":
        return "bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400";
      default:
        return "bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400";
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md transition-shadow overflow-hidden">
      <div className={`h-2 ${getColorClass(color)}`}></div>
      <div className="p-5">
        <div className="flex items-center space-x-3 mb-3">
          <div className={`h-10 w-10 rounded-full ${getIconColorClass(color)} flex items-center justify-center`}>
            <i className={`${icon} text-xl`}></i>
          </div>
          <h3 className="font-medium">{title}</h3>
        </div>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{description}</p>
        <button 
          className="w-full py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium text-gray-800 dark:text-gray-300"
          onClick={onClick}
        >
          Create Scraper
        </button>
      </div>
    </div>
  );
}
