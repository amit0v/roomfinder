import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  HomeIcon,
  Users2Icon,
  MessageSquareIcon,
  CalendarIcon,
  BarChart3Icon,
  PlusIcon,
  ChevronRightIcon,
  ClockIcon,
  CheckCircleIcon,
  XCircleIcon,
  AlertCircleIcon,
} from "lucide-react";

export default function OwnerDashboard() {
  const [, navigate] = useLocation();

  // Fetch owner's properties
  const { data: properties, isLoading: isLoadingProperties } = useQuery({
    queryKey: ['/api/user/properties'],
    queryFn: async () => {
      const res = await fetch('/api/user/properties');
      if (!res.ok) throw new Error('Failed to fetch properties');
      return res.json();
    }
  });

  // Fetch active chats
  const { data: chatRooms, isLoading: isLoadingChats } = useQuery({
    queryKey: ['/api/chats'],
    queryFn: async () => {
      const res = await fetch('/api/chats');
      if (!res.ok) throw new Error('Failed to fetch chat rooms');
      return res.json();
    }
  });

  // Stats for the dashboard
  const totalProperties = properties?.length || 0;
  const availableProperties = properties?.filter((p: any) => p.status === 'available').length || 0;
  const rentedProperties = properties?.filter((p: any) => p.status === 'rented').length || 0;
  const pendingProperties = properties?.filter((p: any) => p.status === 'pending').length || 0;
  const totalInquiries = chatRooms?.length || 0;
  const unreadMessages = chatRooms?.reduce((count: number, room: any) => {
    return count + (room.messages?.filter((msg: any) => !msg.isRead && msg.senderId !== 1).length || 0);
  }, 0) || 0;

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Owner Dashboard</h1>
          <Button onClick={() => navigate('/owner/property/add')}>
            <PlusIcon className="mr-2 h-4 w-4" />
            Add Property
          </Button>
        </div>

        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Properties</p>
                  {isLoadingProperties ? (
                    <Skeleton className="h-10 w-16" />
                  ) : (
                    <p className="text-3xl font-bold">{totalProperties}</p>
                  )}
                </div>
                <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <HomeIcon className="h-6 w-6 text-indigo-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-500">Active Inquiries</p>
                  {isLoadingChats ? (
                    <Skeleton className="h-10 w-16" />
                  ) : (
                    <p className="text-3xl font-bold">{totalInquiries}</p>
                  )}
                </div>
                <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <MessageSquareIcon className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-500">Rented Properties</p>
                  {isLoadingProperties ? (
                    <Skeleton className="h-10 w-16" />
                  ) : (
                    <p className="text-3xl font-bold">{rentedProperties}</p>
                  )}
                </div>
                <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Users2Icon className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-500">
                    {isLoadingChats ? (
                      <Skeleton className="h-5 w-32" />
                    ) : (
                      <>Unread Messages {unreadMessages > 0 && <Badge className="ml-1">{unreadMessages}</Badge>}</>
                    )}
                  </p>
                  <p className="text-3xl font-bold">
                    {isLoadingChats ? <Skeleton className="h-10 w-16" /> : unreadMessages}
                  </p>
                </div>
                <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <MessageSquareIcon className="h-6 w-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="properties" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:w-auto md:inline-flex">
            <TabsTrigger value="properties">My Properties</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
          </TabsList>

          {/* Properties Tab */}
          <TabsContent value="properties" className="space-y-4">
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-50 p-4 border-b">
                <h2 className="font-semibold">Property Listings</h2>
              </div>

              {isLoadingProperties ? (
                <div className="p-4 space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex border rounded-lg p-4">
                      <Skeleton className="h-24 w-32 rounded-md mr-4" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-6 w-3/4" />
                        <Skeleton className="h-4 w-1/2" />
                        <Skeleton className="h-4 w-1/3" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : properties?.length > 0 ? (
                <div className="divide-y">
                  {properties.map((property: any) => (
                    <div 
                      key={property.id} 
                      className="p-4 hover:bg-gray-50 cursor-pointer flex items-center"
                      onClick={() => navigate(`/owner/property/edit/${property.id}`)}
                    >
                      <div className="w-24 h-24 overflow-hidden rounded-md mr-4">
                        <img 
                          src={property.images?.[0]?.imageUrl || "https://images.unsplash.com/photo-1554995207-c18c203602cb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"}
                          alt={property.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold">{property.title}</h3>
                            <p className="text-sm text-gray-500">{property.address}, {property.city}</p>
                            <p className="text-sm mt-1">
                              ${property.monthlyRent}/mo · {property.bedrooms} {property.bedrooms === 1 ? "bed" : "beds"} · {property.bathrooms} {property.bathrooms === 1 ? "bath" : "baths"}
                            </p>
                          </div>
                          <div className="flex items-center">
                            <Badge
                              className={`${
                                property.status === "available"
                                  ? "bg-green-500"
                                  : property.status === "pending"
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                              } mr-4 capitalize`}
                            >
                              {property.status}
                            </Badge>
                            <ChevronRightIcon className="h-5 w-5 text-gray-400" />
                          </div>
                        </div>
                        <div className="flex mt-2">
                          <span className="text-sm text-gray-500 flex items-center mr-4">
                            <CalendarIcon className="h-4 w-4 mr-1" />
                            Available: {new Date(property.availableFrom).toLocaleDateString()}
                          </span>
                          {property.status === "available" && (
                            <span className="text-sm text-green-600 flex items-center">
                              <CheckCircleIcon className="h-4 w-4 mr-1" />
                              Active Listing
                            </span>
                          )}
                          {property.status === "pending" && (
                            <span className="text-sm text-yellow-600 flex items-center">
                              <ClockIcon className="h-4 w-4 mr-1" />
                              Pending Approval
                            </span>
                          )}
                          {property.status === "rented" && (
                            <span className="text-sm text-blue-600 flex items-center">
                              <Users2Icon className="h-4 w-4 mr-1" />
                              Currently Rented
                            </span>
                          )}
                          {property.status === "inactive" && (
                            <span className="text-sm text-gray-600 flex items-center">
                              <XCircleIcon className="h-4 w-4 mr-1" />
                              Inactive Listing
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <HomeIcon className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No properties listed yet</h3>
                  <p className="text-gray-500 mb-6">
                    Start listing your properties to find student renters.
                  </p>
                  <Button onClick={() => navigate("/owner/property/add")}>
                    Add Your First Property
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="space-y-4">
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-50 p-4 border-b">
                <h2 className="font-semibold">Recent Messages</h2>
              </div>

              {isLoadingChats ? (
                <div className="p-4 space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex border rounded-lg p-4">
                      <Skeleton className="h-12 w-12 rounded-full mr-4" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-5 w-1/3" />
                        <Skeleton className="h-4 w-2/3" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : chatRooms?.length > 0 ? (
                <div className="divide-y">
                  {chatRooms.map((chatRoom: any) => {
                    const isOwner = chatRoom.ownerId === 1;
                    const otherUser = isOwner ? chatRoom.student : chatRoom.owner;
                    const unreadCount = chatRoom.messages?.filter((msg: any) => !msg.isRead && msg.senderId !== 1).length || 0;
                    
                    return (
                      <div 
                        key={chatRoom.id} 
                        className="p-4 hover:bg-gray-50 cursor-pointer"
                        onClick={() => navigate(`/chat/${chatRoom.id}`)}
                      >
                        <div className="flex items-start">
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={otherUser?.profileImage} />
                            <AvatarFallback>
                              {otherUser?.fullName?.charAt(0) || 'U'}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <div>
                                <h3 className="font-medium">{otherUser?.fullName}</h3>
                                <p className="text-sm text-gray-500 flex items-center">
                                  <HomeIcon className="h-3 w-3 mr-1" />
                                  {chatRoom.property?.title}
                                </p>
                              </div>
                              <div className="flex items-center">
                                {unreadCount > 0 && (
                                  <Badge className="mr-2">{unreadCount}</Badge>
                                )}
                                <span className="text-xs text-gray-500">
                                  {new Date(chatRoom.lastMessageAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                            {chatRoom.messages && chatRoom.messages.length > 0 && (
                              <p className="text-sm mt-1 text-gray-600 line-clamp-1">
                                {chatRoom.messages[0].senderId === 1 ? "You: " : ""}
                                {chatRoom.messages[0].message}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <MessageSquareIcon className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No messages yet</h3>
                  <p className="text-gray-500">
                    When students inquire about your properties, conversations will appear here.
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}