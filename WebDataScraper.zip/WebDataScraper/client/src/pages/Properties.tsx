import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import MainLayout from "@/components/layout/MainLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ErrorPlaceholder } from "@/components/ui/error-placeholder";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  MapPinIcon,
  BedDoubleIcon,
  BathIcon,
  HomeIcon,
  SearchIcon,
  FilterIcon,
  LoaderIcon,
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Property } from "@shared/schema";
import { useMobile } from "@/hooks/use-mobile";

export default function Properties() {
  const [location, navigate] = useLocation();
  const isMobile = useMobile();
  
  // Parse the search query directly from location
  const getSearchParams = () => {
    const queryString = location.split('?')[1] || '';
    return new URLSearchParams(queryString);
  };
  
  const searchParams = getSearchParams();

  // Filter state
  const [filters, setFilters] = useState({
    city: searchParams.get("city") || "",
    minPrice: parseInt(searchParams.get("minPrice") || "0") || 0,
    maxPrice: parseInt(searchParams.get("maxPrice") || "3000") || 3000,
    bedrooms: searchParams.get("bedrooms") || "",
    bathrooms: searchParams.get("bathrooms") || "",
    propertyType: searchParams.get("propertyType") || "",
    furnished: searchParams.get("furnished") === "true",
    parking: searchParams.get("parking") === "true",
    pets: searchParams.get("pets") === "true",
  });

  // Pagination state
  const [page, setPage] = useState(parseInt(searchParams.get("page") || "1") || 1);
  const limit = 9;

  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    if (filters.city) params.append("city", filters.city);
    params.append("minPrice", filters.minPrice.toString());
    params.append("maxPrice", filters.maxPrice.toString());
    if (filters.bedrooms) params.append("bedrooms", filters.bedrooms.toString());
    if (filters.bathrooms) params.append("bathrooms", filters.bathrooms.toString());
    if (filters.propertyType && filters.propertyType !== "all") params.append("propertyType", filters.propertyType);
    if (filters.furnished) params.append("furnished", "true");
    if (filters.parking) params.append("parking", "true");
    if (filters.pets) params.append("pets", "true");
    params.append("page", page.toString());

    const queryString = params.toString();
    navigate(`/properties${queryString ? `?${queryString}` : ""}`);
  }, [filters, page, navigate]);

  // Fetch properties with filters
  const {
    data,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["/api/properties", { ...filters, page, limit }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.city) params.append("city", filters.city);
      params.append("minPrice", filters.minPrice.toString());
      params.append("maxPrice", filters.maxPrice.toString());
      if (filters.bedrooms) params.append("bedrooms", filters.bedrooms.toString());
      if (filters.bathrooms) params.append("bathrooms", filters.bathrooms.toString());
      if (filters.propertyType && filters.propertyType !== "all") params.append("propertyType", filters.propertyType);
      if (filters.furnished) params.append("furnished", "true");
      if (filters.parking) params.append("parking", "true");
      if (filters.pets) params.append("pets", "true");
      params.append("page", page.toString());
      params.append("limit", limit.toString());

      const res = await fetch(`/api/properties?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch properties");
      return await res.json();
    },
  });

  const properties = data?.properties || [];
  const totalPages = data?.pagination?.pages || 1;

  const handleFilterChange = (name: string, value: any) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
    setPage(1); // Reset page when filters change
  };

  const handlePriceRangeChange = (value: number[]) => {
    setFilters((prev) => ({
      ...prev,
      minPrice: value[0],
      maxPrice: value[1],
    }));
    setPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
    window.scrollTo(0, 0);
  };

  const clearFilters = () => {
    setFilters({
      city: "",
      minPrice: 0,
      maxPrice: 3000,
      bedrooms: "",
      bathrooms: "",
      propertyType: "",
      furnished: false,
      parking: false,
      pets: false,
    });
    setPage(1);
  };

  const FilterPanel = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium mb-2">Location</h3>
        <Input
          placeholder="Enter city or neighborhood"
          value={filters.city}
          onChange={(e) => handleFilterChange("city", e.target.value)}
        />
      </div>

      <div>
        <h3 className="font-medium mb-2">Price Range</h3>
        <div className="px-2">
          <Slider
            value={[filters.minPrice, filters.maxPrice]}
            min={0}
            max={5000}
            step={100}
            onValueChange={handlePriceRangeChange}
          />
          <div className="flex justify-between mt-2 text-sm text-gray-500">
            <span>${filters.minPrice}</span>
            <span>${filters.maxPrice}</span>
          </div>
        </div>
      </div>

      <div>
        <h3 className="font-medium mb-2">Property Type</h3>
        <Select
          value={filters.propertyType}
          onValueChange={(value) => handleFilterChange("propertyType", value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Types</SelectItem>
            <SelectItem value="apartment">Apartment</SelectItem>
            <SelectItem value="house">House</SelectItem>
            <SelectItem value="room">Room</SelectItem>
            <SelectItem value="studio">Studio</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <h3 className="font-medium mb-2">Bedrooms</h3>
        <Select
          value={filters.bedrooms}
          onValueChange={(value) => handleFilterChange("bedrooms", value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Any" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">Any</SelectItem>
            <SelectItem value="0">Studio</SelectItem>
            <SelectItem value="1">1 Bedroom</SelectItem>
            <SelectItem value="2">2 Bedrooms</SelectItem>
            <SelectItem value="3">3 Bedrooms</SelectItem>
            <SelectItem value="4">4+ Bedrooms</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <h3 className="font-medium mb-2">Bathrooms</h3>
        <Select
          value={filters.bathrooms}
          onValueChange={(value) => handleFilterChange("bathrooms", value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Any" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">Any</SelectItem>
            <SelectItem value="1">1 Bathroom</SelectItem>
            <SelectItem value="1.5">1.5 Bathrooms</SelectItem>
            <SelectItem value="2">2 Bathrooms</SelectItem>
            <SelectItem value="2.5">2.5+ Bathrooms</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <h3 className="font-medium mb-2">Amenities</h3>
        <div className="flex items-center gap-2">
          <Checkbox
            id="furnished"
            checked={filters.furnished}
            onCheckedChange={(checked) =>
              handleFilterChange("furnished", checked === true)
            }
          />
          <Label htmlFor="furnished">Furnished</Label>
        </div>
        <div className="flex items-center gap-2">
          <Checkbox
            id="parking"
            checked={filters.parking}
            onCheckedChange={(checked) =>
              handleFilterChange("parking", checked === true)
            }
          />
          <Label htmlFor="parking">Parking Available</Label>
        </div>
        <div className="flex items-center gap-2">
          <Checkbox
            id="pets"
            checked={filters.pets}
            onCheckedChange={(checked) =>
              handleFilterChange("pets", checked === true)
            }
          />
          <Label htmlFor="pets">Pets Allowed</Label>
        </div>
      </div>

      <Button
        variant="outline"
        className="w-full"
        onClick={clearFilters}
      >
        Clear Filters
      </Button>
    </div>
  );

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Properties</h1>
          
          {isMobile && (
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm">
                  <FilterIcon className="h-4 w-4 mr-2" />
                  Filters
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                  <SheetDescription>
                    Refine your property search
                  </SheetDescription>
                </SheetHeader>
                <div className="py-4">
                  <FilterPanel />
                </div>
              </SheetContent>
            </Sheet>
          )}
        </div>

        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Desktop Filter Sidebar */}
          {!isMobile && (
            <div className="col-span-1 hidden lg:block">
              <div className="sticky top-24 bg-white rounded-lg border p-6">
                <h2 className="text-lg font-semibold mb-6">Filters</h2>
                <FilterPanel />
              </div>
            </div>
          )}

          {/* Properties Grid */}
          <div className="lg:col-span-3">
            {/* Search Query Display */}
            {filters.city && (
              <div className="mb-4">
                <h2 className="text-xl font-medium">
                  Properties in <span className="text-indigo-600">{filters.city}</span>
                </h2>
              </div>
            )}

            {/* Loading State */}
            {isLoading && (
              <div className="flex justify-center items-center py-20">
                <LoaderIcon className="h-8 w-8 animate-spin text-indigo-600" />
                <span className="ml-2 text-lg">Loading properties...</span>
              </div>
            )}

            {/* Error State */}
            {isError && (
              <div className="py-10">
                <ErrorPlaceholder 
                  type="server"
                  title="Unable to Load Properties"
                  message="We're having trouble connecting to our database. Please try again later."
                  actionText="Try Again"
                  onAction={() => window.location.reload()}
                />
              </div>
            )}

            {/* No Results */}
            {!isLoading && !isError && properties.length === 0 && (
              <div className="py-10">
                <ErrorPlaceholder 
                  type="not-found"
                  title="No Properties Found"
                  message="We couldn't find any properties matching your criteria. Try adjusting your filters or search in a different location."
                  actionText="Clear Filters"
                  onAction={clearFilters}
                />
              </div>
            )}

            {/* Property Grid */}
            {!isLoading && !isError && properties.length > 0 && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {properties.map((property: Property) => (
                    <Card
                      key={property.id}
                      className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow duration-200"
                      onClick={() => navigate(`/property/${property.id}`)}
                    >
                      <div className="relative h-48 overflow-hidden">
                        <img
                          src={
                            property.images?.[0]?.imageUrl ||
                            "https://images.unsplash.com/photo-1554995207-c18c203602cb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
                          }
                          alt={property.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 right-2">
                          <Badge className="bg-green-500 hover:bg-green-600">
                            {property.status}
                          </Badge>
                        </div>
                      </div>
                      <CardContent className="p-5">
                        <h3 className="text-xl font-semibold text-gray-900 mb-2 line-clamp-1">
                          {property.title}
                        </h3>
                        <div className="flex items-center text-gray-500 mb-2">
                          <MapPinIcon className="w-4 h-4 mr-1" />
                          <span className="text-sm line-clamp-1">
                            {property.address}, {property.city}
                          </span>
                        </div>
                        <div className="flex space-x-4 mb-4">
                          <div className="flex items-center text-gray-500">
                            <BedDoubleIcon className="w-4 h-4 mr-1" />
                            <span className="text-sm">
                              {property.bedrooms}{" "}
                              {property.bedrooms === 1 ? "Bed" : "Beds"}
                            </span>
                          </div>
                          <div className="flex items-center text-gray-500">
                            <BathIcon className="w-4 h-4 mr-1" />
                            <span className="text-sm">
                              {property.bathrooms}{" "}
                              {property.bathrooms === 1 ? "Bath" : "Baths"}
                            </span>
                          </div>
                          {property.squareFeet && (
                            <div className="flex items-center text-gray-500">
                              <HomeIcon className="w-4 h-4 mr-1" />
                              <span className="text-sm">{property.squareFeet} ft²</span>
                            </div>
                          )}
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-xl font-bold text-indigo-600">
                            ${property.monthlyRent}/mo
                          </span>
                          <div className="flex items-center">
                            {property.owner?.isVerified && (
                              <Badge
                                variant="outline"
                                className="border-blue-500 text-blue-700"
                              >
                                Verified Owner
                              </Badge>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <Pagination className="mt-8">
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious
                          onClick={() =>
                            page > 1 && handlePageChange(page - 1)
                          }
                          className={
                            page === 1
                              ? "pointer-events-none opacity-50"
                              : "cursor-pointer"
                          }
                        />
                      </PaginationItem>

                      {[...Array(totalPages)].map((_, i) => {
                        const pageNumber = i + 1;
                        // Show first page, current page, last page and pages around current page
                        if (
                          pageNumber === 1 ||
                          pageNumber === totalPages ||
                          (pageNumber >= page - 1 && pageNumber <= page + 1)
                        ) {
                          return (
                            <PaginationItem key={pageNumber}>
                              <PaginationLink
                                isActive={pageNumber === page}
                                onClick={() => handlePageChange(pageNumber)}
                              >
                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>
                          );
                        }

                        // Show ellipsis for skipped pages
                        if (
                          (pageNumber === 2 && page > 3) ||
                          (pageNumber === totalPages - 1 && page < totalPages - 2)
                        ) {
                          return (
                            <PaginationItem key={pageNumber}>
                              <PaginationEllipsis />
                            </PaginationItem>
                          );
                        }

                        return null;
                      })}

                      <PaginationItem>
                        <PaginationNext
                          onClick={() =>
                            page < totalPages && handlePageChange(page + 1)
                          }
                          className={
                            page === totalPages
                              ? "pointer-events-none opacity-50"
                              : "cursor-pointer"
                          }
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}