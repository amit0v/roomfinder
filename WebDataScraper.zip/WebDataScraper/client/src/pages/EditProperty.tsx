import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogTrigger
} from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertCircleIcon, 
  LoaderIcon, 
  Trash2Icon, 
  PlusIcon, 
  TrashIcon,
  CheckIcon,
  XIcon,
  HomeIcon
} from "lucide-react";

// Form validation schema
const propertyFormSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  address: z.string().min(5, "Address must be at least 5 characters"),
  city: z.string().min(2, "City is required"),
  state: z.string().min(2, "State is required"),
  zipCode: z.string().min(5, "Zip code is required"),
  latitude: z.coerce.number().optional(),
  longitude: z.coerce.number().optional(),
  propertyType: z.enum(["apartment", "house", "room", "studio"]),
  monthlyRent: z.coerce.number().positive("Monthly rent must be greater than 0"),
  securityDeposit: z.coerce.number().positive("Security deposit must be greater than 0").optional(),
  bedrooms: z.coerce.number().min(0, "Bedrooms must be 0 or greater"),
  bathrooms: z.coerce.number().min(0.5, "Bathrooms must be 0.5 or greater"),
  squareFeet: z.coerce.number().positive("Square feet must be greater than 0").optional(),
  isFurnished: z.boolean().default(false),
  hasParking: z.boolean().default(false),
  petsAllowed: z.boolean().default(false),
  availableFrom: z.string(),
  availableUntil: z.string().optional().nullable(),
  status: z.enum(["available", "pending", "rented", "inactive"]),
  images: z.array(z.string()).optional(),
  amenities: z.array(z.string()).optional(),
});

type PropertyFormValues = z.infer<typeof propertyFormSchema>;

export default function EditProperty() {
  const [, params] = useRoute("/owner/property/edit/:id");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [imageUrls, setImageUrls] = useState<string[]>([""]);
  const [amenities, setAmenities] = useState<string[]>([""]);
  const [error, setError] = useState<string | null>(null);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);
  const propertyId = params?.id ? parseInt(params.id) : 0;

  // Setup form with validation
  const form = useForm<PropertyFormValues>({
    resolver: zodResolver(propertyFormSchema),
    defaultValues: {
      title: "",
      description: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      propertyType: "apartment",
      monthlyRent: 0,
      securityDeposit: 0,
      bedrooms: 1,
      bathrooms: 1,
      squareFeet: 0,
      isFurnished: false,
      hasParking: false,
      petsAllowed: false,
      availableFrom: new Date().toISOString().split("T")[0],
      availableUntil: null,
      status: "available",
    }
  });

  // Fetch property data
  const { data: property, isLoading } = useQuery({
    queryKey: ['/api/properties', propertyId],
    queryFn: async () => {
      const res = await fetch(`/api/properties/${propertyId}`);
      if (!res.ok) throw new Error('Failed to fetch property details');
      return res.json();
    },
    enabled: !!propertyId,
    onSuccess: (data) => {
      // Format dates properly
      const formattedData = {
        ...data,
        availableFrom: new Date(data.availableFrom).toISOString().split('T')[0],
        availableUntil: data.availableUntil 
          ? new Date(data.availableUntil).toISOString().split('T')[0] 
          : null,
      };
      
      // Reset form with property data
      form.reset(formattedData);
      
      // Set image URLs and amenities
      if (data.images && data.images.length > 0) {
        setImageUrls(data.images.map((img: any) => img.imageUrl));
      }
      
      if (data.amenities && data.amenities.length > 0) {
        setAmenities(data.amenities.map((amenity: any) => amenity.name));
      } else {
        setAmenities([""]);
      }
    }
  });

  // Update property mutation
  const updatePropertyMutation = useMutation({
    mutationFn: async (data: PropertyFormValues) => {
      return apiRequest(`/properties/${propertyId}`, {
        method: "PATCH",
        body: JSON.stringify({
          ...data,
          images: imageUrls.filter(url => url.trim() !== ""),
          amenities: amenities.filter(amenity => amenity.trim() !== ""),
        }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Property Updated",
        description: "Your property listing has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/properties', propertyId] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/properties'] });
    },
    onError: (error: any) => {
      setError(error.message || "Failed to update property. Please try again.");
      toast({
        title: "Error",
        description: "Failed to update property. Please check the form and try again.",
        variant: "destructive",
      });
    },
  });

  // Delete property mutation
  const deletePropertyMutation = useMutation({
    mutationFn: async () => {
      return apiRequest(`/properties/${propertyId}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      toast({
        title: "Property Deleted",
        description: "Your property listing has been deleted successfully",
      });
      navigate("/owner/dashboard");
    },
    onError: (error: any) => {
      setError(error.message || "Failed to delete property. Please try again.");
      toast({
        title: "Error",
        description: "Failed to delete property. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = async (data: PropertyFormValues) => {
    setError(null);
    
    // Validate images and amenities
    const filteredImages = imageUrls.filter(url => url.trim() !== "");
    const filteredAmenities = amenities.filter(amenity => amenity.trim() !== "");
    
    if (filteredImages.length === 0) {
      setError("Please add at least one property image");
      return;
    }
    
    // Update form data with images and amenities
    data.images = filteredImages;
    data.amenities = filteredAmenities;
    
    updatePropertyMutation.mutate(data);
  };

  // Handle image URL changes
  const handleImageUrlChange = (index: number, value: string) => {
    const newImageUrls = [...imageUrls];
    newImageUrls[index] = value;
    setImageUrls(newImageUrls);
  };

  // Add image URL field
  const addImageUrl = () => {
    setImageUrls([...imageUrls, ""]);
  };

  // Remove image URL field
  const removeImageUrl = (index: number) => {
    if (imageUrls.length > 1) {
      const newImageUrls = [...imageUrls];
      newImageUrls.splice(index, 1);
      setImageUrls(newImageUrls);
    }
  };

  // Handle amenity changes
  const handleAmenityChange = (index: number, value: string) => {
    const newAmenities = [...amenities];
    newAmenities[index] = value;
    setAmenities(newAmenities);
  };

  // Add amenity field
  const addAmenity = () => {
    setAmenities([...amenities, ""]);
  };

  // Remove amenity field
  const removeAmenity = (index: number) => {
    if (amenities.length > 1) {
      const newAmenities = [...amenities];
      newAmenities.splice(index, 1);
      setAmenities(newAmenities);
    }
  };

  // Delete property
  const handleDeleteProperty = () => {
    deletePropertyMutation.mutate();
    setIsConfirmDeleteOpen(false);
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6">
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-96" />
          </div>
          
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-36" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent className="space-y-8">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="h-6 w-36" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <div className="grid grid-cols-2 gap-4">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }
  
  if (!property) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
          <HomeIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-3xl font-bold mb-2">Property Not Found</h1>
          <p className="text-gray-600 mb-6">
            We couldn't find the property you're looking for. It may have been removed or you don't have access to it.
          </p>
          <Button onClick={() => navigate("/owner/dashboard")}>
            Return to Dashboard
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Edit Property</h1>
            <p className="text-gray-600 mt-1">
              Update your property listing details
            </p>
          </div>
          <div className="flex space-x-2">
            <Button 
              variant="outline"
              onClick={() => navigate(`/property/${propertyId}`)}
            >
              View Listing
            </Button>
            <Dialog open={isConfirmDeleteOpen} onOpenChange={setIsConfirmDeleteOpen}>
              <DialogTrigger asChild>
                <Button variant="destructive">
                  <TrashIcon className="h-4 w-4 mr-2" />
                  Delete Property
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Are you sure you want to delete this property?</DialogTitle>
                  <DialogDescription>
                    This action cannot be undone. This will permanently delete your property listing
                    and remove it from our servers.
                  </DialogDescription>
                </DialogHeader>
                <DialogFooter className="mt-4">
                  <Button
                    variant="outline"
                    onClick={() => setIsConfirmDeleteOpen(false)}
                  >
                    <XIcon className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={handleDeleteProperty}
                    disabled={deletePropertyMutation.isPending}
                  >
                    {deletePropertyMutation.isPending ? (
                      <>
                        <LoaderIcon className="h-4 w-4 mr-2 animate-spin" />
                        Deleting...
                      </>
                    ) : (
                      <>
                        <TrashIcon className="h-4 w-4 mr-2" />
                        Delete Property
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="details">
          <TabsList className="mb-6">
            <TabsTrigger value="details">Property Details</TabsTrigger>
            <TabsTrigger value="images">Images</TabsTrigger>
            <TabsTrigger value="amenities">Amenities</TabsTrigger>
            <TabsTrigger value="status">Status</TabsTrigger>
          </TabsList>

          <Card>
            <CardContent className="pt-6">
              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircleIcon className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                  {/* Property Details Tab */}
                  <TabsContent value="details" className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Basic Details</h3>
                      
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Property Title</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Cozy 2-Bedroom Apartment Near Campus" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Property Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Describe your property in detail..." 
                                {...field} 
                                className="min-h-32"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="propertyType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Property Type</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select property type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="apartment">Apartment</SelectItem>
                                  <SelectItem value="house">House</SelectItem>
                                  <SelectItem value="room">Room</SelectItem>
                                  <SelectItem value="studio">Studio</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="monthlyRent"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Monthly Rent ($)</FormLabel>
                              <FormControl>
                                <Input type="number" min="0" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="bedrooms"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bedrooms</FormLabel>
                              <FormControl>
                                <Input type="number" min="0" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="bathrooms"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bathrooms</FormLabel>
                              <FormControl>
                                <Input type="number" min="0.5" step="0.5" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="squareFeet"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Square Feet</FormLabel>
                              <FormControl>
                                <Input type="number" min="0" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="securityDeposit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Security Deposit ($)</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Location</h3>
                      
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Street Address</FormLabel>
                            <FormControl>
                              <Input placeholder="123 Main St" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="city"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>City</FormLabel>
                              <FormControl>
                                <Input placeholder="City" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="state"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>State</FormLabel>
                              <FormControl>
                                <Input placeholder="State" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="zipCode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Zip Code</FormLabel>
                              <FormControl>
                                <Input placeholder="Zip Code" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="latitude"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Latitude</FormLabel>
                              <FormControl>
                                <Input type="number" step="any" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="longitude"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Longitude</FormLabel>
                              <FormControl>
                                <Input type="number" step="any" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Features</h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="isFurnished"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>Furnished</FormLabel>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="hasParking"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>Parking</FormLabel>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="petsAllowed"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>Pets Allowed</FormLabel>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="availableFrom"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Available From</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="availableUntil"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Available Until (Optional)</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => navigate('/owner/dashboard')}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={updatePropertyMutation.isPending}
                      >
                        {updatePropertyMutation.isPending ? (
                          <>
                            <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <CheckIcon className="mr-2 h-4 w-4" />
                            Save Changes
                          </>
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                  
                  {/* Images Tab */}
                  <TabsContent value="images" className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-medium">Property Images</h3>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={addImageUrl}
                        >
                          <PlusIcon className="h-4 w-4 mr-2" />
                          Add Image
                        </Button>
                      </div>
                      
                      {/* Preview of current images */}
                      {imageUrls.filter(url => url.trim() !== "").length > 0 && (
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                          {imageUrls.filter(url => url.trim() !== "").map((url, idx) => (
                            <div key={idx} className="relative group">
                              <img
                                src={url}
                                alt={`Property image ${idx + 1}`}
                                className="w-full h-32 object-cover rounded-md"
                              />
                              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity rounded-md">
                                <Button
                                  type="button"
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => removeImageUrl(imageUrls.indexOf(url))}
                                >
                                  <TrashIcon className="h-4 w-4" />
                                </Button>
                              </div>
                              {idx === 0 && (
                                <span className="absolute top-2 left-2 bg-blue-500 text-white text-xs px-2 py-1 rounded">
                                  Featured
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <div className="space-y-4">
                        {imageUrls.map((url, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <Input
                              placeholder="Image URL"
                              value={url}
                              onChange={(e) => handleImageUrlChange(index, e.target.value)}
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => removeImageUrl(index)}
                              disabled={imageUrls.length === 1}
                            >
                              <Trash2Icon className="h-4 w-4 text-gray-500" />
                            </Button>
                          </div>
                        ))}
                      </div>
                      <FormDescription>
                        Add URLs to images of your property. The first image will be the featured image.
                      </FormDescription>
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => navigate('/owner/dashboard')}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={updatePropertyMutation.isPending}
                      >
                        {updatePropertyMutation.isPending ? (
                          <>
                            <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <CheckIcon className="mr-2 h-4 w-4" />
                            Save Changes
                          </>
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                  
                  {/* Amenities Tab */}
                  <TabsContent value="amenities" className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-medium">Amenities</h3>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={addAmenity}
                        >
                          <PlusIcon className="h-4 w-4 mr-2" />
                          Add Amenity
                        </Button>
                      </div>
                      
                      <div className="space-y-4">
                        {amenities.map((amenity, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <Input
                              placeholder="Amenity name"
                              value={amenity}
                              onChange={(e) => handleAmenityChange(index, e.target.value)}
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => removeAmenity(index)}
                              disabled={amenities.length === 1}
                            >
                              <Trash2Icon className="h-4 w-4 text-gray-500" />
                            </Button>
                          </div>
                        ))}
                      </div>
                      <FormDescription>
                        Add amenities available at your property (e.g., Wi-Fi, Air Conditioning, Gym).
                      </FormDescription>
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => navigate('/owner/dashboard')}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={updatePropertyMutation.isPending}
                      >
                        {updatePropertyMutation.isPending ? (
                          <>
                            <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <CheckIcon className="mr-2 h-4 w-4" />
                            Save Changes
                          </>
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                  
                  {/* Status Tab */}
                  <TabsContent value="status" className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Property Status</h3>
                      
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Listing Status</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="available">Available</SelectItem>
                                <SelectItem value="pending">Pending / Application in Process</SelectItem>
                                <SelectItem value="rented">Rented</SelectItem>
                                <SelectItem value="inactive">Inactive (Temporarily Unavailable)</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Change the status of your property listing to reflect its current availability.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Alert className="mt-4">
                        <AlertTitle>Status Guidelines</AlertTitle>
                        <AlertDescription>
                          <ul className="list-disc pl-5 mt-2 space-y-1">
                            <li><strong>Available:</strong> Property is available for rent and will be shown in search results.</li>
                            <li><strong>Pending:</strong> Property has an application in process but is still shown in search results.</li>
                            <li><strong>Rented:</strong> Property has been rented and will not be shown in search results.</li>
                            <li><strong>Inactive:</strong> Property listing is temporarily hidden from search results.</li>
                          </ul>
                        </AlertDescription>
                      </Alert>
                    </div>
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => navigate('/owner/dashboard')}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={updatePropertyMutation.isPending}
                      >
                        {updatePropertyMutation.isPending ? (
                          <>
                            <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <CheckIcon className="mr-2 h-4 w-4" />
                            Save Changes
                          </>
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                </form>
              </Form>
            </CardContent>
          </Card>
        </Tabs>
      </div>
    </MainLayout>
  );
}