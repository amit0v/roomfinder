import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { GradientButton } from "@/components/ui/gradient-button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { PropertyCard } from "@/components/ui/property-card";
import { 
  SearchIcon, 
  HomeIcon, 
  MapPinIcon, 
  BedDoubleIcon, 
  BathIcon,
  ArrowRightIcon,
  MessageSquareIcon,
  CheckIcon,
  SparklesIcon,
  BuildingIcon,
  StarIcon
} from "lucide-react";
import MainLayout from "@/components/layout/MainLayout";

export default function Home() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch featured properties
  const { data: featuredProperties, isLoading } = useQuery({
    queryKey: ['/api/properties', { limit: 6, featured: true }],
    queryFn: async () => {
      try {
        const res = await fetch('/api/properties?limit=6&featured=true');
        if (!res.ok) throw new Error('Failed to fetch featured properties');
        return res.json();
      } catch (error) {
        console.error('Error fetching featured properties:', error);
        return { properties: [] };
      }
    }
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/properties?city=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden py-24 sm:py-32">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-700 opacity-90"></div>
          <img 
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80" 
            alt="Student housing" 
            className="h-full w-full object-cover"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center sm:text-left max-w-3xl mx-auto sm:mx-0">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white drop-shadow-md">
              Find Your <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-200 to-yellow-100">Perfect</span> Student Home
            </h1>
            <p className="text-xl mb-8 text-white/90 drop-shadow">
              The easiest way to find and rent student accommodations near your campus.
            </p>

            <form onSubmit={handleSearch} className="relative max-w-xl w-full bg-white/10 backdrop-blur-md p-2 rounded-lg shadow-lg border border-white/20">
              <div className="flex">
                <div className="relative flex-grow">
                  <Input
                    type="text"
                    placeholder="Enter city, campus or neighborhood..."
                    className="pl-10 h-14 text-white bg-white/20 border-0 placeholder:text-white/70 focus-visible:ring-2 focus-visible:ring-indigo-300"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white h-5 w-5" />
                </div>
                <Button
                  type="submit"
                  className="h-14 px-6 ml-2 bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white font-medium rounded-md"
                >
                  Search
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-3 justify-center sm:justify-start">
                <Badge className="bg-white/30 hover:bg-white/40 text-white cursor-pointer px-3 py-1 text-sm" onClick={() => setSearchQuery("New York")}>New York</Badge>
                <Badge className="bg-white/30 hover:bg-white/40 text-white cursor-pointer px-3 py-1 text-sm" onClick={() => setSearchQuery("Los Angeles")}>Los Angeles</Badge>
                <Badge className="bg-white/30 hover:bg-white/40 text-white cursor-pointer px-3 py-1 text-sm" onClick={() => setSearchQuery("Boston")}>Boston</Badge>
                <Badge className="bg-white/30 hover:bg-white/40 text-white cursor-pointer px-3 py-1 text-sm" onClick={() => setSearchQuery("Chicago")}>Chicago</Badge>
              </div>
            </form>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent z-10"></div>
        <div className="absolute top-10 right-10 w-20 h-20 rounded-full bg-purple-500 opacity-20 blur-3xl"></div>
        <div className="absolute bottom-10 left-10 w-32 h-32 rounded-full bg-indigo-500 opacity-20 blur-3xl"></div>
      </section>

      {/* Featured Properties */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold">Featured Properties</h2>
            <Button variant="outline" onClick={() => navigate("/properties")}>
              View All Properties
              <ArrowRightIcon className="ml-2 h-4 w-4" />
            </Button>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <div className="flex justify-between">
                      <Skeleton className="h-5 w-1/4" />
                      <Skeleton className="h-5 w-1/4" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {(featuredProperties?.properties || []).map((property) => (
                <Card
                  key={property.id}
                  className="overflow-hidden cursor-pointer group"
                  onClick={() => navigate(`/property/${property.id}`)}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={property.images?.[0]?.imageUrl || "https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&w=2340&q=80"}
                      alt={property.title}
                      className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                      <p className="text-white font-bold">${property.monthlyRent}/month</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-lg mb-1 line-clamp-1">{property.title}</h3>
                    <div className="flex items-center text-gray-500 text-sm mb-2">
                      <MapPinIcon className="h-4 w-4 mr-1" />
                      <span className="truncate">{property.address}, {property.city}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600 pt-2">
                      <div className="flex items-center">
                        <BedDoubleIcon className="h-4 w-4 mr-1" />
                        <span>{property.bedrooms} {property.bedrooms === 1 ? "Bed" : "Beds"}</span>
                      </div>
                      <div className="flex items-center">
                        <BathIcon className="h-4 w-4 mr-1" />
                        <span>{property.bathrooms} {property.bathrooms === 1 ? "Bath" : "Baths"}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-gray-50 to-white"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">How RoomFinder Works</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our simple three-step process makes finding your ideal student accommodation quick and easy
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
            {/* Step 1 */}
            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-xl">
              <div className="relative mb-6">
                <div className="absolute -top-4 -left-4 w-20 h-20 bg-indigo-100 rounded-full"></div>
                <div className="bg-gradient-to-tr from-indigo-600 to-purple-600 text-white h-16 w-16 flex items-center justify-center rounded-full relative z-10 mb-4">
                  <SearchIcon className="h-8 w-8" />
                </div>
                <div className="absolute -bottom-6 right-0 text-gray-200 text-6xl font-bold opacity-30">1</div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900">Search Properties</h3>
              <p className="text-gray-600">
                Browse verified student properties near your campus by location, price, and amenities. Filter results to find exactly what you're looking for.
              </p>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Verified listings only</span>
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Detailed property information</span>
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Real photos and virtual tours</span>
                </li>
              </ul>
            </div>
            
            {/* Step 2 */}
            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-xl md:mt-8">
              <div className="relative mb-6">
                <div className="absolute -top-4 -left-4 w-20 h-20 bg-indigo-100 rounded-full"></div>
                <div className="bg-gradient-to-tr from-indigo-600 to-purple-600 text-white h-16 w-16 flex items-center justify-center rounded-full relative z-10 mb-4">
                  <MessageSquareIcon className="h-8 w-8" />
                </div>
                <div className="absolute -bottom-6 right-0 text-gray-200 text-6xl font-bold opacity-30">2</div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900">Connect with Owners</h3>
              <p className="text-gray-600">
                Message property owners directly through our secure platform to ask questions, schedule viewings, and negotiate terms.
              </p>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Real-time messaging</span>
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Schedule property viewings</span>
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Identity verification</span>
                </li>
              </ul>
            </div>
            
            {/* Step 3 */}
            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-xl md:mt-16">
              <div className="relative mb-6">
                <div className="absolute -top-4 -left-4 w-20 h-20 bg-indigo-100 rounded-full"></div>
                <div className="bg-gradient-to-tr from-indigo-600 to-purple-600 text-white h-16 w-16 flex items-center justify-center rounded-full relative z-10 mb-4">
                  <HomeIcon className="h-8 w-8" />
                </div>
                <div className="absolute -bottom-6 right-0 text-gray-200 text-6xl font-bold opacity-30">3</div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900">Move Into Your New Home</h3>
              <p className="text-gray-600">
                Once you've found the perfect place, complete your rental agreement online and prepare to move into your new student home!
              </p>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Digital lease signing</span>
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Secure payment options</span>
                </li>
                <li className="flex items-center text-sm text-gray-600">
                  <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                  <span>Move-in coordination</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Button 
              variant="outline" 
              className="mt-4 border-indigo-300 text-indigo-600 hover:bg-indigo-50"
              onClick={() => navigate("/properties")}
            >
              Start Your Search
              <ArrowRightIcon className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -bottom-16 right-0 w-64 h-64 bg-indigo-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-24 -left-12 w-48 h-48 bg-purple-100 rounded-full opacity-50 blur-3xl"></div>
      </section>

      {/* CTA */}
      <section className="py-20 relative">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-700 opacity-95"></div>
          <img 
            src="https://images.unsplash.com/photo-1616627561839-074385245ff6?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80" 
            alt="Student accommodations" 
            className="h-full w-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/80 to-indigo-700/30"></div>
          
          {/* Decorative elements */}
          <div className="absolute top-1/2 left-1/4 w-64 h-64 rounded-full bg-purple-500 opacity-30 blur-3xl"></div>
          <div className="absolute bottom-1/3 right-1/4 w-96 h-96 rounded-full bg-indigo-500 opacity-20 blur-3xl"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-7/12 text-center md:text-left">
              <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">
                Ready to Find Your <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-200 to-yellow-100">Perfect Student Home</span>?
              </h2>
              <p className="text-xl mb-8 text-white/90 max-w-lg">
                Join thousands of students who have found their ideal accommodation through RoomFinder. Our platform makes it easy to connect with verified property owners.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button
                  onClick={() => navigate("/properties")}
                  className="bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 text-white border-0"
                  size="lg"
                >
                  Browse Properties
                </Button>
                <Button
                  onClick={() => navigate("/register")}
                  variant="outline"
                  className="border-white text-white hover:bg-white/20"
                  size="lg"
                >
                  Sign Up Free
                </Button>
              </div>
              
              {/* Social proof */}
              <div className="mt-10 flex items-center justify-center md:justify-start">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-full bg-gradient-to-r from-gray-300 to-gray-400 border-2 border-white overflow-hidden">
                      <img 
                        src={`https://i.pravatar.cc/40?img=${10+i}`} 
                        alt="User avatar" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
                <div className="ml-4 text-white">
                  <p className="text-sm font-medium">Trusted by</p>
                  <p className="text-xs text-white/80">1000+ students</p>
                </div>
              </div>
            </div>
            
            <div className="md:w-5/12 p-6 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xl">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <span className="text-white/90 text-lg font-medium">★★★★★</span>
                  <p className="text-white font-semibold">4.9/5 Overall Rating</p>
                </div>
                
                <div className="space-y-3">
                  {[
                    { name: "Emma", review: "Found my perfect apartment in just 3 days. The messaging feature made it easy to communicate with landlords." },
                    { name: "Michael", review: "The verification process gave me peace of mind that I was renting from a legitimate owner." }
                  ].map((testimonial, i) => (
                    <div key={i} className="bg-white/10 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-amber-300 to-orange-300 flex items-center justify-center mr-3">
                          <span className="text-indigo-900 font-bold text-sm">{testimonial.name.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="text-white font-medium">{testimonial.name}</p>
                          <p className="text-white/70 text-xs">Student</p>
                        </div>
                      </div>
                      <p className="text-white/90 text-sm">{testimonial.review}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}