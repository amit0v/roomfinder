import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import {
  UserIcon,
  PhoneIcon,
  MailIcon,
  PencilIcon,
  LoaderIcon,
  CheckCircleIcon,
  XCircleIcon,
  AlertCircleIcon,
  HomeIcon,
  HeartIcon,
  MessageSquareIcon,
  CheckIcon,
  Settings as SettingsIcon,
  PlusIcon
} from "lucide-react";

export default function Profile() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Fetch user profile
  const { data: user = {}, isLoading } = useQuery({
    queryKey: ['/api/user/profile'],
    queryFn: async () => {
      const res = await fetch('/api/user/profile');
      if (!res.ok) throw new Error('Failed to fetch profile');
      return res.json();
    }
  });

  // Form state
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    bio: '',
    school: '',
    graduationYear: '',
    fieldOfStudy: '',
    profileImage: '',
  });

  // Update form data when user data is loaded
  useState(() => {
    if (user) {
      setFormData(prevData => ({
        ...prevData,
        fullName: user.fullName || '',
        phone: user.phone || '',
        bio: user.bio || '',
        school: user.school || '',
        graduationYear: user.graduationYear || '',
        fieldOfStudy: user.fieldOfStudy || '',
        profileImage: user.profileImage || '',
      }));
    }
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/user/profile', {
        method: 'PATCH',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully",
      });
      setIsEditing(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
    },
    onError: (error: any) => {
      setError(error.message || "Failed to update profile. Please try again.");
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle save profile
  const handleSaveProfile = () => {
    setError(null);
    
    // Basic validation
    if (!formData.fullName.trim()) {
      setError("Full name is required");
      return;
    }
    
    updateProfileMutation.mutate(formData);
  };

  // Reset form to original data
  const cancelEditing = () => {
    setFormData({
      fullName: user.fullName || '',
      phone: user.phone || '',
      bio: user.bio || '',
      school: user.school || '',
      graduationYear: user.graduationYear || '',
      fieldOfStudy: user.fieldOfStudy || '',
      profileImage: user.profileImage || '',
    });
    setIsEditing(false);
    setError(null);
  };

  // Fetch user stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/user/stats'],
    queryFn: async () => {
      const res = await fetch('/api/user/stats');
      if (!res.ok) throw new Error('Failed to fetch user stats');
      return res.json();
    }
  });

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <div className="mb-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-4">
              {isLoading ? (
                <Skeleton className="h-20 w-20 rounded-full" />
              ) : (
                <Avatar className="h-20 w-20 border-4 border-white shadow-md">
                  <AvatarImage src={user.profileImage} />
                  <AvatarFallback className="bg-indigo-100 text-indigo-700 text-xl">
                    {user.fullName?.charAt(0) || user.username?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
              )}
              <div>
                {isLoading ? (
                  <div className="space-y-2">
                    <Skeleton className="h-8 w-48" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                ) : (
                  <>
                    <h1 className="text-3xl font-bold">{user.fullName || "Your Profile"}</h1>
                    <p className="text-gray-600 mt-1 flex items-center">
                      {user.userType === "student" ? (
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 mr-2">
                          Student
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 mr-2">
                          Property Owner
                        </Badge>
                      )}
                      {user.isVerified ? (
                        <span className="flex items-center text-green-600 text-sm font-medium">
                          <CheckCircleIcon className="h-4 w-4 mr-1" />
                          Verified Account
                        </span>
                      ) : user.isVerified === false ? (
                        <span className="flex items-center text-yellow-600 text-sm font-medium">
                          <AlertCircleIcon className="h-4 w-4 mr-1" />
                          Verification in Progress
                        </span>
                      ) : null}
                    </p>
                  </>
                )}
              </div>
            </div>
            {!isLoading && user.userType === "owner" && !user.isVerified && (
              <Button 
                variant="outline" 
                className="text-yellow-600 border-yellow-200 bg-yellow-50 hover:bg-yellow-100"
                onClick={() => navigate('/owner/verification')}
              >
                <AlertCircleIcon className="h-4 w-4 mr-2" />
                Complete Verification
              </Button>
            )}
          </div>
        </div>

        {/* Success Alert */}
        {saveSuccess && (
          <Alert className="mb-6 bg-green-50 border-green-200">
            <CheckIcon className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">Success</AlertTitle>
            <AlertDescription className="text-green-700">
              Your profile has been updated successfully.
            </AlertDescription>
          </Alert>
        )}
        
        {/* Error Alert */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircleIcon className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Profile Info */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Profile Information</CardTitle>
                    <CardDescription>
                      Your personal information and preferences
                    </CardDescription>
                  </div>
                  {!isEditing ? (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setIsEditing(true)}
                    >
                      <PencilIcon className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                  ) : (
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={cancelEditing}
                      >
                        <XCircleIcon className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                      <Button 
                        size="sm" 
                        onClick={handleSaveProfile}
                        disabled={updateProfileMutation.isPending}
                      >
                        {updateProfileMutation.isPending ? (
                          <>
                            <LoaderIcon className="h-4 w-4 mr-2 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <CheckCircleIcon className="h-4 w-4 mr-2" />
                            Save Changes
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Skeleton className="h-5 w-32" />
                      <Skeleton className="h-10 w-full" />
                    </div>
                    <div className="space-y-2">
                      <Skeleton className="h-5 w-32" />
                      <Skeleton className="h-10 w-full" />
                    </div>
                    <div className="space-y-2">
                      <Skeleton className="h-5 w-32" />
                      <Skeleton className="h-24 w-full" />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="space-y-1">
                      <Label htmlFor="username" className="text-gray-500">Username</Label>
                      <div className="flex items-center border rounded-md p-2 bg-gray-50">
                        <UserIcon className="h-4 w-4 text-gray-400 mr-2" />
                        <span>{user.username}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="email" className="text-gray-500">Email</Label>
                      <div className="flex items-center border rounded-md p-2 bg-gray-50">
                        <MailIcon className="h-4 w-4 text-gray-400 mr-2" />
                        <span>{user.email}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="fullName" className="text-gray-500">Full Name</Label>
                      {isEditing ? (
                        <Input
                          id="fullName"
                          name="fullName"
                          value={formData.fullName}
                          onChange={handleInputChange}
                          placeholder="Your full name"
                        />
                      ) : (
                        <div className="flex items-center border rounded-md p-2">
                          <UserIcon className="h-4 w-4 text-gray-400 mr-2" />
                          <span>{user.fullName || "Not provided"}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="phone" className="text-gray-500">Phone Number</Label>
                      {isEditing ? (
                        <Input
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="Your phone number"
                        />
                      ) : (
                        <div className="flex items-center border rounded-md p-2">
                          <PhoneIcon className="h-4 w-4 text-gray-400 mr-2" />
                          <span>{user.phone || "Not provided"}</span>
                        </div>
                      )}
                    </div>
                    
                    {user.userType === "student" && (
                      <>
                        <div className="space-y-1">
                          <Label htmlFor="school" className="text-gray-500">School</Label>
                          {isEditing ? (
                            <Input
                              id="school"
                              name="school"
                              value={formData.school}
                              onChange={handleInputChange}
                              placeholder="Your school or university"
                            />
                          ) : (
                            <div className="flex items-center border rounded-md p-2">
                              <span>{formData.school || "Not provided"}</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <Label htmlFor="fieldOfStudy" className="text-gray-500">Field of Study</Label>
                            {isEditing ? (
                              <Input
                                id="fieldOfStudy"
                                name="fieldOfStudy"
                                value={formData.fieldOfStudy}
                                onChange={handleInputChange}
                                placeholder="Your major/field"
                              />
                            ) : (
                              <div className="flex items-center border rounded-md p-2">
                                <span>{formData.fieldOfStudy || "Not provided"}</span>
                              </div>
                            )}
                          </div>
                          
                          <div className="space-y-1">
                            <Label htmlFor="graduationYear" className="text-gray-500">Graduation Year</Label>
                            {isEditing ? (
                              <Input
                                id="graduationYear"
                                name="graduationYear"
                                value={formData.graduationYear}
                                onChange={handleInputChange}
                                placeholder="Expected graduation year"
                              />
                            ) : (
                              <div className="flex items-center border rounded-md p-2">
                                <span>{formData.graduationYear || "Not provided"}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </>
                    )}
                    
                    <div className="space-y-1">
                      <Label htmlFor="bio" className="text-gray-500">Bio</Label>
                      {isEditing ? (
                        <Textarea
                          id="bio"
                          name="bio"
                          value={formData.bio}
                          onChange={handleInputChange}
                          placeholder="Tell us about yourself"
                          className="min-h-32"
                        />
                      ) : (
                        <div className="border rounded-md p-3">
                          {formData.bio || "No bio provided yet."}
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="profileImage" className="text-gray-500">Profile Image URL</Label>
                      {isEditing ? (
                        <Input
                          id="profileImage"
                          name="profileImage"
                          value={formData.profileImage}
                          onChange={handleInputChange}
                          placeholder="URL to your profile image"
                        />
                      ) : (
                        user.profileImage && (
                          <div className="mt-2">
                            <img 
                              src={user.profileImage} 
                              alt="Profile" 
                              className="h-32 w-32 object-cover rounded-md"
                            />
                          </div>
                        )
                      )}
                    </div>
                    
                    <div className="space-y-1">
                      <Label className="text-gray-500">Member Since</Label>
                      <div className="border rounded-md p-2">
                        {new Date(user.createdAt || Date.now()).toLocaleDateString('en-US', { 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
              {isEditing && (
                <CardFooter className="flex justify-end">
                  <Button 
                    onClick={handleSaveProfile}
                    disabled={updateProfileMutation.isPending}
                    className="w-full md:w-auto"
                  >
                    {updateProfileMutation.isPending ? (
                      <>
                        <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </CardFooter>
              )}
            </Card>
          </div>

          {/* Right Column - Stats & Action */}
          <div className="space-y-6">
            {/* Stats Card */}
            <Card>
              <CardHeader>
                <CardTitle>Your Activity</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingStats ? (
                  <div className="space-y-4">
                    <Skeleton className="h-16 w-full" />
                    <Skeleton className="h-16 w-full" />
                    <Skeleton className="h-16 w-full" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {user.userType === "student" ? (
                      <>
                        <div className="border rounded-md p-4 flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="bg-blue-100 p-3 rounded-full mr-3">
                              <MessageSquareIcon className="h-5 w-5 text-blue-700" />
                            </div>
                            <div>
                              <p className="font-medium">Messages</p>
                              <p className="text-sm text-gray-500">Active conversations</p>
                            </div>
                          </div>
                          <span className="text-2xl font-bold">{stats?.messageCount || 0}</span>
                        </div>
                        
                        <div className="border rounded-md p-4 flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="bg-red-100 p-3 rounded-full mr-3">
                              <HeartIcon className="h-5 w-5 text-red-700" />
                            </div>
                            <div>
                              <p className="font-medium">Favorites</p>
                              <p className="text-sm text-gray-500">Saved properties</p>
                            </div>
                          </div>
                          <span className="text-2xl font-bold">{stats?.favoriteCount || 0}</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="border rounded-md p-4 flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="bg-purple-100 p-3 rounded-full mr-3">
                              <HomeIcon className="h-5 w-5 text-purple-700" />
                            </div>
                            <div>
                              <p className="font-medium">Properties</p>
                              <p className="text-sm text-gray-500">Listed properties</p>
                            </div>
                          </div>
                          <span className="text-2xl font-bold">{stats?.propertyCount || 0}</span>
                        </div>
                        
                        <div className="border rounded-md p-4 flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="bg-blue-100 p-3 rounded-full mr-3">
                              <MessageSquareIcon className="h-5 w-5 text-blue-700" />
                            </div>
                            <div>
                              <p className="font-medium">Inquiries</p>
                              <p className="text-sm text-gray-500">Tenant inquiries</p>
                            </div>
                          </div>
                          <span className="text-2xl font-bold">{stats?.inquiryCount || 0}</span>
                        </div>
                      </>
                    )}
                    
                    <div className="border rounded-md p-4 flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="bg-green-100 p-3 rounded-full mr-3">
                          <CheckCircleIcon className="h-5 w-5 text-green-700" />
                        </div>
                        <div>
                          <p className="font-medium">Status</p>
                          <p className="text-sm text-gray-500">Account status</p>
                        </div>
                      </div>
                      <Badge className={user.isVerified ? "bg-green-100 text-green-800 hover:bg-green-200" : "bg-yellow-100 text-yellow-800 hover:bg-yellow-200"}>
                        {user.isVerified ? "Verified" : "Pending"}
                      </Badge>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {user.userType === "student" ? (
                  <>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start" 
                      onClick={() => navigate('/properties')}
                    >
                      <HomeIcon className="h-4 w-4 mr-2" />
                      Browse Properties
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start" 
                      onClick={() => navigate('/favorites')}
                    >
                      <HeartIcon className="h-4 w-4 mr-2" />
                      My Favorites
                    </Button>
                  </>
                ) : (
                  <>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start" 
                      onClick={() => navigate('/owner/dashboard')}
                    >
                      <HomeIcon className="h-4 w-4 mr-2" />
                      Owner Dashboard
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start" 
                      onClick={() => navigate('/owner/property/add')}
                    >
                      <PlusIcon className="h-4 w-4 mr-2" />
                      Add New Property
                    </Button>
                  </>
                )}
                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  onClick={() => navigate('/chat')}
                >
                  <MessageSquareIcon className="h-4 w-4 mr-2" />
                  Messages
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  onClick={() => navigate('/settings')}
                >
                  <SettingsIcon className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}