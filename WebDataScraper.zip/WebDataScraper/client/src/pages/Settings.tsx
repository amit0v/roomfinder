import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { BellIcon, LockIcon, UserIcon, MailIcon, LoaderIcon, AlertCircleIcon, CheckIcon } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Fetch settings
  const { data: settings, isLoading } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const res = await fetch('/api/settings');
      if (!res.ok) throw new Error('Failed to fetch settings');
      return res.json();
    }
  });

  // Form state
  const [formData, setFormData] = useState({
    emailNotifications: true,
    pushNotifications: false,
    smsNotifications: false,
    darkMode: false,
    language: "english",
    distanceUnit: "miles",
    currency: "usd",
    showContactInfo: true,
    notifyOnNewMessage: true,
    notifyOnPropertyUpdates: true,
    notifyOnFavoriteUpdates: true,
    notifyOnVerificationChanges: true,
    emailFrequency: "immediate",
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  // Update settings on form data load
  useState(() => {
    if (settings) {
      setFormData(prevData => ({
        ...prevData,
        ...settings
      }));
    }
  });

  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/settings', {
        method: 'PATCH',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "Your settings have been saved successfully",
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
    },
    onError: (error: any) => {
      setError(error.message || "Failed to update settings. Please try again.");
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Change password mutation
  const changePasswordMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/user/change-password', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Password changed",
        description: "Your password has been updated successfully",
      });
      setFormData(prev => ({
        ...prev,
        oldPassword: "",
        newPassword: "",
        confirmPassword: "",
      }));
    },
    onError: (error: any) => {
      setError(error.message || "Failed to change password. Please try again.");
      toast({
        title: "Error",
        description: "Failed to change password. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // Handle select changes
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle switch changes
  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      [name]: checked
    }));
  };

  // Save notification settings
  const saveNotificationSettings = () => {
    setError(null);
    
    const notificationSettings = {
      emailNotifications: formData.emailNotifications,
      pushNotifications: formData.pushNotifications,
      smsNotifications: formData.smsNotifications,
      notifyOnNewMessage: formData.notifyOnNewMessage,
      notifyOnPropertyUpdates: formData.notifyOnPropertyUpdates,
      notifyOnFavoriteUpdates: formData.notifyOnFavoriteUpdates,
      notifyOnVerificationChanges: formData.notifyOnVerificationChanges,
      emailFrequency: formData.emailFrequency,
    };
    
    updateSettingsMutation.mutate(notificationSettings);
  };

  // Save preferences settings
  const savePreferencesSettings = () => {
    setError(null);
    
    const preferencesSettings = {
      darkMode: formData.darkMode,
      language: formData.language,
      distanceUnit: formData.distanceUnit,
      currency: formData.currency,
      showContactInfo: formData.showContactInfo,
    };
    
    updateSettingsMutation.mutate(preferencesSettings);
  };

  // Change password
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!formData.oldPassword || !formData.newPassword || !formData.confirmPassword) {
      setError("All password fields are required");
      return;
    }
    
    if (formData.newPassword !== formData.confirmPassword) {
      setError("New passwords do not match");
      return;
    }
    
    if (formData.newPassword.length < 8) {
      setError("New password must be at least 8 characters");
      return;
    }
    
    changePasswordMutation.mutate({
      oldPassword: formData.oldPassword,
      newPassword: formData.newPassword,
    });
  };

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Account Settings</h1>
          <p className="text-gray-600 mt-1">
            Manage your account preferences and settings
          </p>
        </div>

        {savedSuccess && (
          <Alert className="mb-6 bg-green-50 border-green-200">
            <CheckIcon className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">Success</AlertTitle>
            <AlertDescription className="text-green-700">
              Your settings have been saved successfully.
            </AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircleIcon className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="notifications" className="space-y-6">
          <TabsList className="mb-2">
            <TabsTrigger value="notifications" className="flex items-center">
              <BellIcon className="h-4 w-4 mr-2" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="preferences" className="flex items-center">
              <UserIcon className="h-4 w-4 mr-2" />
              Preferences
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center">
              <LockIcon className="h-4 w-4 mr-2" />
              Security
            </TabsTrigger>
          </TabsList>

          {/* Notifications Tab */}
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>
                  Configure how and when you receive notifications
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {isLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                ) : (
                  <>
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Notification Channels</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="flex items-center justify-between space-x-2 p-4 border rounded-md">
                          <div className="space-y-0.5">
                            <Label htmlFor="emailNotifications">Email</Label>
                            <p className="text-sm text-gray-500">Receive email notifications</p>
                          </div>
                          <Switch
                            id="emailNotifications"
                            name="emailNotifications"
                            checked={formData.emailNotifications}
                            onCheckedChange={(checked) => handleSwitchChange("emailNotifications", checked)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between space-x-2 p-4 border rounded-md">
                          <div className="space-y-0.5">
                            <Label htmlFor="pushNotifications">Push</Label>
                            <p className="text-sm text-gray-500">Receive push notifications</p>
                          </div>
                          <Switch
                            id="pushNotifications"
                            name="pushNotifications"
                            checked={formData.pushNotifications}
                            onCheckedChange={(checked) => handleSwitchChange("pushNotifications", checked)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between space-x-2 p-4 border rounded-md">
                          <div className="space-y-0.5">
                            <Label htmlFor="smsNotifications">SMS</Label>
                            <p className="text-sm text-gray-500">Receive SMS notifications</p>
                          </div>
                          <Switch
                            id="smsNotifications"
                            name="smsNotifications"
                            checked={formData.smsNotifications}
                            onCheckedChange={(checked) => handleSwitchChange("smsNotifications", checked)}
                          />
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Notification Types</h3>
                      
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="notifyOnNewMessage">New Messages</Label>
                          <Switch
                            id="notifyOnNewMessage"
                            name="notifyOnNewMessage"
                            checked={formData.notifyOnNewMessage}
                            onCheckedChange={(checked) => handleSwitchChange("notifyOnNewMessage", checked)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <Label htmlFor="notifyOnPropertyUpdates">Property Updates</Label>
                          <Switch
                            id="notifyOnPropertyUpdates"
                            name="notifyOnPropertyUpdates"
                            checked={formData.notifyOnPropertyUpdates}
                            onCheckedChange={(checked) => handleSwitchChange("notifyOnPropertyUpdates", checked)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <Label htmlFor="notifyOnFavoriteUpdates">Favorite Property Updates</Label>
                          <Switch
                            id="notifyOnFavoriteUpdates"
                            name="notifyOnFavoriteUpdates"
                            checked={formData.notifyOnFavoriteUpdates}
                            onCheckedChange={(checked) => handleSwitchChange("notifyOnFavoriteUpdates", checked)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <Label htmlFor="notifyOnVerificationChanges">Verification Status Changes</Label>
                          <Switch
                            id="notifyOnVerificationChanges"
                            name="notifyOnVerificationChanges"
                            checked={formData.notifyOnVerificationChanges}
                            onCheckedChange={(checked) => handleSwitchChange("notifyOnVerificationChanges", checked)}
                          />
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Email Frequency</h3>
                      <RadioGroup 
                        value={formData.emailFrequency}
                        onValueChange={(value) => handleSelectChange("emailFrequency", value)}
                        className="space-y-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="immediate" id="immediate" />
                          <Label htmlFor="immediate">Immediate — Send emails as events happen</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="daily" id="daily" />
                          <Label htmlFor="daily">Daily Digest — Send a daily email with all notifications</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="weekly" id="weekly" />
                          <Label htmlFor="weekly">Weekly Digest — Send a weekly email with all notifications</Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </>
                )}
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={saveNotificationSettings}
                  disabled={updateSettingsMutation.isPending || isLoading}
                >
                  {updateSettingsMutation.isPending ? (
                    <>
                      <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save Notification Settings"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Preferences Tab */}
          <TabsContent value="preferences">
            <Card>
              <CardHeader>
                <CardTitle>Preferences</CardTitle>
                <CardDescription>
                  Customize your viewing preferences and display settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {isLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Appearance</h3>
                        
                        <div className="flex items-center justify-between">
                          <Label htmlFor="darkMode">Dark Mode</Label>
                          <Switch
                            id="darkMode"
                            name="darkMode"
                            checked={formData.darkMode}
                            onCheckedChange={(checked) => handleSwitchChange("darkMode", checked)}
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="language">Language</Label>
                          <Select
                            value={formData.language}
                            onValueChange={(value) => handleSelectChange("language", value)}
                          >
                            <SelectTrigger id="language">
                              <SelectValue placeholder="Select language" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="english">English</SelectItem>
                              <SelectItem value="spanish">Spanish</SelectItem>
                              <SelectItem value="french">French</SelectItem>
                              <SelectItem value="german">German</SelectItem>
                              <SelectItem value="chinese">Chinese</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Regional Settings</h3>
                        
                        <div className="space-y-2">
                          <Label htmlFor="distanceUnit">Distance Unit</Label>
                          <Select
                            value={formData.distanceUnit}
                            onValueChange={(value) => handleSelectChange("distanceUnit", value)}
                          >
                            <SelectTrigger id="distanceUnit">
                              <SelectValue placeholder="Select distance unit" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="miles">Miles</SelectItem>
                              <SelectItem value="kilometers">Kilometers</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="currency">Currency</Label>
                          <Select
                            value={formData.currency}
                            onValueChange={(value) => handleSelectChange("currency", value)}
                          >
                            <SelectTrigger id="currency">
                              <SelectValue placeholder="Select currency" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="usd">USD ($)</SelectItem>
                              <SelectItem value="eur">EUR (€)</SelectItem>
                              <SelectItem value="gbp">GBP (£)</SelectItem>
                              <SelectItem value="cad">CAD (CA$)</SelectItem>
                              <SelectItem value="aud">AUD (AU$)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Privacy</h3>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="showContactInfo">Show Contact Information</Label>
                          <p className="text-sm text-gray-500">Allow property owners to see your contact information</p>
                        </div>
                        <Switch
                          id="showContactInfo"
                          name="showContactInfo"
                          checked={formData.showContactInfo}
                          onCheckedChange={(checked) => handleSwitchChange("showContactInfo", checked)}
                        />
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={savePreferencesSettings}
                  disabled={updateSettingsMutation.isPending || isLoading}
                >
                  {updateSettingsMutation.isPending ? (
                    <>
                      <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save Preferences"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
                <CardDescription>
                  Update your password and manage account security
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <form onSubmit={handleChangePassword} className="space-y-4">
                  <h3 className="text-lg font-medium">Change Password</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="oldPassword">Current Password</Label>
                    <Input
                      id="oldPassword"
                      name="oldPassword"
                      type="password"
                      value={formData.oldPassword}
                      onChange={handleInputChange}
                      placeholder="Enter your current password"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input
                      id="newPassword"
                      name="newPassword"
                      type="password"
                      value={formData.newPassword}
                      onChange={handleInputChange}
                      placeholder="Enter your new password"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      placeholder="Confirm your new password"
                    />
                  </div>
                  
                  <Button 
                    type="submit"
                    disabled={changePasswordMutation.isPending}
                  >
                    {changePasswordMutation.isPending ? (
                      <>
                        <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                        Changing Password...
                      </>
                    ) : (
                      "Change Password"
                    )}
                  </Button>
                </form>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Connected Accounts</h3>
                  <p className="text-sm text-gray-500">
                    Connect your account to other services for easier login and additional features.
                  </p>
                  
                  <div className="space-y-4">
                    <div className="p-4 border rounded-md flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="bg-blue-100 text-blue-600 p-2 rounded-full">
                          <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Facebook</h4>
                          <p className="text-sm text-gray-500">Not connected</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Connect</Button>
                    </div>
                    
                    <div className="p-4 border rounded-md flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="bg-blue-100 text-blue-500 p-2 rounded-full">
                          <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Twitter</h4>
                          <p className="text-sm text-gray-500">Not connected</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Connect</Button>
                    </div>
                    
                    <div className="p-4 border rounded-md flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="bg-red-100 text-red-600 p-2 rounded-full">
                          <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Google</h4>
                          <p className="text-sm text-gray-500">Not connected</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Connect</Button>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Account Security</h3>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Two-Factor Authentication</h4>
                        <p className="text-sm text-gray-500">Add an extra layer of security to your account</p>
                      </div>
                      <Button variant="secondary">Set Up</Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Active Sessions</h4>
                        <p className="text-sm text-gray-500">Manage devices where you're currently logged in</p>
                      </div>
                      <Button variant="secondary">Manage</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}