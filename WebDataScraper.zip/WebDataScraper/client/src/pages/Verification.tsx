import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  ShieldCheckIcon,
  AlertCircleIcon,
  UploadIcon,
  CheckCircleIcon,
  ClockIcon,
  HelpCircleIcon,
  LoaderIcon,
  FileIcon
} from "lucide-react";

// Form validation schema
const documentFormSchema = z.object({
  documentType: z.string().min(1, "Document type is required"),
  documentUrl: z.string().url("Please enter a valid URL")
});

type DocumentFormValues = z.infer<typeof documentFormSchema>;

export default function Verification() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);

  // Form setup with validation
  const form = useForm<DocumentFormValues>({
    resolver: zodResolver(documentFormSchema),
    defaultValues: {
      documentType: "",
      documentUrl: ""
    }
  });

  // Fetch verification status
  const { data: verificationStatus, isLoading } = useQuery({
    queryKey: ['/api/verification/status'],
    queryFn: async () => {
      const res = await fetch('/api/verification/status');
      if (!res.ok) throw new Error('Failed to fetch verification status');
      return res.json();
    }
  });

  // Submit document mutation
  const submitDocumentMutation = useMutation({
    mutationFn: async (data: DocumentFormValues) => {
      return apiRequest('/verification/documents', {
        method: 'POST',
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "Document Submitted",
        description: "Your verification document has been submitted successfully",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/verification/status'] });
    },
    onError: (error: any) => {
      setError(error.message || "Failed to submit document. Please try again.");
      toast({
        title: "Error",
        description: "Failed to submit verification document. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Handle form submission
  const onSubmit = (data: DocumentFormValues) => {
    setError(null);
    submitDocumentMutation.mutate(data);
  };

  // Calculate verification progress
  const calculateVerificationProgress = () => {
    if (!verificationStatus) return 0;
    
    if (verificationStatus.isVerified) return 100;
    
    const documentCount = verificationStatus.documents?.length || 0;
    if (documentCount === 0) return 5; // Just started
    if (documentCount === 1) return 40; // One document
    if (documentCount >= 2) return 80; // Two or more documents
    
    return 0;
  };

  const progress = calculateVerificationProgress();
  const isVerified = verificationStatus?.isVerified || false;
  const documents = verificationStatus?.documents || [];
  const verifiedDocuments = documents.filter((doc: any) => doc.isVerified);
  const pendingDocuments = documents.filter((doc: any) => !doc.isVerified);

  if (isLoading) {
    return (
      <MainLayout>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6">
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-96" />
          </div>
          
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-36" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent className="space-y-6">
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-10 w-36" />
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold">Account Verification</h1>
            <p className="text-gray-600 mt-1">
              Verify your identity to list properties on our platform
            </p>
          </div>
          <Badge
            className={`text-sm px-3 py-1 ${
              isVerified
                ? "bg-green-100 text-green-800 border-green-200"
                : "bg-yellow-100 text-yellow-800 border-yellow-200"
            }`}
          >
            {isVerified ? (
              <span className="flex items-center">
                <CheckCircleIcon className="h-4 w-4 mr-1" />
                Verified Account
              </span>
            ) : (
              <span className="flex items-center">
                <ClockIcon className="h-4 w-4 mr-1" />
                Verification in Progress
              </span>
            )}
          </Badge>
        </div>

        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle>Verification Progress</CardTitle>
            <CardDescription>
              Complete the verification process to unlock all features
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-500">
                <span>Progress</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
              <div className="flex justify-between items-center mt-4">
                <div className="flex items-center text-gray-700">
                  {progress === 0 && (
                    <>
                      <HelpCircleIcon className="h-5 w-5 mr-2 text-gray-400" />
                      <span>Not Started</span>
                    </>
                  )}
                  {progress > 0 && progress < 100 && (
                    <>
                      <ClockIcon className="h-5 w-5 mr-2 text-yellow-500" />
                      <span>In Progress</span>
                    </>
                  )}
                  {progress === 100 && (
                    <>
                      <CheckCircleIcon className="h-5 w-5 mr-2 text-green-500" />
                      <span>Verification Complete</span>
                    </>
                  )}
                </div>
                {isVerified && (
                  <Button size="sm" onClick={() => navigate('/owner/dashboard')}>
                    Go to Dashboard
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue={isVerified ? "status" : "upload"}>
          <TabsList className="mb-4">
            <TabsTrigger value="upload">Upload Documents</TabsTrigger>
            <TabsTrigger value="status">Verification Status</TabsTrigger>
            <TabsTrigger value="faq">FAQ</TabsTrigger>
          </TabsList>

          {/* Upload Documents Tab */}
          <TabsContent value="upload">
            <Card>
              <CardHeader>
                <CardTitle>Submit Verification Documents</CardTitle>
                <CardDescription>
                  Please provide at least two documents to verify your identity
                </CardDescription>
              </CardHeader>
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-6">
                    <AlertCircleIcon className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="mb-6">
                  <h3 className="text-sm font-medium mb-2">Required Documents</h3>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-gray-600">
                    <li>Government-issued ID (driver's license, passport)</li>
                    <li>Proof of address (utility bill, bank statement)</li>
                    <li>For property owners: proof of ownership or rental license</li>
                  </ul>
                </div>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="documentType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Document Type</FormLabel>
                          <FormControl>
                            <select 
                              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                              {...field}
                            >
                              <option value="">Select document type</option>
                              <option value="id">Government ID</option>
                              <option value="utility_bill">Utility Bill</option>
                              <option value="bank_statement">Bank Statement</option>
                              <option value="property_deed">Property Deed</option>
                              <option value="rental_license">Rental License</option>
                              <option value="tax_document">Property Tax Document</option>
                              <option value="other">Other</option>
                            </select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="documentUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Document URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter URL to your uploaded document" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            First upload your document to a cloud storage service (Google Drive, Dropbox, etc.) 
                            and then paste the URL here.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="mt-2"
                      disabled={submitDocumentMutation.isPending}
                    >
                      {submitDocumentMutation.isPending ? (
                        <>
                          <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        <>
                          <UploadIcon className="mr-2 h-4 w-4" />
                          Submit Document
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Verification Status Tab */}
          <TabsContent value="status">
            <Card>
              <CardHeader>
                <CardTitle>Document Status</CardTitle>
                <CardDescription>
                  Track the status of your submitted verification documents
                </CardDescription>
              </CardHeader>
              <CardContent>
                {documents.length === 0 ? (
                  <div className="text-center py-8">
                    <FileIcon className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No documents</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      You haven't submitted any verification documents yet.
                    </p>
                    <div className="mt-6">
                      <Button onClick={() => document.querySelector('[data-value="upload"]')?.click()}>
                        Upload Documents
                      </Button>
                    </div>
                  </div>
                ) : (
                  <ScrollArea className="h-80">
                    <div className="space-y-4">
                      {verifiedDocuments.length > 0 && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-500 mb-2">Verified Documents</h3>
                          <div className="space-y-2">
                            {verifiedDocuments.map((doc: any) => (
                              <div key={doc.id} className="flex items-center p-3 border rounded-md bg-green-50">
                                <CheckCircleIcon className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                                <div>
                                  <p className="font-medium">{doc.documentType.replace('_', ' ')}</p>
                                  <p className="text-xs text-gray-500">
                                    Verified on {new Date(doc.verifiedAt).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {pendingDocuments.length > 0 && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-500 mb-2">Pending Documents</h3>
                          <div className="space-y-2">
                            {pendingDocuments.map((doc: any) => (
                              <div key={doc.id} className="flex items-center p-3 border rounded-md bg-yellow-50">
                                <ClockIcon className="h-5 w-5 text-yellow-500 mr-3 flex-shrink-0" />
                                <div>
                                  <p className="font-medium">{doc.documentType.replace('_', ' ')}</p>
                                  <p className="text-xs text-gray-500">
                                    Submitted on {new Date(doc.createdAt).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
              <CardFooter className="bg-gray-50 border-t px-6 py-4">
                <div className="flex items-center text-sm text-gray-600">
                  <AlertCircleIcon className="h-4 w-4 mr-2 text-blue-500" />
                  <p>
                    Verification typically takes 1-3 business days. You will receive an email notification once your account is verified.
                  </p>
                </div>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* FAQ Tab */}
          <TabsContent value="faq">
            <Card>
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
                <CardDescription>
                  Common questions about our verification process
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Why do I need to verify my account?</h3>
                    <p className="text-gray-600">
                      Account verification helps us maintain a secure platform where students can find legitimate
                      rental properties from verified owners. This protects both property owners and students
                      from potential fraud.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">What documents do I need to provide?</h3>
                    <p className="text-gray-600 mb-3">
                      To complete verification, you'll need to provide at least two of the following:
                    </p>
                    <ul className="list-disc pl-5 space-y-1 text-sm text-gray-600">
                      <li>Government-issued ID (driver's license, passport, ID card)</li>
                      <li>Proof of address (utility bill, bank statement dated within past 3 months)</li>
                      <li>Property ownership documentation (deed, recent tax bill, rental license)</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">How long does verification take?</h3>
                    <p className="text-gray-600">
                      Our team typically reviews verification documents within 1-3 business days. You'll 
                      receive an email notification once your account is verified.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Is my information secure?</h3>
                    <p className="text-gray-600">
                      Yes, we take your privacy seriously. All documents are stored securely and
                      are only accessible to our verification team. Your personal information is never 
                      shared with third parties without your consent.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">What if my verification is rejected?</h3>
                    <p className="text-gray-600">
                      If your verification is rejected, you'll receive an email explaining why. Common reasons 
                      include unclear/unreadable documents or expired documentation. You can submit new documents 
                      to restart the verification process.
                    </p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 border-t px-6 py-4">
                <div className="flex items-center text-sm text-gray-600">
                  <ShieldCheckIcon className="h-4 w-4 mr-2 text-indigo-500" />
                  <p>
                    Still have questions? Contact our support team at support@roomfinder.com
                  </p>
                </div>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}