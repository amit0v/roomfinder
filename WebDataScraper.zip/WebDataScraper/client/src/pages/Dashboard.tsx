import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/Sidebar";
import TopNav from "@/components/layout/TopNav";
import MobileNav from "@/components/layout/MobileNav";
import StatsCard from "@/components/dashboard/StatsCard";
import ScraperCard from "@/components/dashboard/ScraperCard";
import TasksTable from "@/components/dashboard/TasksTable";
import ScraperModal from "@/components/modals/ScraperModal";
import DataPreviewModal from "@/components/modals/DataPreviewModal";
import { ScraperType, ScraperTask, ScrapedData } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { useMobile } from "@/hooks/use-mobile";

export default function Dashboard() {
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
  const [scraperModalOpen, setScraperModalOpen] = useState(false);
  const [dataModalOpen, setDataModalOpen] = useState(false);
  const [selectedScraperType, setSelectedScraperType] = useState<ScraperType | null>(null);
  const [selectedTask, setSelectedTask] = useState<ScraperTask | null>(null);
  const { toast } = useToast();

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
  });

  const { data: tasks } = useQuery({
    queryKey: ["/api/tasks"],
  });

  const { data: taskData } = useQuery({
    queryKey: ["/api/tasks/data", selectedTask?.id],
    enabled: !!selectedTask,
  });

  useEffect(() => {
    setSidebarOpen(!isMobile);
  }, [isMobile]);

  const handleToggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleOpenScraperModal = (type: ScraperType) => {
    setSelectedScraperType(type);
    setScraperModalOpen(true);
  };

  const handleViewTaskData = (task: ScraperTask) => {
    setSelectedTask(task);
    setDataModalOpen(true);
  };

  const handleTaskAction = (action: string, task: ScraperTask) => {
    toast({
      title: `Task ${action}`,
      description: `Task "${task.name}" has been ${action.toLowerCase()}.`,
    });
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar 
        isOpen={sidebarOpen} 
        closeSidebar={() => setSidebarOpen(false)} 
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav 
          toggleSidebar={handleToggleSidebar} 
        />
        
        <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900 p-4 md:p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-2">Dashboard</h1>
            <p className="text-gray-600 dark:text-gray-400">Create and manage your data scraping tasks</p>
          </div>
          
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <StatsCard 
              title="Active Tasks"
              value={stats?.activeTasks || 0}
              icon="ri-time-line"
              color="blue"
            />
            <StatsCard 
              title="Data Collected" 
              value={stats?.dataCollected || "0"}
              icon="ri-database-2-line"
              color="green"
            />
            <StatsCard 
              title="API Credits" 
              value={stats?.apiCredits || 0}
              icon="ri-pie-chart-line"
              color="purple"
            />
          </div>
          
          {/* Create New Scraper Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Create New Scraper</h2>
              <button className="text-sm text-primary hover:underline">
                View templates
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <ScraperCard
                title="Web Scraper"
                description="Extract data from websites and HTML pages with advanced selectors"
                icon="ri-global-line"
                color="primary"
                onClick={() => handleOpenScraperModal("web")}
              />
              <ScraperCard
                title="Twitter/X Data"
                description="Collect tweets, profiles, and trends using the Twitter/X API"
                icon="ri-twitter-x-line"
                color="blue"
                onClick={() => handleOpenScraperModal("twitter")}
              />
              <ScraperCard
                title="API Connector"
                description="Connect to external APIs and transform data into structured formats"
                icon="ri-file-list-3-line"
                color="green"
                onClick={() => handleOpenScraperModal("api")}
              />
            </div>
          </div>
          
          {/* Active Tasks Section */}
          <TasksTable 
            tasks={tasks || []} 
            onTaskAction={handleTaskAction}
            onViewData={handleViewTaskData}
          />
        </main>
        
        {isMobile && <MobileNav />}
      </div>
      
      {scraperModalOpen && (
        <ScraperModal
          type={selectedScraperType!}
          onClose={() => setScraperModalOpen(false)}
        />
      )}
      
      {dataModalOpen && selectedTask && (
        <DataPreviewModal
          task={selectedTask}
          data={taskData as ScrapedData}
          onClose={() => setDataModalOpen(false)}
        />
      )}
    </div>
  );
}
