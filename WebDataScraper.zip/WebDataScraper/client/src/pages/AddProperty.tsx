import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircleIcon, LoaderIcon, Trash2Icon, PlusIcon } from "lucide-react";

// Form validation schema
const propertyFormSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  address: z.string().min(5, "Address must be at least 5 characters"),
  city: z.string().min(2, "City is required"),
  state: z.string().min(2, "State is required"),
  zipCode: z.string().min(5, "Zip code is required"),
  latitude: z.coerce.number().optional(),
  longitude: z.coerce.number().optional(),
  propertyType: z.enum(["apartment", "house", "room", "studio"]),
  monthlyRent: z.coerce.number().positive("Monthly rent must be greater than 0"),
  securityDeposit: z.coerce.number().positive("Security deposit must be greater than 0").optional(),
  bedrooms: z.coerce.number().min(0, "Bedrooms must be 0 or greater"),
  bathrooms: z.coerce.number().min(0.5, "Bathrooms must be 0.5 or greater"),
  squareFeet: z.coerce.number().positive("Square feet must be greater than 0").optional(),
  isFurnished: z.boolean().default(false),
  hasParking: z.boolean().default(false),
  petsAllowed: z.boolean().default(false),
  availableFrom: z.string(),
  availableUntil: z.string().optional(),
  images: z.array(z.string()).optional(),
  amenities: z.array(z.string()).optional(),
});

type PropertyFormValues = z.infer<typeof propertyFormSchema>;

export default function AddProperty() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [imageUrls, setImageUrls] = useState<string[]>([""]);
  const [amenities, setAmenities] = useState<string[]>([""]);
  const [error, setError] = useState<string | null>(null);

  // Form setup with validation
  const form = useForm<PropertyFormValues>({
    resolver: zodResolver(propertyFormSchema),
    defaultValues: {
      title: "",
      description: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      propertyType: "apartment",
      monthlyRent: 0,
      securityDeposit: 0,
      bedrooms: 1,
      bathrooms: 1,
      squareFeet: 0,
      isFurnished: false,
      hasParking: false,
      petsAllowed: false,
      availableFrom: new Date().toISOString().split("T")[0],
      images: [],
      amenities: [],
    },
  });

  // Create property mutation
  const createPropertyMutation = useMutation({
    mutationFn: async (data: PropertyFormValues) => {
      return apiRequest("/properties", {
        method: "POST",
        body: JSON.stringify({
          ...data,
          images: imageUrls.filter(url => url.trim() !== ""),
          amenities: amenities.filter(amenity => amenity.trim() !== ""),
        }),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Property Created",
        description: "Your property listing has been created successfully",
      });
      navigate(`/owner/dashboard`);
    },
    onError: (error: any) => {
      setError(error.message || "Failed to create property. Please try again.");
      toast({
        title: "Error",
        description: "Failed to create property. Please check the form and try again.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = async (data: PropertyFormValues) => {
    setError(null);
    
    // Validate images and amenities
    const filteredImages = imageUrls.filter(url => url.trim() !== "");
    const filteredAmenities = amenities.filter(amenity => amenity.trim() !== "");
    
    if (filteredImages.length === 0) {
      setError("Please add at least one property image");
      return;
    }
    
    // Update form data with images and amenities
    data.images = filteredImages;
    data.amenities = filteredAmenities;
    
    createPropertyMutation.mutate(data);
  };

  // Handle image URL changes
  const handleImageUrlChange = (index: number, value: string) => {
    const newImageUrls = [...imageUrls];
    newImageUrls[index] = value;
    setImageUrls(newImageUrls);
  };

  // Add image URL field
  const addImageUrl = () => {
    setImageUrls([...imageUrls, ""]);
  };

  // Remove image URL field
  const removeImageUrl = (index: number) => {
    if (imageUrls.length > 1) {
      const newImageUrls = [...imageUrls];
      newImageUrls.splice(index, 1);
      setImageUrls(newImageUrls);
    }
  };

  // Handle amenity changes
  const handleAmenityChange = (index: number, value: string) => {
    const newAmenities = [...amenities];
    newAmenities[index] = value;
    setAmenities(newAmenities);
  };

  // Add amenity field
  const addAmenity = () => {
    setAmenities([...amenities, ""]);
  };

  // Remove amenity field
  const removeAmenity = (index: number) => {
    if (amenities.length > 1) {
      const newAmenities = [...amenities];
      newAmenities.splice(index, 1);
      setAmenities(newAmenities);
    }
  };

  // Try to get geolocation based on address
  const getGeolocation = async () => {
    const address = form.getValues("address");
    const city = form.getValues("city");
    const state = form.getValues("state");
    const zipCode = form.getValues("zipCode");
    
    if (!address || !city || !state) {
      toast({
        title: "Missing Address Information",
        description: "Please fill in the address, city, and state fields before fetching coordinates.",
        variant: "destructive",
      });
      return;
    }
    
    // In a real app, you would use a geocoding service like Google Maps API
    // For this demo, we'll just set some random coordinates
    toast({
      title: "Geolocation",
      description: "In a production app, this would use a real geocoding service to get coordinates.",
    });
    
    // Set random coordinates for demonstration
    form.setValue("latitude", 34.0522 + Math.random() * 0.02);
    form.setValue("longitude", -118.2437 + Math.random() * 0.02);
  };

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Add New Property</h1>
          <p className="text-gray-600 mt-2">
            Fill in the details below to create a new property listing
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Property Information</CardTitle>
            <CardDescription>
              Provide accurate information to attract potential renters
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-6">
                <AlertCircleIcon className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                {/* Basic Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Basic Details</h3>
                  
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Property Title</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Cozy 2-Bedroom Apartment Near Campus" {...field} />
                        </FormControl>
                        <FormDescription>
                          A descriptive title to attract tenants
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Property Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe your property in detail..." 
                            {...field} 
                            className="min-h-32"
                          />
                        </FormControl>
                        <FormDescription>
                          Include details about features, nearby amenities, and any special offerings
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="propertyType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Property Type</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select property type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="apartment">Apartment</SelectItem>
                              <SelectItem value="house">House</SelectItem>
                              <SelectItem value="room">Room</SelectItem>
                              <SelectItem value="studio">Studio</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="monthlyRent"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Monthly Rent ($)</FormLabel>
                          <FormControl>
                            <Input type="number" min="0" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="bedrooms"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bedrooms</FormLabel>
                          <FormControl>
                            <Input type="number" min="0" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="bathrooms"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bathrooms</FormLabel>
                          <FormControl>
                            <Input type="number" min="0.5" step="0.5" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="squareFeet"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Square Feet</FormLabel>
                          <FormControl>
                            <Input type="number" min="0" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="securityDeposit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Security Deposit ($)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <Separator />
                
                {/* Location */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Location</h3>
                  
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Street Address</FormLabel>
                        <FormControl>
                          <Input placeholder="123 Main St" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>City</FormLabel>
                          <FormControl>
                            <Input placeholder="City" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="state"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>State</FormLabel>
                          <FormControl>
                            <Input placeholder="State" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="zipCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Zip Code</FormLabel>
                          <FormControl>
                            <Input placeholder="Zip Code" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="latitude"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Latitude</FormLabel>
                          <FormControl>
                            <Input type="number" step="any" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="longitude"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Longitude</FormLabel>
                          <FormControl>
                            <Input type="number" step="any" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={getGeolocation}
                  >
                    Get Coordinates from Address
                  </Button>
                </div>
                
                <Separator />
                
                {/* Features and Availability */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Features and Availability</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="isFurnished"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                          <div className="space-y-0.5">
                            <FormLabel>Furnished</FormLabel>
                            <FormDescription>
                              Property comes with furniture
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="hasParking"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                          <div className="space-y-0.5">
                            <FormLabel>Parking</FormLabel>
                            <FormDescription>
                              Parking available on premises
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="petsAllowed"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                          <div className="space-y-0.5">
                            <FormLabel>Pets Allowed</FormLabel>
                            <FormDescription>
                              Property allows pets
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="availableFrom"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Available From</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="availableUntil"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Available Until (Optional)</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <Separator />
                
                {/* Images */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">Property Images</h3>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addImageUrl}
                    >
                      <PlusIcon className="h-4 w-4 mr-2" />
                      Add Image
                    </Button>
                  </div>
                  
                  <div className="space-y-4">
                    {imageUrls.map((url, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Input
                          placeholder="Image URL"
                          value={url}
                          onChange={(e) => handleImageUrlChange(index, e.target.value)}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeImageUrl(index)}
                          disabled={imageUrls.length === 1}
                        >
                          <Trash2Icon className="h-4 w-4 text-gray-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  <FormDescription>
                    Add URLs to images of your property. The first image will be the featured image.
                  </FormDescription>
                </div>
                
                <Separator />
                
                {/* Amenities */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">Amenities</h3>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addAmenity}
                    >
                      <PlusIcon className="h-4 w-4 mr-2" />
                      Add Amenity
                    </Button>
                  </div>
                  
                  <div className="space-y-4">
                    {amenities.map((amenity, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Input
                          placeholder="Amenity name"
                          value={amenity}
                          onChange={(e) => handleAmenityChange(index, e.target.value)}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeAmenity(index)}
                          disabled={amenities.length === 1}
                        >
                          <Trash2Icon className="h-4 w-4 text-gray-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  <FormDescription>
                    Add amenities available at your property (e.g., Wi-Fi, Air Conditioning, Gym).
                  </FormDescription>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={createPropertyMutation.isPending}
                >
                  {createPropertyMutation.isPending ? (
                    <>
                      <LoaderIcon className="mr-2 h-4 w-4 animate-spin" />
                      Creating Property...
                    </>
                  ) : (
                    "Create Property Listing"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={() => navigate('/owner/dashboard')}
            >
              Cancel
            </Button>
          </CardFooter>
        </Card>
      </div>
    </MainLayout>
  );
}