import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    try {
      const errorData = await res.json();
      throw new Error(errorData.error || `Request failed with status ${res.status}`);
    } catch (e) {
      // If we can't parse the JSON, just throw with status
      if (e instanceof SyntaxError) {
        const text = await res.text() || res.statusText;
        throw new Error(`${res.status}: ${text}`);
      }
      throw e;
    }
  }
}

export async function apiRequest(
  url: string,
  options: RequestInit = {},
): Promise<any> {
  const baseUrl = "/api";
  const res = await fetch(`${baseUrl}${url.startsWith("/") ? url : `/${url}`}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
    credentials: "include",
  });

  await throwIfResNotOk(res);

  // Check if the response has content
  const contentType = res.headers.get("content-type");
  if (contentType && contentType.includes("application/json")) {
    return await res.json();
  }

  return await res.text();
}

// Default fetch function for React Query
export const defaultQueryFn = async ({ queryKey }: { queryKey: any[] }) => {
  // The first item in the query key should be the URL
  const url = queryKey[0] as string;
  
  // Any params would be in the second item
  const params = queryKey[1] || {};
  
  // For GET requests, convert params to URL parameters
  if (Object.keys(params).length > 0) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        if (Array.isArray(value)) {
          value.forEach(v => searchParams.append(key, String(v)));
        } else {
          searchParams.append(key, String(value));
        }
      }
    });
    
    // Append parameters to URL
    const queryString = searchParams.toString();
    if (queryString) {
      const hasQueryParams = url.includes('?');
      const connector = hasQueryParams ? '&' : '?';
      const finalUrl = `${url}${connector}${queryString}`;
      const res = await fetch(finalUrl, { credentials: "include" });
      await throwIfResNotOk(res);
      return res.json();
    }
  }
  
  const res = await fetch(url, { credentials: "include" });
  await throwIfResNotOk(res);
  return res.json();
};

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: defaultQueryFn,
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: 60000, // 1 minute
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
