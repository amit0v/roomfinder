import { useEffect, useRef } from 'react';

export function useWebSocket<T>(
  onMessage: (data: T) => void,
  onError?: (error: Event) => void,
  onOpen?: () => void,
  onClose?: () => void
) {
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    // Determine if we're using https or http and set the appropriate WebSocket protocol
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    // Create WebSocket connection
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;

    // Set up event listeners
    socket.addEventListener('open', () => {
      console.log('WebSocket connection established');
      // Send auth message with user ID (in a real app, this would be from auth context)
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: 'auth', userId: 1 }));
      }
      if (onOpen) onOpen();
    });

    socket.addEventListener('message', (event) => {
      try {
        const data = JSON.parse(event.data);
        onMessage(data);
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });

    socket.addEventListener('error', (error) => {
      console.error('WebSocket error:', error);
      if (onError) onError(error);
    });

    socket.addEventListener('close', (event) => {
      console.log('WebSocket connection closed:', event.code, event.reason);
      if (onClose) onClose();
    });

    // Clean up function
    return () => {
      if (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING) {
        console.log('Closing WebSocket connection');
        socket.close();
      }
    };
  }, []); // Empty deps array means this effect runs once on mount

  // Return a function to send messages
  const sendMessage = (data: any) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(data));
    } else {
      console.warn('WebSocket not connected, message not sent');
    }
  };

  return { sendMessage };
}