import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useTaskData(taskId?: number) {
  const { toast } = useToast();
  
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/tasks/data", taskId],
    enabled: !!taskId,
  });
  
  const refreshDataMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest("POST", `/api/tasks/${id}/refresh`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/data", taskId] });
      toast({
        title: "Data refreshed",
        description: "The latest data has been fetched successfully.",
      });
    },
  });
  
  const exportDataMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest("GET", `/api/tasks/${id}/export`),
    onSuccess: async (response) => {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `task_${taskId}_data.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast({
        title: "Export successful",
        description: "Data has been exported successfully.",
      });
    },
  });
  
  return {
    data,
    isLoading,
    error,
    refreshData: (id: number) => refreshDataMutation.mutate(id),
    exportData: (id: number) => exportDataMutation.mutate(id),
    isRefreshing: refreshDataMutation.isPending,
    isExporting: exportDataMutation.isPending,
  };
}
