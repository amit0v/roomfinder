import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { ThemeProvider } from "@/components/ThemeProvider";
import Home from "@/pages/Home";
import Properties from "@/pages/Properties";
import PropertyDetails from "@/pages/PropertyDetails";
import Chat from "@/pages/Chat";
import Favorites from "@/pages/Favorites";
import Profile from "@/pages/Profile";
import Settings from "@/pages/Settings";
import Register from "@/pages/Register";
import Login from "@/pages/Login";
import OwnerDashboard from "@/pages/OwnerDashboard";
import AddProperty from "@/pages/AddProperty";
import EditProperty from "@/pages/EditProperty";
import Verification from "@/pages/Verification";

function Router() {
  // We would normally check for auth state here
  const isAuthenticated = true; // For demo purposes, we'll assume the user is authenticated
  const userType = "student"; // "student" or "owner"
  
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={Home} />
      <Route path="/properties" component={Properties} />
      <Route path="/property/:id" component={PropertyDetails} />
      <Route path="/register" component={Register} />
      <Route path="/login" component={Login} />
      
      {/* Protected Routes - in a real app, we'd check authentication */}
      <Route path="/chat" component={Chat} />
      <Route path="/chat/:id" component={Chat} />
      <Route path="/favorites" component={Favorites} />
      <Route path="/profile" component={Profile} />
      <Route path="/settings" component={Settings} />
      
      {/* Owner-specific Routes */}
      <Route path="/owner/dashboard" component={OwnerDashboard} />
      <Route path="/owner/property/add" component={AddProperty} />
      <Route path="/owner/property/edit/:id" component={EditProperty} />
      <Route path="/owner/verification" component={Verification} />
      
      {/* Fallback Route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="roomfinder-theme">
        <Router />
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
