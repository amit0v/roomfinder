import { db } from "./index";
import * as schema from "@shared/schema";
import { hashSync } from "bcrypt";

async function seed() {
  try {
    // Check if we already have users
    const existingUsers = await db.query.users.findMany({
      limit: 1
    });

    if (existingUsers.length === 0) {
      console.log("Seeding database with initial data...");
      
      // Create demo student user
      const [studentUser] = await db.insert(schema.users).values({
        username: "student1",
        password: hashSync("student123", 10),
        email: "student1@example.com",
        fullName: "Alex Johnson",
        phone: "555-123-4567",
        userType: "student",
        isVerified: true,
        profileImage: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex"
      }).returning();
      
      console.log(`Created student user with ID: ${studentUser.id}`);
      
      // Create demo property owner user
      const [ownerUser] = await db.insert(schema.users).values({
        username: "owner1",
        password: hashSync("owner123", 10),
        email: "owner1@example.com",
        fullName: "Morgan Smith",
        phone: "555-987-6543",
        userType: "owner",
        isVerified: true,
        profileImage: "https://api.dicebear.com/7.x/avataaars/svg?seed=Morgan"
      }).returning();
      
      console.log(`Created owner user with ID: ${ownerUser.id}`);
      
      // Create verification documents for owner
      await db.insert(schema.verificationDocuments).values([
        {
          userId: ownerUser.id,
          documentType: "id",
          documentUrl: "https://example.com/verification/id.jpg",
          isVerified: true,
          verifiedAt: new Date()
        },
        {
          userId: ownerUser.id,
          documentType: "utility_bill",
          documentUrl: "https://example.com/verification/utility.jpg",
          isVerified: true,
          verifiedAt: new Date()
        }
      ]);
      
      console.log("Created verification documents for owner");
      
      // Create sample properties
      const properties = await db.insert(schema.properties).values([
        {
          ownerId: ownerUser.id,
          title: "Cozy Studio Near University",
          description: "Bright and modern studio apartment perfect for students. Located just 5 minutes walk from the main campus. Includes all utilities and high-speed internet.",
          address: "123 University Ave",
          city: "College Town",
          state: "CA",
          zipCode: "90210",
          latitude: 34.052235,
          longitude: -118.243683,
          propertyType: "studio",
          monthlyRent: 950,
          securityDeposit: 950,
          bedrooms: 0,
          bathrooms: 1.0,
          squareFeet: 450,
          isFurnished: true,
          hasParking: true,
          petsAllowed: false,
          availableFrom: new Date("2025-06-01"),
          status: "available"
        },
        {
          ownerId: ownerUser.id,
          title: "Shared 2-Bedroom Apartment with Balcony",
          description: "Looking for a roommate to share this beautiful 2-bedroom apartment. Private bedroom and shared common areas. Great neighborhood with restaurants and shops nearby.",
          address: "456 College Blvd",
          city: "College Town",
          state: "CA",
          zipCode: "90211",
          latitude: 34.053255,
          longitude: -118.245664,
          propertyType: "apartment",
          monthlyRent: 750,
          securityDeposit: 750,
          bedrooms: 2,
          bathrooms: 1.5,
          squareFeet: 850,
          isFurnished: false,
          hasParking: true,
          petsAllowed: true,
          availableFrom: new Date("2025-05-15"),
          status: "available"
        },
        {
          ownerId: ownerUser.id,
          title: "Private Room in Modern House",
          description: "Furnished private room in a modern house shared with other students. Includes utilities, internet, laundry facilities, and access to a fully equipped kitchen.",
          address: "789 Student Lane",
          city: "College Town",
          state: "CA",
          zipCode: "90212",
          latitude: 34.054248,
          longitude: -118.247852,
          propertyType: "room",
          monthlyRent: 650,
          securityDeposit: 650,
          bedrooms: 1,
          bathrooms: 1.0,
          squareFeet: 200,
          isFurnished: true,
          hasParking: false,
          petsAllowed: false,
          availableFrom: new Date("2025-05-01"),
          status: "available"
        }
      ]).returning();
      
      console.log(`Created ${properties.length} sample properties`);
      
      // Create property images
      for (const property of properties) {
        await db.insert(schema.propertyImages).values([
          {
            propertyId: property.id,
            imageUrl: `https://source.unsplash.com/random/800x600?apartment&sig=${property.id}1`,
            isFeatured: true
          },
          {
            propertyId: property.id,
            imageUrl: `https://source.unsplash.com/random/800x600?livingroom&sig=${property.id}2`,
            isFeatured: false
          },
          {
            propertyId: property.id,
            imageUrl: `https://source.unsplash.com/random/800x600?kitchen&sig=${property.id}3`,
            isFeatured: false
          }
        ]);
      }
      
      console.log("Created property images");
      
      // Create property amenities
      const amenitiesSet = [
        ["High-speed internet", "Air conditioning", "Heating", "Laundry facilities"],
        ["High-speed internet", "Pool", "Gym", "Parking", "Security system"],
        ["High-speed internet", "Air conditioning", "Heating", "Shared kitchen", "Study room"]
      ];
      
      for (let i = 0; i < properties.length; i++) {
        const amenities = amenitiesSet[i];
        for (const name of amenities) {
          await db.insert(schema.propertyAmenities).values({
            propertyId: properties[i].id,
            name
          });
        }
      }
      
      console.log("Created property amenities");
      
      // Create a chat room
      const [chatRoom] = await db.insert(schema.chatRooms).values({
        propertyId: properties[0].id,
        studentId: studentUser.id,
        ownerId: ownerUser.id,
        lastMessageAt: new Date()
      }).returning();
      
      console.log(`Created chat room with ID: ${chatRoom.id}`);
      
      // Create chat messages
      const currentTime = new Date();
      await db.insert(schema.chatMessages).values([
        {
          chatRoomId: chatRoom.id,
          senderId: studentUser.id,
          message: "Hi, I'm interested in this studio. Is it still available?",
          isRead: true,
          createdAt: new Date(currentTime.getTime() - 3 * 24 * 60 * 60 * 1000) // 3 days ago
        },
        {
          chatRoomId: chatRoom.id,
          senderId: ownerUser.id,
          message: "Yes, it's still available! When would you like to view it?",
          isRead: true,
          createdAt: new Date(currentTime.getTime() - 2 * 24 * 60 * 60 * 1000) // 2 days ago
        },
        {
          chatRoomId: chatRoom.id,
          senderId: studentUser.id,
          message: "Great! Would this Friday at 3 PM work for you?",
          isRead: true,
          createdAt: new Date(currentTime.getTime() - 1 * 24 * 60 * 60 * 1000) // 1 day ago
        },
        {
          chatRoomId: chatRoom.id,
          senderId: ownerUser.id,
          message: "Friday at 3 PM works perfectly. I'll meet you at the property. Let me know if you need directions.",
          isRead: false,
          createdAt: new Date(currentTime.getTime() - 12 * 60 * 60 * 1000) // 12 hours ago
        }
      ]);
      
      console.log("Created chat messages");
      
      // Add a property to student's favorites
      await db.insert(schema.favorites).values({
        userId: studentUser.id,
        propertyId: properties[0].id
      });
      
      console.log("Added property to student's favorites");
      
      // Create settings for users
      await db.insert(schema.settings).values([
        {
          userId: studentUser.id,
          notificationsEnabled: true,
          emailAlerts: true,
          darkMode: false
        },
        {
          userId: ownerUser.id,
          notificationsEnabled: true,
          emailAlerts: true,
          darkMode: true
        }
      ]);
      
      console.log("Created settings for users");
      
      // Add a review for one of the properties
      await db.insert(schema.propertyReviews).values({
        propertyId: properties[2].id,
        userId: studentUser.id,
        rating: 4,
        comment: "Great location and clean space. Very convenient for university students."
      });
      
      console.log("Created property review");
      
      console.log("Database seeded successfully.");
    } else {
      console.log("Database already has data, skipping seed.");
    }
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
