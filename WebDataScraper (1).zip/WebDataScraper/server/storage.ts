import { db } from "@db";
import * as schema from "@shared/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import type { Task, ScrapedData, ApiKey, Settings } from "@shared/schema";
import { hashSync, compareSync } from "bcrypt";

// User methods
export const storage = {
  // User methods
  async getUserById(id: number) {
    return await db.query.users.findFirst({
      where: eq(schema.users.id, id)
    });
  },

  async getUserByUsername(username: string) {
    return await db.query.users.findFirst({
      where: eq(schema.users.username, username)
    });
  },

  async getUserByEmail(email: string) {
    return await db.query.users.findFirst({
      where: eq(schema.users.email, email)
    });
  },

  async createUser(username: string, email: string, password: string) {
    const hashedPassword = hashSync(password, 10);
    const [user] = await db.insert(schema.users).values({
      username,
      email,
      password: hashedPassword
    }).returning();
    
    // Create default settings for new user
    await db.insert(schema.settings).values({
      userId: user.id,
      notifications: true,
      dataRetention: 30,
      proxyEnabled: false
    });
    
    return user;
  },

  async validateUser(username: string, password: string) {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const isValid = compareSync(password, user.password);
    return isValid ? user : null;
  },

  // Task methods
  async getAllTasks(userId: number): Promise<Task[]> {
    return await db.query.tasks.findMany({
      where: eq(schema.tasks.userId, userId),
      orderBy: [desc(schema.tasks.updatedAt)]
    });
  },

  async getTasksByStatus(userId: number, status: string): Promise<Task[]> {
    return await db.query.tasks.findMany({
      where: and(
        eq(schema.tasks.userId, userId),
        eq(schema.tasks.status, status)
      ),
      orderBy: [desc(schema.tasks.updatedAt)]
    });
  },

  async getTaskById(id: number, userId: number): Promise<Task | null> {
    return await db.query.tasks.findFirst({
      where: and(
        eq(schema.tasks.id, id),
        eq(schema.tasks.userId, userId)
      )
    });
  },

  async createTask(userId: number, task: Omit<schema.InsertTask, "userId">): Promise<Task> {
    const [newTask] = await db.insert(schema.tasks).values({
      ...task,
      userId
    }).returning();
    return newTask;
  },

  async updateTask(id: number, userId: number, updates: Partial<Task>): Promise<Task | null> {
    const [updatedTask] = await db.update(schema.tasks)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(
        and(
          eq(schema.tasks.id, id),
          eq(schema.tasks.userId, userId)
        )
      )
      .returning();
      
    return updatedTask || null;
  },

  async updateTaskStatus(id: number, userId: number, status: string): Promise<Task | null> {
    return await this.updateTask(id, userId, { status });
  },

  async incrementTaskDataPoints(id: number, userId: number, count: number): Promise<Task | null> {
    const [updatedTask] = await db.update(schema.tasks)
      .set({
        dataPoints: sql`${schema.tasks.dataPoints} + ${count}`,
        lastRun: new Date(),
        updatedAt: new Date()
      })
      .where(
        and(
          eq(schema.tasks.id, id),
          eq(schema.tasks.userId, userId)
        )
      )
      .returning();
      
    return updatedTask || null;
  },

  async deleteTask(id: number, userId: number): Promise<boolean> {
    // First delete associated scraped data
    await db.delete(schema.scrapedData)
      .where(eq(schema.scrapedData.taskId, id));
      
    // Then delete the task
    const result = await db.delete(schema.tasks)
      .where(
        and(
          eq(schema.tasks.id, id),
          eq(schema.tasks.userId, userId)
        )
      );
      
    return result.rowCount > 0;
  },

  // Scraped data methods
  async getScrapedData(taskId: number, userId: number): Promise<ScrapedData | null> {
    // First verify the task belongs to the user
    const task = await this.getTaskById(taskId, userId);
    if (!task) return null;
    
    return await db.query.scrapedData.findFirst({
      where: eq(schema.scrapedData.taskId, taskId),
      orderBy: [desc(schema.scrapedData.createdAt)]
    });
  },

  async saveScrapedData(taskId: number, userId: number, data: any): Promise<ScrapedData | null> {
    // First verify the task belongs to the user
    const task = await this.getTaskById(taskId, userId);
    if (!task) return null;
    
    const [newData] = await db.insert(schema.scrapedData).values({
      taskId,
      data
    }).returning();
    
    // Update task data points and last run
    await this.incrementTaskDataPoints(taskId, userId, Array.isArray(data) ? data.length : 1);
    
    return newData;
  },

  // API key methods
  async getApiKeys(userId: number): Promise<ApiKey[]> {
    return await db.query.apiKeys.findMany({
      where: eq(schema.apiKeys.userId, userId),
      orderBy: [desc(schema.apiKeys.createdAt)]
    });
  },

  async getApiKeyById(id: number, userId: number): Promise<ApiKey | null> {
    return await db.query.apiKeys.findFirst({
      where: and(
        eq(schema.apiKeys.id, id),
        eq(schema.apiKeys.userId, userId)
      )
    });
  },

  async getApiKeyByService(userId: number, service: string): Promise<ApiKey | null> {
    return await db.query.apiKeys.findFirst({
      where: and(
        eq(schema.apiKeys.userId, userId),
        eq(schema.apiKeys.service, service)
      )
    });
  },

  async createApiKey(userId: number, service: string, key: string): Promise<ApiKey> {
    // Check if key already exists for this service
    const existingKey = await this.getApiKeyByService(userId, service);
    
    if (existingKey) {
      // Update existing key
      const [updatedKey] = await db.update(schema.apiKeys)
        .set({ key })
        .where(
          and(
            eq(schema.apiKeys.userId, userId),
            eq(schema.apiKeys.service, service)
          )
        )
        .returning();
        
      return updatedKey;
    } else {
      // Create new key
      const [newKey] = await db.insert(schema.apiKeys).values({
        userId,
        service,
        key
      }).returning();
      
      return newKey;
    }
  },

  async deleteApiKey(id: number, userId: number): Promise<boolean> {
    const result = await db.delete(schema.apiKeys)
      .where(
        and(
          eq(schema.apiKeys.id, id),
          eq(schema.apiKeys.userId, userId)
        )
      );
      
    return result.rowCount > 0;
  },

  // Settings methods
  async getSettings(userId: number): Promise<Settings | null> {
    return await db.query.settings.findFirst({
      where: eq(schema.settings.userId, userId)
    });
  },

  async updateSettings(userId: number, updates: Partial<Settings>): Promise<Settings | null> {
    // Check if settings exist
    const existingSettings = await this.getSettings(userId);
    
    if (existingSettings) {
      // Update existing settings
      const [updatedSettings] = await db.update(schema.settings)
        .set({
          ...updates,
          updatedAt: new Date()
        })
        .where(eq(schema.settings.userId, userId))
        .returning();
        
      return updatedSettings;
    } else {
      // Create new settings
      const [newSettings] = await db.insert(schema.settings).values({
        userId,
        ...updates
      }).returning();
      
      return newSettings;
    }
  },

  // Stats methods
  async getStats(userId: number) {
    // Get active tasks count
    const activeTasks = await db.query.tasks.findMany({
      where: and(
        eq(schema.tasks.userId, userId),
        eq(schema.tasks.status, "running")
      )
    });
    
    // Get total data points across all tasks
    const result = await db.select({
      totalDataPoints: sql`sum(${schema.tasks.dataPoints})`
    })
    .from(schema.tasks)
    .where(eq(schema.tasks.userId, userId));
    
    const totalDataPoints = Number(result[0]?.totalDataPoints || 0);
    
    // Format data collected for display
    let dataCollected: string;
    if (totalDataPoints >= 1000000) {
      dataCollected = `${(totalDataPoints / 1000000).toFixed(1)}M`;
    } else if (totalDataPoints >= 1000) {
      dataCollected = `${(totalDataPoints / 1000).toFixed(1)}k`;
    } else {
      dataCollected = totalDataPoints.toString();
    }
    
    // Simulate API credits (in a real app, this would come from an API provider)
    const apiCredits = 750;
    
    return {
      activeTasks: activeTasks.length,
      dataCollected,
      apiCredits
    };
  }
};
