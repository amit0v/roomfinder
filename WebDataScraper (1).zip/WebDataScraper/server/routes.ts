import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { db } from "../db";
import * as schema from "@shared/schema";
import { z } from "zod";
import { eq, and, desc, asc, count, sql, gte, lte, like, between } from "drizzle-orm";

// Connected WebSocket clients for chat system
const connectedClients: Map<number, WebSocket> = new Map();

// Basic auth middleware (for demo purposes)
const authenticate = (req: Request, res: Response, next: NextFunction) => {
  // For demo purposes, we'll use a fixed user ID
  // In a real app, this would come from authentication sessions
  req.userId = 1;
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // WebSocket connection handler
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    let userId: number | null = null;
    
    // Handle connection close
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      if (userId) {
        connectedClients.delete(userId);
      }
    });
    
    // Handle client messages
    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);
        
        // Handle authentication message to register client
        if (data.type === 'auth' && data.userId) {
          userId = parseInt(data.userId);
          connectedClients.set(userId, ws);
          
          // Send confirmation
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ 
              type: 'auth_success',
              userId
            }));
          }
          return;
        }
        
        // Handle chat messages
        if (data.type === 'chat_message' && data.chatRoomId && data.message && userId) {
          const chatRoomId = parseInt(data.chatRoomId);
          
          // Save message to database
          const [savedMessage] = await db.insert(schema.chatMessages).values({
            chatRoomId,
            senderId: userId,
            message: data.message
          }).returning();
          
          // Update last message timestamp
          await db.update(schema.chatRooms)
            .set({ lastMessageAt: new Date() })
            .where(eq(schema.chatRooms.id, chatRoomId));
          
          // Get chat room details to find recipient
          const chatRoom = await db.query.chatRooms.findFirst({
            where: eq(schema.chatRooms.id, chatRoomId)
          });
          
          if (chatRoom) {
            // Determine recipient ID
            const recipientId = chatRoom.studentId === userId 
              ? chatRoom.ownerId 
              : chatRoom.studentId;
            
            // Send to recipient if online
            const recipientWs = connectedClients.get(recipientId);
            if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
              recipientWs.send(JSON.stringify({
                type: 'new_message',
                chatRoomId,
                message: savedMessage
              }));
            }
            
            // Send back confirmation to sender
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({
                type: 'message_sent',
                chatRoomId,
                message: savedMessage
              }));
            }
          }
        }
        
      } catch (e) {
        console.error('Invalid message format:', e);
      }
    });
    
    // Send initial connection confirmation
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'connected' }));
    }
  });
  
  // ===== API Routes =====
  
  // User routes
  
  // Register a new user
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const userData = req.body;
      
      try {
        const validatedData = schema.insertUserSchema.parse(userData);
        
        // Check if username or email already exists
        const existingUser = await db.query.users.findFirst({
          where: sql`${schema.users.username} = ${userData.username} OR ${schema.users.email} = ${userData.email}`
        });
        
        if (existingUser) {
          return res.status(400).json({ error: 'Username or email already in use' });
        }
        
        const [newUser] = await db.insert(schema.users).values(validatedData).returning({
          id: schema.users.id,
          username: schema.users.username,
          email: schema.users.email,
          createdAt: schema.users.createdAt
        });
        
        // Create default settings
        await db.insert(schema.settings).values({
          userId: newUser.id,
          notificationsEnabled: true,
          emailAlerts: true,
          darkMode: false
        });
        
        return res.status(201).json(newUser);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      console.error('Error registering user:', error);
      return res.status(500).json({ error: 'Failed to register user' });
    }
  });
  
  // Login
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
      }
      
      // In a real app, you'd use bcrypt to compare passwords
      // For this demo, we're using a simplistic approach
      const user = await db.query.users.findFirst({
        where: eq(schema.users.username, username)
      });
      
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      // TODO: Add proper password validation with bcrypt
      
      // Return user with token (in a real app)
      return res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        token: 'demo_token' // would be a real JWT token in production
      });
    } catch (error) {
      console.error('Error during login:', error);
      return res.status(500).json({ error: 'Login failed' });
    }
  });
  
  // Get current user profile
  app.get('/api/user/profile', authenticate, async (req: Request, res: Response) => {
    try {
      const user = await db.query.users.findFirst({
        where: eq(schema.users.id, req.userId)
      });
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      return res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        createdAt: user.createdAt
      });
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return res.status(500).json({ error: 'Failed to fetch user profile' });
    }
  });
  
  // Update user profile
  app.patch('/api/user/profile', authenticate, async (req: Request, res: Response) => {
    try {
      const updates = req.body;
      
      // Don't allow updating username or email directly
      delete updates.username;
      delete updates.email;
      delete updates.password;
      delete updates.userType;
      delete updates.isVerified;
      
      const [updatedUser] = await db.update(schema.users)
        .set({
          ...updates,
          updatedAt: new Date()
        })
        .where(eq(schema.users.id, req.userId))
        .returning();
      
      return res.json({
        id: updatedUser.id,
        username: updatedUser.username,
        email: updatedUser.email,
        createdAt: updatedUser.createdAt,
        updatedAt: updatedUser.updatedAt
      });
    } catch (error) {
      console.error('Error updating user profile:', error);
      return res.status(500).json({ error: 'Failed to update user profile' });
    }
  });
  
  // Property routes
  
  // Get properties with pagination and filters
  app.get('/api/properties', async (req: Request, res: Response) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = (page - 1) * limit;
      
      // Parse filters
      const filters: any = {};
      const { minPrice, maxPrice, bedrooms, bathrooms, propertyType, city, available, furnished, parking, pets } = req.query;
      
      // Construct where clause based on filters
      let whereClause = and();
      
      if (minPrice) {
        whereClause = and(whereClause, gte(schema.properties.monthlyRent, parseInt(minPrice as string)));
      }
      
      if (maxPrice) {
        whereClause = and(whereClause, lte(schema.properties.monthlyRent, parseInt(maxPrice as string)));
      }
      
      if (bedrooms) {
        whereClause = and(whereClause, eq(schema.properties.bedrooms, parseInt(bedrooms as string)));
      }
      
      if (bathrooms) {
        whereClause = and(whereClause, eq(schema.properties.bathrooms, parseFloat(bathrooms as string)));
      }
      
      if (propertyType) {
        whereClause = and(whereClause, eq(schema.properties.propertyType, propertyType as string));
      }
      
      if (city) {
        whereClause = and(whereClause, like(schema.properties.city, `%${city}%`));
      }
      
      if (available === 'true') {
        whereClause = and(whereClause, eq(schema.properties.status, 'available'));
        whereClause = and(whereClause, lte(schema.properties.availableFrom, new Date()));
      }
      
      if (furnished === 'true') {
        whereClause = and(whereClause, eq(schema.properties.isFurnished, true));
      }
      
      if (parking === 'true') {
        whereClause = and(whereClause, eq(schema.properties.hasParking, true));
      }
      
      if (pets === 'true') {
        whereClause = and(whereClause, eq(schema.properties.petsAllowed, true));
      }
      
      // Count total properties for pagination
      const [{ value: total }] = await db
        .select({ value: count() })
        .from(schema.properties)
        .where(whereClause);
      
      // Get properties
      const properties = await db.query.properties.findMany({
        where: whereClause,
        with: {
          owner: {
            columns: {
              id: true,
              username: true,
              email: true
            }
          },
          images: {
            where: eq(schema.propertyImages.isFeatured, true),
            limit: 1
          },
          amenities: true
        },
        limit,
        offset,
        orderBy: [desc(schema.properties.createdAt)]
      });
      
      return res.json({
        properties,
        pagination: {
          total,
          page,
          limit,
          pages: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      console.error('Error fetching properties:', error);
      return res.status(500).json({ error: 'Failed to fetch properties' });
    }
  });
  
  // Get a specific property
  app.get('/api/properties/:id', async (req: Request, res: Response) => {
    try {
      const propertyId = parseInt(req.params.id);
      if (isNaN(propertyId)) {
        return res.status(400).json({ error: 'Invalid property ID' });
      }
      
      const property = await db.query.properties.findFirst({
        where: eq(schema.properties.id, propertyId),
        with: {
          owner: {
            columns: {
              id: true,
              username: true,
              email: true
            }
          },
          images: true,
          amenities: true,
          reviews: {
            with: {
              user: {
                columns: {
                  id: true,
                  username: true,
                  email: true
                }
              }
            }
          }
        }
      });
      
      if (!property) {
        return res.status(404).json({ error: 'Property not found' });
      }
      
      return res.json(property);
    } catch (error) {
      console.error('Error fetching property:', error);
      return res.status(500).json({ error: 'Failed to fetch property' });
    }
  });
  
  // Create a new property (owner only)
  app.post('/api/properties', authenticate, async (req: Request, res: Response) => {
    try {
      // Get user to check if owner
      const user = await db.query.users.findFirst({
        where: eq(schema.users.id, req.userId)
      });
      
      if (!user || user.userType !== 'owner') {
        return res.status(403).json({ error: 'Only property owners can create listings' });
      }
      
      if (!user.isVerified) {
        return res.status(403).json({ error: 'Account must be verified to create listings' });
      }
      
      const propertyData = {
        ...req.body,
        ownerId: req.userId
      };
      
      // Validate
      try {
        const validatedData = schema.insertPropertySchema.parse(propertyData);
        
        // Create property
        const [newProperty] = await db.insert(schema.properties).values(validatedData).returning();
        
        // Add images if provided
        if (req.body.images && Array.isArray(req.body.images)) {
          const imageInserts = req.body.images.map((imageUrl: string, index: number) => ({
            propertyId: newProperty.id,
            imageUrl,
            isFeatured: index === 0 // First image is featured
          }));
          
          await db.insert(schema.propertyImages).values(imageInserts);
        }
        
        // Add amenities if provided
        if (req.body.amenities && Array.isArray(req.body.amenities)) {
          const amenityInserts = req.body.amenities.map((name: string) => ({
            propertyId: newProperty.id,
            name
          }));
          
          await db.insert(schema.propertyAmenities).values(amenityInserts);
        }
        
        // Return new property with relationships
        const property = await db.query.properties.findFirst({
          where: eq(schema.properties.id, newProperty.id),
          with: {
            images: true,
            amenities: true
          }
        });
        
        return res.status(201).json(property);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      console.error('Error creating property:', error);
      return res.status(500).json({ error: 'Failed to create property' });
    }
  });
  
  // Update a property (owner only)
  app.patch('/api/properties/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const propertyId = parseInt(req.params.id);
      if (isNaN(propertyId)) {
        return res.status(400).json({ error: 'Invalid property ID' });
      }
      
      // Verify ownership
      const property = await db.query.properties.findFirst({
        where: eq(schema.properties.id, propertyId)
      });
      
      if (!property) {
        return res.status(404).json({ error: 'Property not found' });
      }
      
      if (property.ownerId !== req.userId) {
        return res.status(403).json({ error: 'You can only update your own properties' });
      }
      
      // Update property
      const updates = req.body;
      delete updates.ownerId; // Don't allow changing owner
      
      const [updatedProperty] = await db.update(schema.properties)
        .set({
          ...updates,
          updatedAt: new Date()
        })
        .where(eq(schema.properties.id, propertyId))
        .returning();
      
      // Handle images update if provided
      if (updates.images && Array.isArray(updates.images)) {
        // Delete existing images
        await db.delete(schema.propertyImages)
          .where(eq(schema.propertyImages.propertyId, propertyId));
        
        // Add new images
        const imageInserts = updates.images.map((imageUrl: string, index: number) => ({
          propertyId,
          imageUrl,
          isFeatured: index === 0 // First image is featured
        }));
        
        await db.insert(schema.propertyImages).values(imageInserts);
      }
      
      // Handle amenities update if provided
      if (updates.amenities && Array.isArray(updates.amenities)) {
        // Delete existing amenities
        await db.delete(schema.propertyAmenities)
          .where(eq(schema.propertyAmenities.propertyId, propertyId));
        
        // Add new amenities
        const amenityInserts = updates.amenities.map((name: string) => ({
          propertyId,
          name
        }));
        
        await db.insert(schema.propertyAmenities).values(amenityInserts);
      }
      
      // Return updated property with relationships
      const result = await db.query.properties.findFirst({
        where: eq(schema.properties.id, propertyId),
        with: {
          images: true,
          amenities: true
        }
      });
      
      return res.json(result);
    } catch (error) {
      console.error('Error updating property:', error);
      return res.status(500).json({ error: 'Failed to update property' });
    }
  });
  
  // Delete a property (owner only)
  app.delete('/api/properties/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const propertyId = parseInt(req.params.id);
      if (isNaN(propertyId)) {
        return res.status(400).json({ error: 'Invalid property ID' });
      }
      
      // Verify ownership
      const property = await db.query.properties.findFirst({
        where: eq(schema.properties.id, propertyId)
      });
      
      if (!property) {
        return res.status(404).json({ error: 'Property not found' });
      }
      
      if (property.ownerId !== req.userId) {
        return res.status(403).json({ error: 'You can only delete your own properties' });
      }
      
      // First delete related records
      await db.delete(schema.propertyImages)
        .where(eq(schema.propertyImages.propertyId, propertyId));
      
      await db.delete(schema.propertyAmenities)
        .where(eq(schema.propertyAmenities.propertyId, propertyId));
      
      await db.delete(schema.propertyReviews)
        .where(eq(schema.propertyReviews.propertyId, propertyId));
      
      await db.delete(schema.favorites)
        .where(eq(schema.favorites.propertyId, propertyId));
      
      // Delete all chat rooms and messages for this property
      const chatRooms = await db.query.chatRooms.findMany({
        where: eq(schema.chatRooms.propertyId, propertyId),
        columns: { id: true }
      });
      
      for (const room of chatRooms) {
        await db.delete(schema.chatMessages)
          .where(eq(schema.chatMessages.chatRoomId, room.id));
      }
      
      await db.delete(schema.chatRooms)
        .where(eq(schema.chatRooms.propertyId, propertyId));
      
      // Finally delete the property
      await db.delete(schema.properties)
        .where(eq(schema.properties.id, propertyId));
      
      return res.json({ success: true });
    } catch (error) {
      console.error('Error deleting property:', error);
      return res.status(500).json({ error: 'Failed to delete property' });
    }
  });
  
  // Get properties for a specific owner
  app.get('/api/user/:userId/properties', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ error: 'Invalid user ID' });
      }
      
      const properties = await db.query.properties.findMany({
        where: eq(schema.properties.ownerId, userId),
        with: {
          images: {
            where: eq(schema.propertyImages.isFeatured, true),
            limit: 1
          }
        },
        orderBy: [desc(schema.properties.createdAt)]
      });
      
      return res.json(properties);
    } catch (error) {
      console.error('Error fetching user properties:', error);
      return res.status(500).json({ error: 'Failed to fetch user properties' });
    }
  });
  
  // Owner verification routes
  
  // Submit verification documents
  app.post('/api/verification/documents', authenticate, async (req: Request, res: Response) => {
    try {
      const { documentType, documentUrl } = req.body;
      
      if (!documentType || !documentUrl) {
        return res.status(400).json({ error: 'Document type and URL are required' });
      }
      
      // Validate document submission
      try {
        const validatedData = schema.insertVerificationDocumentSchema.parse({
          userId: req.userId,
          documentType,
          documentUrl
        });
        
        const [document] = await db.insert(schema.verificationDocuments)
          .values(validatedData)
          .returning();
        
        return res.status(201).json(document);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      console.error('Error submitting verification document:', error);
      return res.status(500).json({ error: 'Failed to submit verification document' });
    }
  });
  
  // Get verification status
  app.get('/api/verification/status', authenticate, async (req: Request, res: Response) => {
    try {
      const documents = await db.query.verificationDocuments.findMany({
        where: eq(schema.verificationDocuments.userId, req.userId)
      });
      
      const user = await db.query.users.findFirst({
        where: eq(schema.users.id, req.userId),
        columns: { id: true, username: true, email: true }
      });
      
      return res.json({
        user,
        documents
      });
    } catch (error) {
      console.error('Error fetching verification status:', error);
      return res.status(500).json({ error: 'Failed to fetch verification status' });
    }
  });
  
  // Chat routes
  
  // Get all chat rooms for a user
  app.get('/api/chats', authenticate, async (req: Request, res: Response) => {
    try {
      const chatRooms = await db.query.chatRooms.findMany({
        where: sql`${schema.chatRooms.studentId} = ${req.userId} OR ${schema.chatRooms.ownerId} = ${req.userId}`,
        with: {
          property: {
            columns: {
              id: true,
              title: true
            }
          },
          student: {
            columns: {
              id: true,
              username: true,
              email: true
            }
          },
          owner: {
            columns: {
              id: true,
              username: true,
              email: true
            }
          },
          messages: {
            limit: 1,
            orderBy: [desc(schema.chatMessages.createdAt)]
          }
        },
        orderBy: [desc(schema.chatRooms.lastMessageAt)]
      });
      
      return res.json(chatRooms);
    } catch (error) {
      console.error('Error fetching chat rooms:', error);
      return res.status(500).json({ error: 'Failed to fetch chat rooms' });
    }
  });
  
  // Get or create a chat room for a property
  app.post('/api/chats/property/:propertyId', authenticate, async (req: Request, res: Response) => {
    try {
      const propertyId = parseInt(req.params.propertyId);
      if (isNaN(propertyId)) {
        return res.status(400).json({ error: 'Invalid property ID' });
      }
      
      // Get property to verify it exists and get owner
      const property = await db.query.properties.findFirst({
        where: eq(schema.properties.id, propertyId),
        columns: { id: true, ownerId: true }
      });
      
      if (!property) {
        return res.status(404).json({ error: 'Property not found' });
      }
      
      // Owner can't chat with themselves
      if (property.ownerId === req.userId) {
        return res.status(400).json({ error: 'You cannot chat with yourself' });
      }
      
      // Check if chat room already exists
      let chatRoom = await db.query.chatRooms.findFirst({
        where: and(
          eq(schema.chatRooms.propertyId, propertyId),
          eq(schema.chatRooms.studentId, req.userId),
          eq(schema.chatRooms.ownerId, property.ownerId)
        ),
        with: {
          property: {
            columns: {
              id: true,
              title: true
            }
          },
          student: {
            columns: {
              id: true,
              username: true,
              email: true
            }
          },
          owner: {
            columns: {
              id: true,
              username: true,
              email: true
            }
          }
        }
      });
      
      // Create new chat room if it doesn't exist
      if (!chatRoom) {
        const [newChatRoom] = await db.insert(schema.chatRooms).values({
          propertyId,
          studentId: req.userId,
          ownerId: property.ownerId,
          lastMessageAt: new Date()
        }).returning();
        
        chatRoom = await db.query.chatRooms.findFirst({
          where: eq(schema.chatRooms.id, newChatRoom.id),
          with: {
            property: {
              columns: {
                id: true,
                title: true
              }
            },
            student: {
              columns: {
                id: true,
                username: true,
                email: true
              }
            },
            owner: {
              columns: {
                id: true,
                username: true,
                email: true
              }
            }
          }
        });
      }
      
      return res.json(chatRoom);
    } catch (error) {
      console.error('Error creating chat room:', error);
      return res.status(500).json({ error: 'Failed to create chat room' });
    }
  });
  
  // Get chat messages for a chat room
  app.get('/api/chats/:chatRoomId/messages', authenticate, async (req: Request, res: Response) => {
    try {
      const chatRoomId = parseInt(req.params.chatRoomId);
      if (isNaN(chatRoomId)) {
        return res.status(400).json({ error: 'Invalid chat room ID' });
      }
      
      // Verify user has access to this chat room
      const chatRoom = await db.query.chatRooms.findFirst({
        where: and(
          eq(schema.chatRooms.id, chatRoomId),
          sql`${schema.chatRooms.studentId} = ${req.userId} OR ${schema.chatRooms.ownerId} = ${req.userId}`
        )
      });
      
      if (!chatRoom) {
        return res.status(403).json({ error: 'You do not have access to this chat room' });
      }
      
      // Get messages
      const messages = await db.query.chatMessages.findMany({
        where: eq(schema.chatMessages.chatRoomId, chatRoomId),
        with: {
          sender: {
            columns: {
              id: true,
              username: true,
              email: true
            }
          }
        },
        orderBy: [asc(schema.chatMessages.createdAt)]
      });
      
      // Mark messages as read
      await db.update(schema.chatMessages)
        .set({ isRead: true })
        .where(
          and(
            eq(schema.chatMessages.chatRoomId, chatRoomId),
            eq(schema.chatMessages.isRead, false),
            sql`${schema.chatMessages.senderId} != ${req.userId}`
          )
        );
      
      return res.json(messages);
    } catch (error) {
      console.error('Error fetching chat messages:', error);
      return res.status(500).json({ error: 'Failed to fetch chat messages' });
    }
  });
  
  // Send a chat message
  app.post('/api/chats/:chatRoomId/messages', authenticate, async (req: Request, res: Response) => {
    try {
      const chatRoomId = parseInt(req.params.chatRoomId);
      if (isNaN(chatRoomId)) {
        return res.status(400).json({ error: 'Invalid chat room ID' });
      }
      
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ error: 'Message content is required' });
      }
      
      // Verify user has access to this chat room
      const chatRoom = await db.query.chatRooms.findFirst({
        where: and(
          eq(schema.chatRooms.id, chatRoomId),
          sql`${schema.chatRooms.studentId} = ${req.userId} OR ${schema.chatRooms.ownerId} = ${req.userId}`
        )
      });
      
      if (!chatRoom) {
        return res.status(403).json({ error: 'You do not have access to this chat room' });
      }
      
      // Create message
      try {
        const validatedData = schema.insertChatMessageSchema.parse({
          chatRoomId,
          senderId: req.userId,
          message
        });
        
        const [newMessage] = await db.insert(schema.chatMessages)
          .values(validatedData)
          .returning();
        
        // Update last message timestamp
        await db.update(schema.chatRooms)
          .set({ lastMessageAt: new Date() })
          .where(eq(schema.chatRooms.id, chatRoomId));
        
        // Get message with sender
        const messageWithSender = await db.query.chatMessages.findFirst({
          where: eq(schema.chatMessages.id, newMessage.id),
          with: {
            sender: {
              columns: {
                id: true,
                username: true,
                email: true
              }
            }
          }
        });
        
        // Notify recipient if online
        const recipientId = chatRoom.studentId === req.userId ? chatRoom.ownerId : chatRoom.studentId;
        const recipientWs = connectedClients.get(recipientId);
        
        if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
          recipientWs.send(JSON.stringify({
            type: 'new_message',
            chatRoomId,
            message: messageWithSender
          }));
        }
        
        return res.status(201).json(messageWithSender);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      console.error('Error sending message:', error);
      return res.status(500).json({ error: 'Failed to send message' });
    }
  });
  
  // Favorites routes
  
  // Get favorites for current user
  app.get('/api/favorites', authenticate, async (req: Request, res: Response) => {
    try {
      const favorites = await db.query.favorites.findMany({
        where: eq(schema.favorites.userId, req.userId),
        with: {
          property: {
            with: {
              images: {
                where: eq(schema.propertyImages.isFeatured, true),
                limit: 1
              },
              owner: {
                columns: {
                  id: true,
                  username: true,
                  email: true
                }
              }
            }
          }
        }
      });
      
      return res.json(favorites);
    } catch (error) {
      console.error('Error fetching favorites:', error);
      return res.status(500).json({ error: 'Failed to fetch favorites' });
    }
  });
  
  // Add a property to favorites
  app.post('/api/favorites', authenticate, async (req: Request, res: Response) => {
    try {
      const { propertyId } = req.body;
      
      if (!propertyId) {
        return res.status(400).json({ error: 'Property ID is required' });
      }
      
      // Check if property exists
      const property = await db.query.properties.findFirst({
        where: eq(schema.properties.id, propertyId)
      });
      
      if (!property) {
        return res.status(404).json({ error: 'Property not found' });
      }
      
      // Check if already in favorites
      const existing = await db.query.favorites.findFirst({
        where: and(
          eq(schema.favorites.userId, req.userId),
          eq(schema.favorites.propertyId, propertyId)
        )
      });
      
      if (existing) {
        return res.status(400).json({ error: 'Property already in favorites' });
      }
      
      // Add to favorites
      const [favorite] = await db.insert(schema.favorites).values({
        userId: req.userId,
        propertyId
      }).returning();
      
      return res.status(201).json(favorite);
    } catch (error) {
      console.error('Error adding to favorites:', error);
      return res.status(500).json({ error: 'Failed to add to favorites' });
    }
  });
  
  // Remove a property from favorites
  app.delete('/api/favorites/:propertyId', authenticate, async (req: Request, res: Response) => {
    try {
      const propertyId = parseInt(req.params.propertyId);
      if (isNaN(propertyId)) {
        return res.status(400).json({ error: 'Invalid property ID' });
      }
      
      await db.delete(schema.favorites)
        .where(
          and(
            eq(schema.favorites.userId, req.userId),
            eq(schema.favorites.propertyId, propertyId)
          )
        );
      
      return res.json({ success: true });
    } catch (error) {
      console.error('Error removing from favorites:', error);
      return res.status(500).json({ error: 'Failed to remove from favorites' });
    }
  });
  
  // Check if a property is in user's favorites
  app.get('/api/favorites/check/:propertyId', authenticate, async (req: Request, res: Response) => {
    try {
      const propertyId = parseInt(req.params.propertyId);
      if (isNaN(propertyId)) {
        return res.status(400).json({ error: 'Invalid property ID' });
      }
      
      const favorite = await db.query.favorites.findFirst({
        where: and(
          eq(schema.favorites.userId, req.userId),
          eq(schema.favorites.propertyId, propertyId)
        )
      });
      
      return res.json({ isFavorite: !!favorite });
    } catch (error) {
      console.error('Error checking favorite status:', error);
      return res.status(500).json({ error: 'Failed to check favorite status' });
    }
  });
  
  // Reviews routes
  
  // Get reviews for a property
  app.get('/api/properties/:propertyId/reviews', async (req: Request, res: Response) => {
    try {
      const propertyId = parseInt(req.params.propertyId);
      if (isNaN(propertyId)) {
        return res.status(400).json({ error: 'Invalid property ID' });
      }
      
      const reviews = await db.query.propertyReviews.findMany({
        where: eq(schema.propertyReviews.propertyId, propertyId),
        with: {
          user: {
            columns: {
              id: true,
              username: true,
              email: true
            }
          }
        },
        orderBy: [desc(schema.propertyReviews.createdAt)]
      });
      
      return res.json(reviews);
    } catch (error) {
      console.error('Error fetching reviews:', error);
      return res.status(500).json({ error: 'Failed to fetch reviews' });
    }
  });
  
  // Add a review for a property
  app.post('/api/properties/:propertyId/reviews', authenticate, async (req: Request, res: Response) => {
    try {
      const propertyId = parseInt(req.params.propertyId);
      if (isNaN(propertyId)) {
        return res.status(400).json({ error: 'Invalid property ID' });
      }
      
      const { rating, comment } = req.body;
      
      if (!rating) {
        return res.status(400).json({ error: 'Rating is required' });
      }
      
      // Check if property exists
      const property = await db.query.properties.findFirst({
        where: eq(schema.properties.id, propertyId)
      });
      
      if (!property) {
        return res.status(404).json({ error: 'Property not found' });
      }
      
      // Check if user already reviewed this property
      const existingReview = await db.query.propertyReviews.findFirst({
        where: and(
          eq(schema.propertyReviews.propertyId, propertyId),
          eq(schema.propertyReviews.userId, req.userId)
        )
      });
      
      if (existingReview) {
        return res.status(400).json({ error: 'You have already reviewed this property' });
      }
      
      // Add review
      try {
        const validatedData = schema.insertPropertyReviewSchema.parse({
          propertyId,
          userId: req.userId,
          rating,
          comment
        });
        
        const [review] = await db.insert(schema.propertyReviews)
          .values(validatedData)
          .returning();
        
        // Get review with user
        const reviewWithUser = await db.query.propertyReviews.findFirst({
          where: eq(schema.propertyReviews.id, review.id),
          with: {
            user: {
              columns: {
                id: true,
                username: true,
                fullName: true,
                profileImage: true
              }
            }
          }
        });
        
        return res.status(201).json(reviewWithUser);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      console.error('Error adding review:', error);
      return res.status(500).json({ error: 'Failed to add review' });
    }
  });
  
  // Settings routes
  
  // Get user settings
  app.get('/api/settings', authenticate, async (req: Request, res: Response) => {
    try {
      const settings = await db.query.settings.findFirst({
        where: eq(schema.settings.userId, req.userId)
      });
      
      if (!settings) {
        // Create default settings if not found
        const [newSettings] = await db.insert(schema.settings).values({
          userId: req.userId,
          notificationsEnabled: true,
          emailAlerts: true,
          darkMode: false
        }).returning();
        
        return res.json(newSettings);
      }
      
      return res.json(settings);
    } catch (error) {
      console.error('Error fetching settings:', error);
      return res.status(500).json({ error: 'Failed to fetch settings' });
    }
  });
  
  // Update user settings
  app.patch('/api/settings', authenticate, async (req: Request, res: Response) => {
    try {
      const updates = req.body;
      
      // Validate settings
      const settingsSchema = z.object({
        notificationsEnabled: z.boolean().optional(),
        emailAlerts: z.boolean().optional(),
        darkMode: z.boolean().optional()
      });
      
      try {
        const validatedData = settingsSchema.parse(updates);
        
        // Get current settings
        let settings = await db.query.settings.findFirst({
          where: eq(schema.settings.userId, req.userId)
        });
        
        if (!settings) {
          // Create settings if not exist
          const [newSettings] = await db.insert(schema.settings).values({
            userId: req.userId,
            ...validatedData
          }).returning();
          
          return res.json(newSettings);
        }
        
        // Update existing settings
        const [updatedSettings] = await db.update(schema.settings)
          .set({
            ...validatedData,
            updatedAt: new Date()
          })
          .where(eq(schema.settings.userId, req.userId))
          .returning();
        
        return res.json(updatedSettings);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      console.error('Error updating settings:', error);
      return res.status(500).json({ error: 'Failed to update settings' });
    }
  });

  return httpServer;
}

// Extend Express Request type to include userId
declare global {
  namespace Express {
    interface Request {
      userId: number;
    }
  }
}
