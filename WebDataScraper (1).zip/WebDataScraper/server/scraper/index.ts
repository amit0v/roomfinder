import { WebScraper } from "./web-scraper";
import { SocialScraper } from "./social-scraper";
import { ApiConnector } from "./api-connector";
import { storage } from "../storage";
import { Task } from "@shared/schema";
import { WebSocket } from "ws";

// Map to keep track of active scraper tasks
const activeScrapers = new Map<number, any>();

// WebSocket clients for real-time progress updates
const clients = new Set<WebSocket>();

// Add a WebSocket client
export function addClient(client: WebSocket) {
  clients.add(client);
}

// Remove a WebSocket client
export function removeClient(client: WebSocket) {
  clients.delete(client);
}

// Broadcast a message to all connected clients
export function broadcast(message: any) {
  const data = JSON.stringify(message);
  
  clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  });
}

// Get a scraper instance based on task type
function getScraperInstance(task: Task, onProgress: (progress: number) => void) {
  switch (task.type) {
    case "web":
      return new WebScraper(task, onProgress);
    case "twitter":
    case "linkedin":
    case "instagram":
      return new SocialScraper(task, onProgress);
    case "api":
      return new ApiConnector(task, onProgress);
    default:
      throw new Error(`Unknown task type: ${task.type}`);
  }
}

// Start a scraping task
export async function startTask(taskId: number, userId: number): Promise<Task | null> {
  // Check if task is already running
  if (activeScrapers.has(taskId)) {
    return null;
  }
  
  // Get task details
  const task = await storage.getTaskById(taskId, userId);
  if (!task) {
    throw new Error(`Task not found: ${taskId}`);
  }
  
  // Update task status to running
  const updatedTask = await storage.updateTaskStatus(taskId, userId, "running");
  if (!updatedTask) {
    throw new Error(`Failed to update task status: ${taskId}`);
  }
  
  // Create progress callback
  const onProgress = (progress: number) => {
    broadcast({
      taskId,
      type: "progress",
      progress
    });
  };
  
  // Create scraper instance
  const scraper = getScraperInstance(task, onProgress);
  
  // Add to active scrapers
  activeScrapers.set(taskId, scraper);
  
  // Start scraping in the background
  scraper.start().then(async (result: any) => {
    // Save scraped data
    if (result && result.data) {
      await storage.saveScrapedData(taskId, userId, result.data);
    }
    
    // Update task status
    const finalStatus = result.success ? "completed" : "failed";
    await storage.updateTaskStatus(taskId, userId, finalStatus);
    
    // Broadcast status update
    broadcast({
      taskId,
      type: "status",
      status: finalStatus
    });
    
    // Remove from active scrapers
    activeScrapers.delete(taskId);
  }).catch(async (error: Error) => {
    console.error(`Error in scraping task ${taskId}:`, error);
    
    // Update task status to failed
    await storage.updateTaskStatus(taskId, userId, "failed");
    
    // Broadcast error
    broadcast({
      taskId,
      type: "error",
      message: error.message
    });
    
    // Remove from active scrapers
    activeScrapers.delete(taskId);
  });
  
  return updatedTask;
}

// Pause a running task
export async function pauseTask(taskId: number, userId: number): Promise<Task | null> {
  // Check if task is running
  const scraper = activeScrapers.get(taskId);
  if (scraper) {
    // Stop the scraper
    await scraper.stop();
    activeScrapers.delete(taskId);
  }
  
  // Update task status to paused
  return await storage.updateTaskStatus(taskId, userId, "paused");
}

// Get all active tasks
export function getActiveTasks(): number[] {
  return Array.from(activeScrapers.keys());
}

// Schedule tasks to run based on their frequency
export async function scheduleTasksByFrequency() {
  // This would be called by a scheduler (like node-cron) to run tasks according to their frequency
  // For now, we'll just implement the core logic
  
  // Get all scheduled tasks (in a real app, we would filter by frequency and last run time)
  // For demo purposes, we'll just schedule all paused tasks
  const allUsers = await storage.getAllTasks(1); // In a real app, we'd query all users and their tasks
  
  for (const task of allUsers) {
    if (task.status === "scheduled") {
      try {
        await startTask(task.id, task.userId);
      } catch (error) {
        console.error(`Failed to schedule task ${task.id}:`, error);
      }
    }
  }
}
