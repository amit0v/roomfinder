import { Task, ApiConnectorConfig } from "@shared/schema";
import fetch from "node-fetch";

export class ApiConnector {
  private task: Task;
  private config: ApiConnectorConfig;
  private onProgress: (progress: number) => void;
  private isStopped: boolean = false;
  
  constructor(task: Task, onProgress: (progress: number) => void) {
    this.task = task;
    this.config = task.configuration as ApiConnectorConfig;
    this.onProgress = onProgress;
  }
  
  async start(): Promise<{ success: boolean; data?: any[] }> {
    try {
      if (!this.config.url) {
        throw new Error("URL is required");
      }
      
      const data = await this.fetchData();
      return { success: true, data };
    } catch (error) {
      console.error("API connector error:", error);
      return { success: false };
    }
  }
  
  async stop(): Promise<void> {
    this.isStopped = true;
  }
  
  private async fetchData(): Promise<any[]> {
    // Report starting progress
    this.onProgress(0);
    
    if (this.isStopped) {
      return [];
    }
    
    // Prepare headers
    const headers: Record<string, string> = {
      ...this.config.headers
    };
    
    // Make the API request
    const response = await fetch(this.config.url, {
      method: this.config.method,
      headers,
      body: this.config.method === "POST" && this.config.body ? this.config.body : undefined
    });
    
    // Update progress to 50%
    this.onProgress(50);
    
    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}: ${response.statusText}`);
    }
    
    // Parse response
    const contentType = response.headers.get("content-type");
    let data;
    
    if (contentType && contentType.includes("application/json")) {
      data = await response.json();
    } else {
      const text = await response.text();
      try {
        // Try to parse as JSON anyway
        data = JSON.parse(text);
      } catch (e) {
        // If not JSON, return as plain text
        data = { text };
      }
    }
    
    // Normalize the response to an array
    let results: any[] = [];
    
    if (Array.isArray(data)) {
      results = data;
    } else if (data && typeof data === "object") {
      // Check if the data has results/items/data/content properties
      if (data.results) results = data.results;
      else if (data.items) results = data.items;
      else if (data.data) results = Array.isArray(data.data) ? data.data : [data.data];
      else if (data.content) results = Array.isArray(data.content) ? data.content : [data.content];
      // If none of these properties exist, use the object as a single item
      else results = [data];
    } else {
      results = [{ value: data }];
    }
    
    // Final progress update
    this.onProgress(100);
    
    return results;
  }
}
