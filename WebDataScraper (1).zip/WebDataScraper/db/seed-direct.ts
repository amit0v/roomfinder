import { pool } from "./index";
import { hashSync } from "bcrypt";

async function seed() {
  const client = await pool.connect();
  
  try {
    // Start transaction
    await client.query('BEGIN');

    // Check if we already have users
    const existingUsers = await client.query('SELECT id FROM users LIMIT 1');
    
    if (existingUsers.rows.length === 0) {
      console.log("Seeding database with initial data...");
      
      // Create demo student user
      const studentUser = await client.query(`
        INSERT INTO users (username, password, email, full_name, phone, user_type, is_verified, profile_image)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING id
      `, [
        "student1",
        hashSync("student123", 10),
        "student1@example.com",
        "Alex Johnson",
        "555-123-4567",
        "student",
        true,
        "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex"
      ]);
      
      const studentUserId = studentUser.rows[0].id;
      console.log(`Created student user with ID: ${studentUserId}`);
      
      // Create demo property owner user
      const ownerUser = await client.query(`
        INSERT INTO users (username, password, email, full_name, phone, user_type, is_verified, profile_image)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING id
      `, [
        "owner1",
        hashSync("owner123", 10),
        "owner1@example.com",
        "Morgan Smith",
        "555-987-6543",
        "owner",
        true,
        "https://api.dicebear.com/7.x/avataaars/svg?seed=Morgan"
      ]);
      
      const ownerUserId = ownerUser.rows[0].id;
      console.log(`Created owner user with ID: ${ownerUserId}`);
      
      // Create verification documents for owner
      await client.query(`
        INSERT INTO verification_documents (user_id, document_type, document_url, is_verified, verified_at)
        VALUES
          ($1, $2, $3, $4, $5),
          ($1, $6, $7, $8, $9)
      `, [
        ownerUserId, "id", "https://example.com/verification/id.jpg", true, new Date(),
        "utility_bill", "https://example.com/verification/utility.jpg", true, new Date()
      ]);
      
      console.log("Created verification documents for owner");
      
      // Create sample properties
      const property1 = await client.query(`
        INSERT INTO properties (
          owner_id, title, description, address, city, state, zip_code,
          latitude, longitude, property_type, monthly_rent, security_deposit,
          bedrooms, bathrooms, square_feet, is_furnished, has_parking,
          pets_allowed, available_from, status
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
        RETURNING id
      `, [
        ownerUserId,
        "Cozy Studio Near University",
        "Bright and modern studio apartment perfect for students. Located just 5 minutes walk from the main campus. Includes all utilities and high-speed internet.",
        "123 University Ave",
        "College Town",
        "CA",
        "90210",
        34.052235,
        -118.243683,
        "studio",
        950,
        950,
        0,
        1.0,
        450,
        true,
        true,
        false,
        new Date("2025-06-01"),
        "available"
      ]);
      
      const property2 = await client.query(`
        INSERT INTO properties (
          owner_id, title, description, address, city, state, zip_code,
          latitude, longitude, property_type, monthly_rent, security_deposit,
          bedrooms, bathrooms, square_feet, is_furnished, has_parking,
          pets_allowed, available_from, status
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
        RETURNING id
      `, [
        ownerUserId,
        "Shared 2-Bedroom Apartment with Balcony",
        "Looking for a roommate to share this beautiful 2-bedroom apartment. Private bedroom and shared common areas. Great neighborhood with restaurants and shops nearby.",
        "456 College Blvd",
        "College Town",
        "CA",
        "90211",
        34.053255,
        -118.245664,
        "apartment",
        750,
        750,
        2,
        1.5,
        850,
        false,
        true,
        true,
        new Date("2025-05-15"),
        "available"
      ]);
      
      const property3 = await client.query(`
        INSERT INTO properties (
          owner_id, title, description, address, city, state, zip_code,
          latitude, longitude, property_type, monthly_rent, security_deposit,
          bedrooms, bathrooms, square_feet, is_furnished, has_parking,
          pets_allowed, available_from, status
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
        RETURNING id
      `, [
        ownerUserId,
        "Private Room in Modern House",
        "Furnished private room in a modern house shared with other students. Includes utilities, internet, laundry facilities, and access to a fully equipped kitchen.",
        "789 Student Lane",
        "College Town",
        "CA",
        "90212",
        34.054248,
        -118.247852,
        "room",
        650,
        650,
        1,
        1.0,
        200,
        true,
        false,
        false,
        new Date("2025-05-01"),
        "available"
      ]);
      
      const property1Id = property1.rows[0].id;
      const property2Id = property2.rows[0].id;
      const property3Id = property3.rows[0].id;
      
      console.log(`Created 3 sample properties with IDs: ${property1Id}, ${property2Id}, ${property3Id}`);
      
      // Create property images
      for (const propertyId of [property1Id, property2Id, property3Id]) {
        await client.query(`
          INSERT INTO property_images (property_id, image_url, is_featured)
          VALUES
            ($1, $2, $3),
            ($1, $4, $5),
            ($1, $6, $7)
        `, [
          propertyId,
          `https://source.unsplash.com/random/800x600?apartment&sig=${propertyId}1`, true,
          `https://source.unsplash.com/random/800x600?livingroom&sig=${propertyId}2`, false,
          `https://source.unsplash.com/random/800x600?kitchen&sig=${propertyId}3`, false
        ]);
      }
      
      console.log("Created property images");
      
      // Create property amenities
      const amenitiesSets = [
        ["High-speed internet", "Air conditioning", "Heating", "Laundry facilities"],
        ["High-speed internet", "Pool", "Gym", "Parking", "Security system"],
        ["High-speed internet", "Air conditioning", "Heating", "Shared kitchen", "Study room"]
      ];
      
      const propertyIds = [property1Id, property2Id, property3Id];
      
      for (let i = 0; i < propertyIds.length; i++) {
        for (const amenity of amenitiesSets[i]) {
          await client.query(`
            INSERT INTO property_amenities (property_id, name)
            VALUES ($1, $2)
          `, [propertyIds[i], amenity]);
        }
      }
      
      console.log("Created property amenities");
      
      // Create a chat room
      const chatRoom = await client.query(`
        INSERT INTO chat_rooms (property_id, student_id, owner_id)
        VALUES ($1, $2, $3)
        RETURNING id
      `, [property1Id, studentUserId, ownerUserId]);
      
      const chatRoomId = chatRoom.rows[0].id;
      console.log(`Created chat room with ID: ${chatRoomId}`);
      
      // Create chat messages
      const currentTime = new Date();
      const threeDaysAgo = new Date(currentTime.getTime() - 3 * 24 * 60 * 60 * 1000);
      const twoDaysAgo = new Date(currentTime.getTime() - 2 * 24 * 60 * 60 * 1000);
      const oneDayAgo = new Date(currentTime.getTime() - 1 * 24 * 60 * 60 * 1000);
      const twelveHoursAgo = new Date(currentTime.getTime() - 12 * 60 * 60 * 1000);
      
      await client.query(`
        INSERT INTO chat_messages (chat_room_id, sender_id, message, is_read, created_at)
        VALUES
          ($1, $2, $3, $4, $5),
          ($1, $6, $7, $8, $9),
          ($1, $2, $10, $11, $12),
          ($1, $6, $13, $14, $15)
      `, [
        chatRoomId, studentUserId, "Hi, I'm interested in this studio. Is it still available?", true, threeDaysAgo,
        ownerUserId, "Yes, it's still available! When would you like to view it?", true, twoDaysAgo,
        studentUserId, "Great! Would this Friday at 3 PM work for you?", true, oneDayAgo,
        ownerUserId, "Friday at 3 PM works perfectly. I'll meet you at the property. Let me know if you need directions.", false, twelveHoursAgo
      ]);
      
      console.log("Created chat messages");
      
      // Add a property to student's favorites
      await client.query(`
        INSERT INTO favorites (user_id, property_id)
        VALUES ($1, $2)
      `, [studentUserId, property1Id]);
      
      console.log("Added property to student's favorites");
      
      // Create settings for users
      await client.query(`
        INSERT INTO settings (user_id, notifications_enabled, email_alerts, dark_mode)
        VALUES
          ($1, $2, $3, $4),
          ($5, $6, $7, $8)
      `, [
        studentUserId, true, true, false,
        ownerUserId, true, true, true
      ]);
      
      console.log("Created settings for users");
      
      // Add a review for one of the properties
      await client.query(`
        INSERT INTO property_reviews (property_id, user_id, rating, comment)
        VALUES ($1, $2, $3, $4)
      `, [
        property3Id,
        studentUserId,
        4,
        "Great location and clean space. Very convenient for university students."
      ]);
      
      console.log("Created property review");
      
      // Commit the transaction
      await client.query('COMMIT');
      console.log("Database seeded successfully.");
    } else {
      console.log("Database already has data, skipping seed.");
      await client.query('COMMIT');
    }
  } catch (error) {
    // Rollback in case of error
    await client.query('ROLLBACK');
    console.error("Error seeding database:", error);
  } finally {
    // Release client back to pool
    client.release();
  }
}

seed().catch(console.error);