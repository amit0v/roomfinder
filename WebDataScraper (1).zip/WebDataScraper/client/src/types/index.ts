export type User = {
  id: number;
  username: string;
  email: string;
  createdAt: string;
  updatedAt: string;
};

export type ScraperType = "web" | "twitter" | "linkedin" | "instagram" | "api";

export type TaskStatus = "running" | "scheduled" | "paused" | "completed" | "failed";

export type TaskFrequency = "once" | "hourly" | "daily" | "weekly" | "monthly";

export type DataFormat = "json" | "csv" | "database";

export type ScraperTask = {
  id: number;
  name: string;
  type: ScraperType;
  status: TaskStatus;
  dataPoints: number;
  lastRun: string;
  userId: number;
  createdAt: string;
  updatedAt: string;
  configuration: WebScraperConfig | SocialScraperConfig | ApiConnectorConfig;
};

export type ScraperField = {
  id?: number;
  name: string;
  selector: string;
};

export type WebScraperConfig = {
  url: string;
  frequency: TaskFrequency;
  fields: ScraperField[];
  useProxy: boolean;
  executeJavascript: boolean;
  followPagination: boolean;
  exportFormat: DataFormat;
};

export type SocialScraperConfig = {
  platform: "twitter" | "linkedin" | "instagram";
  query: string;
  frequency: TaskFrequency;
  limit: number;
  exportFormat: DataFormat;
};

export type ApiConnectorConfig = {
  url: string;
  method: "GET" | "POST";
  headers: Record<string, string>;
  body?: string;
  frequency: TaskFrequency;
  exportFormat: DataFormat;
};

export type ScrapedData = {
  id: number;
  taskId: number;
  data: Record<string, any>[];
  createdAt: string;
};

export type Stats = {
  activeTasks: number;
  dataCollected: string;
  apiCredits: number;
};

export type ApiKey = {
  id: number;
  service: string;
  key: string;
  createdAt: string;
};
