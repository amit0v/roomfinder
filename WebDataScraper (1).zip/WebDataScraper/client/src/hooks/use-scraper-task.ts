import { useState, useEffect } from "react";
import { useWebSocket } from "@/lib/websocket";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ScraperTask } from "@/types";
import { useToast } from "@/hooks/use-toast";

export function useScraperTask(taskId?: number) {
  const { toast } = useToast();
  const [task, setTask] = useState<ScraperTask | null>(null);
  const [progress, setProgress] = useState(0);
  
  // Fetch task details if taskId is provided
  const { data: taskData } = useQuery({
    queryKey: ["/api/tasks", taskId],
    enabled: !!taskId,
  });
  
  // Subscribe to task progress updates via WebSocket
  const { isConnected } = useWebSocket<{ taskId: number; type: string; progress?: number; status?: string }>(
    (data) => {
      if (taskId && data.taskId === taskId) {
        if (data.type === "progress" && typeof data.progress === "number") {
          setProgress(data.progress);
        } else if (data.type === "status" && data.status) {
          queryClient.invalidateQueries({ queryKey: ["/api/tasks", taskId] });
          toast({
            title: `Task ${data.status}`,
            description: `Task status updated to ${data.status}`,
          });
        }
      }
    },
    (error) => {
      console.error("WebSocket error:", error);
    }
  );
  
  // Mutations for controlling tasks
  const startTaskMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest("POST", `/api/tasks/${id}/start`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      if (taskId) {
        queryClient.invalidateQueries({ queryKey: ["/api/tasks", taskId] });
      }
      toast({
        title: "Task started",
        description: "The scraping task has been started successfully.",
      });
    },
  });
  
  const pauseTaskMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest("POST", `/api/tasks/${id}/pause`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      if (taskId) {
        queryClient.invalidateQueries({ queryKey: ["/api/tasks", taskId] });
      }
      toast({
        title: "Task paused",
        description: "The scraping task has been paused successfully.",
      });
    },
  });
  
  const deleteTaskMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest("DELETE", `/api/tasks/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task deleted",
        description: "The scraping task has been deleted successfully.",
      });
    },
  });
  
  // Update local task state when data changes
  useEffect(() => {
    if (taskData) {
      setTask(taskData);
    }
  }, [taskData]);
  
  return {
    task,
    progress,
    isConnected,
    startTask: startTaskMutation.mutate,
    pauseTask: pauseTaskMutation.mutate,
    deleteTask: deleteTaskMutation.mutate,
    isStarting: startTaskMutation.isPending,
    isPausing: pauseTaskMutation.isPending,
    isDeleting: deleteTaskMutation.isPending,
  };
}
