import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const gradientButtonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none",
  {
    variants: {
      variant: {
        default:
          "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow hover:shadow-lg hover:from-indigo-500 hover:to-purple-500 focus-visible:ring-indigo-500",
        blue: 
          "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow hover:shadow-lg hover:from-blue-500 hover:to-indigo-500 focus-visible:ring-blue-500",
        amber: 
          "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow hover:shadow-lg hover:from-amber-400 hover:to-orange-400 focus-visible:ring-amber-500",
        green: 
          "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow hover:shadow-lg hover:from-emerald-500 hover:to-teal-500 focus-visible:ring-emerald-500",
        pink: 
          "bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow hover:shadow-lg hover:from-pink-500 hover:to-rose-500 focus-visible:ring-pink-500",
        outline:
          "border border-input bg-background text-foreground hover:text-white hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:border-transparent",
        ghost:
          "bg-none text-foreground hover:text-white hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3 rounded-md",
        lg: "h-12 px-6 rounded-md text-base",
        xl: "h-14 px-8 rounded-lg text-lg",
        icon: "h-10 w-10",
      },
      glow: {
        true: "relative after:absolute after:inset-0 after:z-[-1] after:bg-inherit after:blur-lg after:opacity-50",
        false: "",
      },
      fullWidth: {
        true: "w-full",
        false: "",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
      glow: false,
      fullWidth: false,
    },
  }
);

export interface GradientButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof gradientButtonVariants> {}

const GradientButton = React.forwardRef<HTMLButtonElement, GradientButtonProps>(
  ({ className, variant, size, glow, fullWidth, ...props }, ref) => {
    return (
      <button
        className={cn(gradientButtonVariants({ variant, size, glow, fullWidth, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
GradientButton.displayName = "GradientButton";

export { GradientButton, gradientButtonVariants };