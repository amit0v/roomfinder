import { AlertCircle, ServerOff, BookX, Wifi } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

interface ErrorPlaceholderProps {
  type?: "server" | "not-found" | "connection" | "generic";
  title?: string;
  message?: string;
  actionText?: string;
  onAction?: () => void;
}

export function ErrorPlaceholder({
  type = "generic",
  title,
  message,
  actionText = "Try Again",
  onAction
}: ErrorPlaceholderProps) {
  const defaultMessages = {
    server: {
      title: "Server Error",
      message: "We're experiencing some server issues. Please try again later."
    },
    "not-found": {
      title: "Not Found",
      message: "The resource you're looking for doesn't exist or has been removed."
    },
    connection: {
      title: "Connection Error",
      message: "Unable to connect to the server. Please check your internet connection."
    },
    generic: {
      title: "Something Went Wrong",
      message: "An unexpected error occurred. Please try again later."
    }
  };

  const icons = {
    server: <ServerOff className="h-12 w-12 text-red-500" />,
    "not-found": <BookX className="h-12 w-12 text-yellow-500" />,
    connection: <Wifi className="h-12 w-12 text-blue-500" />,
    generic: <AlertCircle className="h-12 w-12 text-orange-500" />
  };

  const displayTitle = title || defaultMessages[type].title;
  const displayMessage = message || defaultMessages[type].message;
  const icon = icons[type];

  return (
    <Card className="w-full max-w-md mx-auto overflow-hidden border-none shadow-lg bg-white/50 backdrop-blur-sm">
      <CardHeader className="pb-0 pt-6 flex flex-col items-center">
        <div className="mb-4 rounded-full bg-gray-50 p-3">
          {icon}
        </div>
        <CardTitle className="text-xl font-semibold text-center">{displayTitle}</CardTitle>
      </CardHeader>
      <CardContent className="pt-4 text-center text-gray-500">
        <p>{displayMessage}</p>
      </CardContent>
      {onAction && (
        <CardFooter className="pb-6 flex justify-center">
          <Button
            variant="outline"
            onClick={onAction}
            className="border-indigo-200 hover:border-indigo-300 hover:bg-indigo-50 text-indigo-600"
          >
            {actionText}
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}