import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  MapPinIcon, 
  BedDoubleIcon, 
  BathIcon, 
  HomeIcon, 
  Maximize2Icon,
  HeartIcon,
  MessageCircleIcon,
  CalendarIcon,
  VerifiedIcon
} from "lucide-react";

interface PropertyCardProps {
  property: {
    id: number;
    title: string;
    address: string;
    city: string;
    monthlyRent: number;
    bedrooms: number;
    bathrooms: number;
    squareFeet?: number;
    status: string;
    availableFrom: string;
    images?: { imageUrl: string }[];
    owner?: {
      username: string;
      is_verified: boolean;
    };
    isFeatured?: boolean;
  };
  variant?: "default" | "compact" | "list";
  showActions?: boolean;
  onFavoriteToggle?: () => void;
  isFavorite?: boolean;
}

export function PropertyCard({
  property,
  variant = "default",
  showActions = true,
  onFavoriteToggle,
  isFavorite = false,
}: PropertyCardProps) {
  const [, navigate] = useLocation();
  const [isHovered, setIsHovered] = useState(false);
  
  // Format date nicely
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };
  
  const handlePropertyClick = () => {
    navigate(`/property/${property.id}`);
  };
  
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onFavoriteToggle) {
      onFavoriteToggle();
    }
  };
  
  const handleMessageClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/chat?propertyId=${property.id}`);
  };
  
  // Get default or first image
  const imageUrl = property.images?.[0]?.imageUrl || 
    "https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&w=2340&q=80";
  
  if (variant === "compact") {
    return (
      <Card
        className="overflow-hidden cursor-pointer group hover:shadow-md transition-all duration-300"
        onClick={handlePropertyClick}
      >
        <div className="flex h-24">
          <div className="w-24 h-full overflow-hidden">
            <img
              src={imageUrl}
              alt={property.title}
              className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
            />
          </div>
          <CardContent className="p-3 flex-1">
            <h3 className="font-medium text-sm line-clamp-1">{property.title}</h3>
            <div className="flex items-center text-gray-500 text-xs mt-1">
              <MapPinIcon className="h-3 w-3 mr-1" />
              <span className="truncate">{property.city}</span>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm font-semibold text-indigo-600">${property.monthlyRent}/mo</span>
              <Badge variant="outline" className="text-xs px-2 py-0 h-5">{property.bedrooms} bd</Badge>
            </div>
          </CardContent>
        </div>
      </Card>
    );
  }
  
  if (variant === "list") {
    return (
      <Card
        className="overflow-hidden cursor-pointer group hover:shadow-md transition-all duration-300"
        onClick={handlePropertyClick}
      >
        <div className="flex flex-col sm:flex-row">
          <div className="sm:w-48 h-48 sm:h-auto overflow-hidden relative">
            <img
              src={imageUrl}
              alt={property.title}
              className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
            />
            {property.status === "featured" && (
              <Badge className="absolute top-2 left-2 bg-amber-500">Featured</Badge>
            )}
          </div>
          <CardContent className="p-4 flex-1">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-lg mb-1">{property.title}</h3>
                <div className="flex items-center text-gray-500 text-sm mb-2">
                  <MapPinIcon className="h-4 w-4 mr-1" />
                  <span>{property.address}, {property.city}</span>
                </div>
              </div>
              <span className="text-xl font-bold text-indigo-600">${property.monthlyRent}/mo</span>
            </div>
            
            <div className="flex flex-wrap gap-4 mt-3 text-sm text-gray-600">
              <div className="flex items-center">
                <BedDoubleIcon className="h-4 w-4 mr-1" />
                <span>{property.bedrooms} {property.bedrooms === 1 ? "Bed" : "Beds"}</span>
              </div>
              <div className="flex items-center">
                <BathIcon className="h-4 w-4 mr-1" />
                <span>{property.bathrooms} {property.bathrooms === 1 ? "Bath" : "Baths"}</span>
              </div>
              {property.squareFeet && (
                <div className="flex items-center">
                  <Maximize2Icon className="h-4 w-4 mr-1" />
                  <span>{property.squareFeet} ft²</span>
                </div>
              )}
              <div className="flex items-center">
                <CalendarIcon className="h-4 w-4 mr-1" />
                <span>Available {formatDate(property.availableFrom)}</span>
              </div>
            </div>
            
            {showActions && (
              <div className="flex justify-between mt-4 pt-3 border-t">
                <div className="flex items-center text-gray-600 text-sm">
                  {property.owner?.is_verified && (
                    <div className="flex items-center mr-4 text-indigo-600">
                      <VerifiedIcon className="h-4 w-4 mr-1" />
                      <span>Verified Owner</span>
                    </div>
                  )}
                  <span className="text-gray-500">Listed by {property.owner?.username || "Owner"}</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleFavoriteClick}
                    className={`p-2 rounded-full ${isFavorite ? "text-red-500 bg-red-50" : "text-gray-400 hover:text-red-500 hover:bg-red-50"} transition-colors`}
                  >
                    <HeartIcon className="h-5 w-5" fill={isFavorite ? "currentColor" : "none"} />
                  </button>
                  <button
                    onClick={handleMessageClick}
                    className="p-2 rounded-full text-gray-400 hover:text-indigo-500 hover:bg-indigo-50 transition-colors"
                  >
                    <MessageCircleIcon className="h-5 w-5" />
                  </button>
                </div>
              </div>
            )}
          </CardContent>
        </div>
      </Card>
    );
  }
  
  // Default card style
  return (
    <Card
      className="overflow-hidden cursor-pointer group hover:shadow-xl transition-all duration-300"
      onClick={handlePropertyClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={imageUrl}
          alt={property.title}
          className={`h-full w-full object-cover transition-transform duration-300 ${isHovered ? "scale-110" : "scale-100"}`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        {property.status === "featured" && (
          <Badge className="absolute top-2 left-2 bg-amber-500">Featured</Badge>
        )}
        
        {showActions && (
          <div className="absolute top-2 right-2 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={handleFavoriteClick}
              className={`p-1.5 rounded-full ${isFavorite ? "bg-red-500 text-white" : "bg-white/90 text-gray-700 hover:bg-red-500 hover:text-white"} transition-colors shadow-sm`}
            >
              <HeartIcon className="h-4 w-4" fill={isFavorite ? "currentColor" : "none"} />
            </button>
            <button
              onClick={handleMessageClick}
              className="p-1.5 rounded-full bg-white/90 text-gray-700 hover:bg-indigo-500 hover:text-white transition-colors shadow-sm"
            >
              <MessageCircleIcon className="h-4 w-4" />
            </button>
          </div>
        )}
        
        <div className="absolute bottom-0 left-0 right-0 p-3 flex justify-between items-end opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Badge variant="outline" className="bg-white/90 text-indigo-600 font-medium border-0">
            Available {formatDate(property.availableFrom)}
          </Badge>
          <Badge className="bg-gradient-to-r from-indigo-600 to-purple-600 border-0 text-white">
            ${property.monthlyRent}/mo
          </Badge>
        </div>
      </div>
      
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="font-bold text-lg mb-1 line-clamp-1 group-hover:text-indigo-600 transition-colors">{property.title}</h3>
          {property.owner?.is_verified && (
            <Badge variant="outline" className="ml-2 border-indigo-200 text-indigo-600 flex items-center gap-1">
              <VerifiedIcon className="h-3 w-3" />
              <span className="text-xs">Verified</span>
            </Badge>
          )}
        </div>
        
        <div className="flex items-center text-gray-500 text-sm mb-3">
          <MapPinIcon className="h-4 w-4 mr-1 flex-shrink-0" />
          <span className="truncate">{property.address}, {property.city}</span>
        </div>
        
        <div className="flex justify-between text-sm text-gray-600 pt-2 border-t">
          <div className="flex items-center">
            <BedDoubleIcon className="h-4 w-4 mr-1" />
            <span>{property.bedrooms} {property.bedrooms === 1 ? "Bed" : "Beds"}</span>
          </div>
          <div className="flex items-center">
            <BathIcon className="h-4 w-4 mr-1" />
            <span>{property.bathrooms} {property.bathrooms === 1 ? "Bath" : "Baths"}</span>
          </div>
          {property.squareFeet && (
            <div className="flex items-center">
              <HomeIcon className="h-4 w-4 mr-1" />
              <span>{property.squareFeet} ft²</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}