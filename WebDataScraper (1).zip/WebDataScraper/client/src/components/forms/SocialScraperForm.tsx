import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { SocialScraperConfig, TaskFrequency, DataFormat, ScraperType } from "@/types";

interface SocialScraperFormProps {
  type: ScraperType;
  onChange: (data: Partial<SocialScraperConfig>, isValid: boolean) => void;
}

export default function SocialScraperForm({ type, onChange }: SocialScraperFormProps) {
  const [name, setName] = useState("");
  const [query, setQuery] = useState("");
  const [frequency, setFrequency] = useState<TaskFrequency>("once");
  const [limit, setLimit] = useState(100);
  const [exportFormat, setExportFormat] = useState<DataFormat>("json");
  
  const getPlatformName = () => {
    switch (type) {
      case "twitter":
        return "Twitter/X";
      case "linkedin":
        return "LinkedIn";
      case "instagram":
        return "Instagram";
      default:
        return "Social Media";
    }
  };
  
  const getQueryPlaceholder = () => {
    switch (type) {
      case "twitter":
        return "#hashtag, @username, or search term";
      case "linkedin":
        return "Company name, job title, or keyword";
      case "instagram":
        return "#hashtag, @username, or location";
      default:
        return "Enter search query";
    }
  };
  
  useEffect(() => {
    const formData = {
      name,
      platform: type,
      query,
      frequency,
      limit,
      exportFormat
    };
    
    const isValid = name.trim() !== "" && query.trim() !== "";
    
    onChange(formData, isValid);
  }, [name, query, frequency, limit, exportFormat, type]);
  
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Scraper Name</Label>
        <Input 
          id="name" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={`${getPlatformName()} Data Collector`}
          className="mt-1" 
        />
      </div>
      
      <div>
        <Label htmlFor="query">Search Query</Label>
        <Input 
          id="query" 
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={getQueryPlaceholder()}
          className="mt-1" 
        />
      </div>
      
      <div>
        <Label htmlFor="frequency">Frequency</Label>
        <Select value={frequency} onValueChange={(value: TaskFrequency) => setFrequency(value)}>
          <SelectTrigger id="frequency" className="mt-1">
            <SelectValue placeholder="Select frequency" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="once">Once</SelectItem>
            <SelectItem value="hourly">Hourly</SelectItem>
            <SelectItem value="daily">Daily</SelectItem>
            <SelectItem value="weekly">Weekly</SelectItem>
            <SelectItem value="monthly">Monthly</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <div className="flex justify-between">
          <Label htmlFor="limit">Result Limit: {limit}</Label>
        </div>
        <Slider
          id="limit"
          min={10}
          max={1000}
          step={10}
          value={[limit]}
          onValueChange={(values) => setLimit(values[0])}
          className="mt-2"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>10</span>
          <span>500</span>
          <span>1000</span>
        </div>
      </div>
      
      <div>
        <Label>Data Export Format</Label>
        <div className="flex space-x-4 mt-1">
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="json" 
              name="format" 
              checked={exportFormat === "json"}
              onChange={() => setExportFormat("json")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="json" className="text-sm font-normal cursor-pointer">
              JSON
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="csv" 
              name="format" 
              checked={exportFormat === "csv"}
              onChange={() => setExportFormat("csv")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="csv" className="text-sm font-normal cursor-pointer">
              CSV
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <input 
              type="radio" 
              id="database" 
              name="format" 
              checked={exportFormat === "database"}
              onChange={() => setExportFormat("database")}
              className="text-primary focus:ring-primary"
            />
            <Label htmlFor="database" className="text-sm font-normal cursor-pointer">
              Database
            </Label>
          </div>
        </div>
      </div>
      
      {type === "twitter" && (
        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
          <div className="flex items-start">
            <i className="ri-information-line text-blue-500 mr-2 mt-0.5"></i>
            <div>
              <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300">API Key Required</h4>
              <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                Twitter/X scraping requires an API key. Please add one in the API Keys section if you haven't already.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
