import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScraperType } from "@/types";
import WebScraperForm from "@/components/forms/WebScraperForm";
import SocialScraperForm from "@/components/forms/SocialScraperForm";
import ApiConnectorForm from "@/components/forms/ApiConnectorForm";

interface ScraperModalProps {
  type: ScraperType;
  onClose: () => void;
}

export default function ScraperModal({ type, onClose }: ScraperModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState<any>({});
  const [isFormValid, setIsFormValid] = useState(false);
  
  const createScraperMutation = useMutation({
    mutationFn: (data: any) => 
      apiRequest("POST", "/api/tasks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Scraper created",
        description: "Your scraper has been created and started.",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create scraper: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    }
  });
  
  const getTitle = () => {
    switch (type) {
      case "web":
        return "Create Web Scraper";
      case "twitter":
        return "Create Twitter/X Scraper";
      case "linkedin":
        return "Create LinkedIn Scraper";
      case "instagram":
        return "Create Instagram Scraper";
      case "api":
        return "Create API Connector";
      default:
        return "Create Scraper";
    }
  };
  
  const handleFormChange = (data: any, valid: boolean) => {
    setFormData(data);
    setIsFormValid(valid);
  };
  
  const handleSubmit = () => {
    createScraperMutation.mutate({
      type,
      ...formData
    });
  };
  
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>{getTitle()}</DialogTitle>
        </DialogHeader>
        
        <div className="overflow-y-auto max-h-[calc(80vh-8rem)]">
          {type === "web" && (
            <WebScraperForm onChange={handleFormChange} />
          )}
          
          {(type === "twitter" || type === "instagram" || type === "linkedin") && (
            <SocialScraperForm type={type} onChange={handleFormChange} />
          )}
          
          {type === "api" && (
            <ApiConnectorForm onChange={handleFormChange} />
          )}
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-4 flex justify-end space-x-3">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={!isFormValid || createScraperMutation.isPending}
          >
            {createScraperMutation.isPending ? (
              <>
                <div className="animate-spin mr-2 h-4 w-4 border-2 border-b-transparent border-white rounded-full"></div>
                Creating...
              </>
            ) : "Create & Run"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
