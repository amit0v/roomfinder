import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScraperTask, ScrapedData } from "@/types";
import { useToast } from "@/hooks/use-toast";

interface DataPreviewModalProps {
  task: ScraperTask;
  data: ScrapedData | undefined;
  onClose: () => void;
}

export default function DataPreviewModal({ task, data, onClose }: DataPreviewModalProps) {
  const { toast } = useToast();
  
  const refreshDataMutation = useMutation({
    mutationFn: () => 
      apiRequest("POST", `/api/tasks/${task.id}/refresh`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/data", task.id] });
      toast({
        title: "Data refreshed",
        description: "The latest data has been fetched successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to refresh data: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    }
  });
  
  const exportDataMutation = useMutation({
    mutationFn: () => 
      apiRequest("GET", `/api/tasks/${task.id}/export`),
    onSuccess: async (response) => {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${task.name.replace(/\s+/g, '_').toLowerCase()}_data.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast({
        title: "Export successful",
        description: "Data has been exported successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to export data: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    }
  });
  
  const formatJSON = (data: any) => {
    if (!data) return "";
    try {
      return JSON.stringify(data, null, 2);
    } catch (e) {
      return "Error formatting JSON data";
    }
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };
  
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>Data Preview: {task.name}</DialogTitle>
        </DialogHeader>
        
        <div className="p-2 overflow-auto max-h-[calc(90vh-8rem)]">
          {!data ? (
            <div className="p-8 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-800 mb-4">
                <i className="ri-file-list-line text-2xl text-gray-400"></i>
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-1">No data available</h3>
              <p className="text-gray-500 dark:text-gray-400">This task hasn't collected any data yet</p>
            </div>
          ) : (
            <pre className="text-xs bg-gray-100 dark:bg-gray-900 p-4 rounded-lg overflow-auto max-h-[500px] code-font">
              <code className="language-json">
                {formatJSON(data.data).replace(/"([^"]+)":/g, '<span class="json-key">"$1":</span>')
                  .replace(/"([^"]+)"/g, '<span class="json-string">"$1"</span>')
                  .replace(/: (\d+\.?\d*)/g, ': <span class="json-value">$1</span>')
                  .replace(/: (true|false)/g, ': <span class="json-value">$1</span>')}
              </code>
            </pre>
          )}
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 px-6 py-4 flex justify-between">
          <div>
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {task.dataPoints.toLocaleString()} records • Last updated {data ? formatDate(data.createdAt) : "never"}
            </span>
          </div>
          <div className="flex space-x-3">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => refreshDataMutation.mutate()}
              disabled={refreshDataMutation.isPending}
            >
              {refreshDataMutation.isPending ? (
                <div className="animate-spin mr-1 h-4 w-4 border-2 border-b-transparent border-primary rounded-full"></div>
              ) : (
                <i className="ri-refresh-line mr-1"></i>
              )}
              Refresh
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              className="border-primary text-primary hover:bg-primary/10"
              onClick={() => exportDataMutation.mutate()}
              disabled={exportDataMutation.isPending || !data}
            >
              {exportDataMutation.isPending ? (
                <div className="animate-spin mr-1 h-4 w-4 border-2 border-b-transparent border-primary rounded-full"></div>
              ) : (
                <i className="ri-download-line mr-1"></i>
              )}
              Export
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
