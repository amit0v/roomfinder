import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import MainLayout from "@/components/layout/MainLayout";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  MapPinIcon,
  BedDoubleIcon,
  BathIcon,
  HomeIcon,
  CalendarIcon,
  WifiIcon,
  UtensilsIcon,
  CarIcon,
  DogIcon,
  CheckIcon,
  HeartIcon,
  Loader as LoaderIcon,
  MessageSquareIcon,
  ArrowLeftIcon,
  StarIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  User as SquareUser,
  Shirt as WashingMachine
} from "lucide-react";

export default function PropertyDetails() {
  const [, params] = useRoute('/property/:id');
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const propertyId = params ? parseInt(params.id) : null;
  
  // Image gallery state
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  
  // Check if user is logged in
  const { data: currentUser } = useQuery({
    queryKey: ['/api/user/profile'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/user/profile');
        if (!res.ok) return null;
        return res.json();
      } catch (error) {
        return null;
      }
    }
  });
  
  // Fetch property details
  const { 
    data: property, 
    isLoading: isLoadingProperty, 
    isError: propertyError 
  } = useQuery({
    queryKey: ['/api/properties', propertyId],
    queryFn: async () => {
      if (!propertyId) return null;
      const res = await fetch(`/api/properties/${propertyId}`);
      if (!res.ok) throw new Error('Failed to fetch property details');
      return res.json();
    },
    enabled: !!propertyId
  });
  
  // Fetch property reviews
  const { 
    data: reviewsData = { reviews: [], averageRating: 0 },
    isLoading: isLoadingReviews
  } = useQuery({
    queryKey: ['/api/properties', propertyId, 'reviews'],
    queryFn: async () => {
      if (!propertyId) return { reviews: [], averageRating: 0 };
      const res = await fetch(`/api/properties/${propertyId}/reviews`);
      if (!res.ok) throw new Error('Failed to fetch property reviews');
      return res.json();
    },
    enabled: !!propertyId
  });
  
  // Check if property is in favorites
  const { 
    data: isFavorite = false, 
    isLoading: isLoadingFavorite,
    refetch: refetchFavorite
  } = useQuery({
    queryKey: ['/api/favorites/check', propertyId],
    queryFn: async () => {
      if (!propertyId || !currentUser) return false;
      const res = await fetch(`/api/favorites/check/${propertyId}`);
      if (!res.ok) return false;
      const data = await res.json();
      return data.isFavorite;
    },
    enabled: !!propertyId && !!currentUser
  });
  
  // Toggle favorite mutation
  const toggleFavoriteMutation = useMutation({
    mutationFn: async () => {
      if (!propertyId) throw new Error('Property ID is required');
      
      if (isFavorite) {
        return apiRequest(`/favorites/${propertyId}`, {
          method: 'DELETE',
        });
      } else {
        return apiRequest('/favorites', {
          method: 'POST',
          body: JSON.stringify({ propertyId }),
        });
      }
    },
    onSuccess: () => {
      toast({
        title: isFavorite ? "Removed from favorites" : "Added to favorites",
        description: isFavorite 
          ? "The property has been removed from your favorites" 
          : "The property has been added to your favorites",
      });
      refetchFavorite();
      queryClient.invalidateQueries({ queryKey: ['/api/favorites'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update favorites",
        variant: "destructive",
      });
    }
  });
  
  // Start chat with owner mutation
  const startChatMutation = useMutation({
    mutationFn: async () => {
      if (!propertyId) throw new Error('Property ID is required');
      return apiRequest(`/chats/property/${propertyId}`, {
        method: 'POST',
      });
    },
    onSuccess: (data) => {
      navigate(`/chat/${data.chatRoomId}`);
    },
    onError: (error: any) => {
      if (error.status === 401) {
        toast({
          title: "Authentication required",
          description: "Please log in to message the owner",
          variant: "destructive",
        });
        navigate('/login');
        return;
      }
      
      toast({
        title: "Error",
        description: error.message || "Failed to start conversation",
        variant: "destructive",
      });
    }
  });
  
  // Navigate to previous/next image
  const navigateGallery = (direction: 'prev' | 'next') => {
    if (!property?.images || property.images.length === 0) return;
    
    if (direction === 'prev') {
      setActiveImageIndex(prev => 
        prev === 0 ? property.images.length - 1 : prev - 1
      );
    } else {
      setActiveImageIndex(prev => 
        prev === property.images.length - 1 ? 0 : prev + 1
      );
    }
  };
  
  // Format date helper function
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };
  
  // Calculate average rating and rating counts
  const totalReviews = reviewsData.reviews.length;
  const averageRating = reviewsData.averageRating;
  
  const ratingCounts = [5, 4, 3, 2, 1].map(rating => {
    const count = reviewsData.reviews.filter((review: any) => 
      Math.round(review.rating) === rating
    ).length;
    return {
      rating,
      count,
      percentage: totalReviews > 0 ? (count / totalReviews) * 100 : 0
    };
  });
  
  // Format amenities into categories
  const getAmenitiesCategories = () => {
    if (!property?.amenities) return [];
    
    const categories = [
      {
        name: "General",
        items: property.amenities.filter((a: any) => 
          ["furnished", "airConditioning", "heating"].includes(a.name)
        ),
      },
      {
        name: "Kitchen & Bath",
        items: property.amenities.filter((a: any) => 
          ["kitchen", "washingMachine", "dishwasher", "privateToilet", "privateBathroom"].includes(a.name)
        ),
      },
      {
        name: "Services",
        items: property.amenities.filter((a: any) => 
          ["wifi", "cableTv", "cleaning", "billsIncluded"].includes(a.name)
        ),
      },
      {
        name: "Other",
        items: property.amenities.filter((a: any) => 
          ["parking", "petsAllowed", "securitySystem", "elevator", "wheelchair"].includes(a.name)
        ),
      },
    ];
    
    // Filter out empty categories
    return categories.filter(category => category.items.length > 0);
  };
  
  // Icon mapping for amenities
  const getAmenityIcon = (name: string) => {
    switch (name) {
      case "wifi": return <WifiIcon className="h-4 w-4" />;
      case "furnished": return <HomeIcon className="h-4 w-4" />;
      case "parking": return <CarIcon className="h-4 w-4" />;
      case "petsAllowed": return <DogIcon className="h-4 w-4" />;
      case "kitchen": return <UtensilsIcon className="h-4 w-4" />;
      case "washingMachine": return <WashingMachine className="h-4 w-4" />;
      case "privateBathroom": return <BathIcon className="h-4 w-4" />;
      default: return <CheckIcon className="h-4 w-4" />;
    }
  };
  
  // Handle toggle favorite
  const handleToggleFavorite = (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    
    if (!currentUser) {
      toast({
        title: "Authentication required",
        description: "Please log in to save properties to favorites",
        variant: "destructive",
      });
      navigate('/login');
      return;
    }
    
    toggleFavoriteMutation.mutate();
  };
  
  // Handle start chat with owner
  const handleStartChat = () => {
    if (!currentUser) {
      toast({
        title: "Authentication required",
        description: "Please log in to message the owner",
        variant: "destructive",
      });
      navigate('/login');
      return;
    }
    
    if (property && currentUser.id === property.ownerId) {
      toast({
        title: "Error",
        description: "You cannot message yourself",
        variant: "destructive",
      });
      return;
    }
    
    startChatMutation.mutate();
  };
  
  // Convert string to title case
  const toTitleCase = (str: string) => {
    return str.replace(/([A-Z])/g, ' $1')
      .replace(/^./, (str) => str.toUpperCase());
  };
  
  if (propertyError) {
    return (
      <MainLayout>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-md mb-6">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg
                  className="h-5 w-5 text-red-500"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                    clipRule="evenodd"
                  />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">
                  This property could not be found or has been removed.
                </p>
              </div>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            onClick={() => navigate('/properties')}
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Back to Properties
          </Button>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back navigation */}
        <div className="mb-4">
          <Button 
            variant="ghost" 
            className="p-0 h-auto hover:bg-transparent hover:text-indigo-600"
            onClick={() => navigate('/properties')}
          >
            <ArrowLeftIcon className="h-4 w-4 mr-1" />
            <span>Back to properties</span>
          </Button>
        </div>
        
        {isLoadingProperty ? (
          <div className="space-y-6">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/3" />
            <Skeleton className="h-[400px] w-full rounded-lg" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <Skeleton className="h-8 w-40" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
              </div>
              <div>
                <Skeleton className="h-60 w-full rounded-lg" />
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Property Header */}
            <div className="mb-6">
              <h1 className="text-3xl font-bold mb-2">{property?.title}</h1>
              <div className="flex flex-wrap items-center gap-2 text-gray-600 mb-2">
                <div className="flex items-center">
                  <MapPinIcon className="h-4 w-4 mr-1" />
                  <span>{property?.address}, {property?.city}, {property?.state} {property?.zipCode}</span>
                </div>
                
                {averageRating > 0 && (
                  <div className="flex items-center ml-2">
                    <StarIcon className="h-4 w-4 text-yellow-500 mr-1" />
                    <span className="mr-1">{averageRating.toFixed(1)}</span>
                    <span className="text-gray-500">({totalReviews} {totalReviews === 1 ? 'review' : 'reviews'})</span>
                  </div>
                )}
              </div>
              
              <div className="flex flex-wrap gap-3 mt-3">
                <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 px-2 py-1">
                  <BedDoubleIcon className="h-3.5 w-3.5 mr-1" />
                  {property?.bedrooms} {property?.bedrooms === 1 ? 'Bedroom' : 'Bedrooms'}
                </Badge>
                <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 px-2 py-1">
                  <BathIcon className="h-3.5 w-3.5 mr-1" />
                  {property?.bathrooms} {property?.bathrooms === 1 ? 'Bathroom' : 'Bathrooms'}
                </Badge>
                <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 px-2 py-1">
                  <HomeIcon className="h-3.5 w-3.5 mr-1" />
                  {property?.propertyType}
                </Badge>
                {property?.availableFrom && (
                  <Badge className="bg-green-50 text-green-700 border-green-200 px-2 py-1">
                    <CalendarIcon className="h-3.5 w-3.5 mr-1" />
                    Available from {formatDate(property.availableFrom)}
                  </Badge>
                )}
              </div>
            </div>
            
            {/* Image Gallery */}
            <div className="mb-8">
              <div className="relative rounded-lg overflow-hidden h-[400px] md:h-[500px] bg-gray-100 mb-2">
                {property?.images && property.images.length > 0 ? (
                  <>
                    <img
                      src={property.images[activeImageIndex]?.imageUrl}
                      alt={`${property.title} - Image ${activeImageIndex + 1}`}
                      className="w-full h-full object-cover"
                    />
                    
                    {property.images.length > 1 && (
                      <>
                        <Button
                          variant="outline"
                          size="icon"
                          className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white rounded-full h-10 w-10"
                          onClick={() => navigateGallery('prev')}
                        >
                          <ChevronLeftIcon className="h-5 w-5" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white rounded-full h-10 w-10"
                          onClick={() => navigateGallery('next')}
                        >
                          <ChevronRightIcon className="h-5 w-5" />
                        </Button>
                        
                        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-1.5">
                          {property.images.map((image, i) => (
                            <button
                              key={i}
                              className={`w-2 h-2 rounded-full ${
                                i === activeImageIndex ? 'bg-white' : 'bg-white/50'
                              }`}
                              onClick={() => setActiveImageIndex(i)}
                              aria-label={`View image ${i + 1}`}
                            />
                          ))}
                        </div>
                      </>
                    )}
                  </>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <HomeIcon className="h-16 w-16 text-gray-300" />
                  </div>
                )}
              </div>
              
              {property?.images && property.images.length > 1 && (
                <div className="grid grid-cols-5 gap-2">
                  {property.images.slice(0, 5).map((image, i) => (
                    <img
                      key={i}
                      src={image.imageUrl}
                      alt={`${property.title} - Thumbnail ${i + 1}`}
                      className={`h-20 w-full object-cover rounded cursor-pointer ${
                        i === activeImageIndex ? 'ring-2 ring-indigo-500' : ''
                      }`}
                      onClick={() => setActiveImageIndex(i)}
                    />
                  ))}
                </div>
              )}
            </div>
            
            {/* Main content and sidebar layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main content */}
              <div className="lg:col-span-2">
                <Tabs defaultValue="details">
                  <TabsList className="w-full mb-6">
                    <TabsTrigger className="flex-1" value="details">Details</TabsTrigger>
                    <TabsTrigger className="flex-1" value="amenities">
                      Amenities
                    </TabsTrigger>
                    <TabsTrigger className="flex-1" value="reviews">
                      Reviews {totalReviews > 0 && `(${totalReviews})`}
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="details" className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Description</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="whitespace-pre-line text-gray-700">
                          {property?.description}
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Property Details</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-6">
                          <div className="flex justify-between">
                            <span className="text-gray-500">Property Type</span>
                            <span className="font-medium">{property?.propertyType}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Bedrooms</span>
                            <span className="font-medium">{property?.bedrooms}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Bathrooms</span>
                            <span className="font-medium">{property?.bathrooms}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Monthly Rent</span>
                            <span className="font-medium">${property?.monthlyRent}/month</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Deposit Required</span>
                            <span className="font-medium">${property?.securityDeposit}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Area</span>
                            <span className="font-medium">{property?.squareFeet} sq ft</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Available From</span>
                            <span className="font-medium">
                              {property?.availableFrom ? formatDate(property.availableFrom) : 'Immediately'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Available Until</span>
                            <span className="font-medium">
                              {property?.availableUntil ? formatDate(property.availableUntil) : 'Indefinitely'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Status</span>
                            <Badge className={property?.status === 'available' ? 'bg-green-50 text-green-700' : 'bg-orange-50 text-orange-700'}>
                              {property?.status === 'available' ? 'Available' : 'Pending'}
                            </Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Lease Term</span>
                            <span className="font-medium">{property?.leaseTerm || 'Flexible'}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="amenities">
                    <Card>
                      <CardHeader>
                        <CardTitle>Amenities</CardTitle>
                        <CardDescription>
                          Available features and facilities at this property
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {getAmenitiesCategories().length > 0 ? (
                          <div className="space-y-6">
                            {getAmenitiesCategories().map((category, idx) => (
                              <div key={idx}>
                                <h3 className="font-medium text-gray-900 mb-3">{category.name}</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-y-2">
                                  {category.items.map((amenity: any) => (
                                    <div key={amenity.id} className="flex items-center">
                                      <div className="text-indigo-600 mr-2">
                                        {getAmenityIcon(amenity.name)}
                                      </div>
                                      <span className="text-gray-700">
                                        {toTitleCase(amenity.name)}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                                {idx < getAmenitiesCategories().length - 1 && (
                                  <Separator className="my-4" />
                                )}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-gray-500">No amenities information available.</p>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="reviews">
                    <Card>
                      <CardHeader>
                        <CardTitle>Reviews</CardTitle>
                        <CardDescription>
                          {totalReviews > 0 
                            ? `What people are saying about this property` 
                            : `This property doesn't have any reviews yet`}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {isLoadingReviews ? (
                          <div className="space-y-4">
                            {[1, 2, 3].map(i => (
                              <div key={i} className="flex gap-4">
                                <Skeleton className="h-10 w-10 rounded-full" />
                                <div className="flex-1">
                                  <Skeleton className="h-4 w-32 mb-2" />
                                  <Skeleton className="h-4 w-full" />
                                  <Skeleton className="h-4 w-full mt-1" />
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : totalReviews > 0 ? (
                          <div className="space-y-6">
                            <div className="bg-gray-50 p-4 rounded-lg">
                              <div className="flex items-end gap-4">
                                <div>
                                  <div className="text-3xl font-bold text-gray-900">
                                    {averageRating.toFixed(1)}
                                  </div>
                                  <div className="flex mt-1">
                                    {[1, 2, 3, 4, 5].map(star => (
                                      <StarIcon
                                        key={star}
                                        className={`h-4 w-4 ${
                                          star <= Math.round(averageRating)
                                            ? 'text-yellow-500 fill-yellow-500'
                                            : 'text-gray-300'
                                        }`}
                                      />
                                    ))}
                                  </div>
                                  <div className="text-sm text-gray-500 mt-1">
                                    {totalReviews} {totalReviews === 1 ? 'review' : 'reviews'}
                                  </div>
                                </div>
                                
                                <div className="flex-1 space-y-2">
                                  {ratingCounts.map(({ rating, count, percentage }) => (
                                    <div key={rating} className="flex items-center gap-2">
                                      <div className="text-sm text-gray-600 w-6">{rating}</div>
                                      <Progress value={percentage} className="h-2 flex-1" />
                                      <div className="text-sm text-gray-600 w-8">{count}</div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                            
                            <Separator />
                            
                            {/* Reviews list */}
                            <div className="space-y-6">
                              {reviewsData.reviews.map((review: any) => (
                                <div key={review.id} className="pb-6 border-b border-gray-200 last:border-0 last:pb-0">
                                  <div className="flex items-start">
                                    <Avatar className="h-10 w-10 mr-4">
                                      <AvatarImage src={review.user?.profileImage} />
                                      <AvatarFallback>
                                        <SquareUser className="h-5 w-5" />
                                      </AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1">
                                      <div className="flex justify-between items-center mb-1">
                                        <h4 className="text-sm font-medium">
                                          {review.user?.fullName || review.user?.username || "Anonymous"}
                                        </h4>
                                        <div className="text-xs text-gray-500">
                                          {formatDate(review.createdAt)}
                                        </div>
                                      </div>
                                      <div className="flex mb-2">
                                        {[1, 2, 3, 4, 5].map(star => (
                                          <StarIcon
                                            key={star}
                                            className={`h-3.5 w-3.5 ${
                                              star <= Math.round(review.rating)
                                                ? 'text-yellow-500 fill-yellow-500'
                                                : 'text-gray-300'
                                            }`}
                                          />
                                        ))}
                                      </div>
                                      <p className="text-gray-700 text-sm">{review.comment}</p>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <div className="text-center py-6">
                            <div className="mx-auto h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center mb-3">
                              <StarIcon className="h-6 w-6 text-gray-400" />
                            </div>
                            <h3 className="text-gray-500 mb-2">No reviews yet</h3>
                            <p className="text-sm text-gray-400 mb-4">
                              Be the first to review this property
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
              
              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="sticky top-24">
                  <Card className="mb-4">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-2xl font-bold text-indigo-600">
                        ${property?.monthlyRent}<span className="text-gray-500 text-lg font-normal">/month</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                        <div className="text-gray-500">Security Deposit</div>
                        <div className="text-right font-medium">${property?.securityDeposit}</div>
                        <div className="text-gray-500">Available From</div>
                        <div className="text-right font-medium">
                          {property?.availableFrom ? formatDate(property.availableFrom) : 'Immediately'}
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div className="space-y-3">
                        <Button 
                          className="w-full gap-2"
                          onClick={handleStartChat}
                          disabled={startChatMutation.isPending || (currentUser?.id === property?.ownerId)}
                        >
                          {startChatMutation.isPending ? (
                            <LoaderIcon className="h-4 w-4 animate-spin" />
                          ) : (
                            <MessageSquareIcon className="h-4 w-4" />
                          )}
                          {currentUser?.id === property?.ownerId ? "Your Property" : "Message Owner"}
                        </Button>
                        
                        <Button 
                          variant="outline" 
                          className={`w-full gap-2 ${
                            isFavorite ? 'text-red-500 border-red-200 hover:bg-red-50' : ''
                          }`}
                          onClick={handleToggleFavorite}
                          disabled={toggleFavoriteMutation.isPending || isLoadingFavorite}
                        >
                          {isLoadingFavorite ? (
                            <LoaderIcon className="h-4 w-4 animate-spin" />
                          ) : toggleFavoriteMutation.isPending ? (
                            <LoaderIcon className="h-4 w-4 animate-spin" />
                          ) : (
                            <HeartIcon className={`h-4 w-4 ${isFavorite ? 'fill-red-500' : ''}`} />
                          )}
                          {isFavorite ? "Saved to Favorites" : "Save to Favorites"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Owner card */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Property Owner</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {property?.owner ? (
                        <div className="flex items-center gap-4">
                          <Avatar>
                            <AvatarImage src={property.owner.profileImage} />
                            <AvatarFallback className="bg-indigo-100 text-indigo-600">
                              {property.owner.fullName?.charAt(0) || property.owner.username?.charAt(0) || "O"}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-medium mb-1">
                              {property.owner.fullName || property.owner.username}
                              {property.owner.isVerified && (
                                <span className="inline-flex items-center ml-1 text-green-600 text-xs font-medium">
                                  <CheckIcon className="h-3 w-3 mr-0.5" />
                                  Verified
                                </span>
                              )}
                            </h4>
                            <p className="text-sm text-gray-500">
                              Member since {new Date(property.owner.createdAt).getFullYear()}
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-4">
                          <Skeleton className="h-10 w-10 rounded-full" />
                          <div>
                            <Skeleton className="h-4 w-24 mb-2" />
                            <Skeleton className="h-3 w-32" />
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </MainLayout>
  );
}