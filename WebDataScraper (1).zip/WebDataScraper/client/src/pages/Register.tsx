// This is a redirect page to Login.tsx since login and registration are handled in one page
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Register() {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Redirect to login page with register tab active
    navigate("/login");
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <p>Redirecting to login page...</p>
    </div>
  );
}