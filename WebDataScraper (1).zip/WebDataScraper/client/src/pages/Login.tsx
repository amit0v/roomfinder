import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircleIcon, Loader2Icon } from "lucide-react";

export default function Login() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Login form state
  const [loginForm, setLoginForm] = useState({
    username: "",
    password: "",
    rememberMe: false,
  });

  // Register form state
  const [registerForm, setRegisterForm] = useState({
    username: "",
    email: "",
    fullName: "",
    password: "",
    confirmPassword: "",
    userType: "student" as "student" | "owner",
    agreeTerms: false,
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: { username: string; password: string }) => {
      return apiRequest("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(credentials),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Login successful",
        description: `Welcome back, ${data.fullName || data.username}!`,
      });
      
      // Redirect to appropriate dashboard
      if (data.userType === "owner") {
        navigate("/owner/dashboard");
      } else {
        navigate("/");
      }
    },
    onError: (error: any) => {
      setErrorMessage(error.message || "Invalid username or password");
    },
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (userData: Omit<typeof registerForm, "confirmPassword" | "agreeTerms">) => {
      return apiRequest("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(userData),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Registration successful",
        description: "Your account has been created successfully. You can now login.",
      });
      
      // Switch to login tab
      setActiveTab("login");
      
      // Pre-fill login form with the registered username
      setLoginForm(prev => ({
        ...prev,
        username: registerForm.username
      }));
    },
    onError: (error: any) => {
      setErrorMessage(error.message || "Registration failed. Please try again.");
    },
  });

  // Handle login form changes
  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setLoginForm(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  // Handle register form changes
  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setRegisterForm(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  // Handle login form submission
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    
    // Basic validation
    if (!loginForm.username || !loginForm.password) {
      setErrorMessage("Please enter both username and password");
      return;
    }
    
    loginMutation.mutate({
      username: loginForm.username,
      password: loginForm.password
    });
  };

  // Handle register form submission
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    
    // Basic validation
    if (!registerForm.username || !registerForm.email || !registerForm.password || !registerForm.fullName) {
      setErrorMessage("Please fill in all required fields");
      return;
    }
    
    if (registerForm.password !== registerForm.confirmPassword) {
      setErrorMessage("Passwords do not match");
      return;
    }
    
    if (!registerForm.agreeTerms) {
      setErrorMessage("You must agree to the terms and conditions");
      return;
    }
    
    // Create user object from form data (excluding confirm password and agreement)
    const userData = {
      username: registerForm.username,
      email: registerForm.email,
      fullName: registerForm.fullName,
      password: registerForm.password,
      userType: registerForm.userType
    };
    
    registerMutation.mutate(userData);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 py-12">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-indigo-600">RoomFinder</h1>
          <p className="mt-2 text-gray-600">Find your perfect student home</p>
        </div>
        
        <Card>
          <CardHeader>
            <Tabs 
              defaultValue="login" 
              value={activeTab} 
              onValueChange={(value) => {
                setActiveTab(value as "login" | "register");
                setErrorMessage(null);
              }}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
              
              {/* Login Tab */}
              <TabsContent value="login">
                <CardTitle>Welcome back</CardTitle>
                <CardDescription>
                  Enter your credentials to access your account
                </CardDescription>
              </TabsContent>
              
              {/* Register Tab */}
              <TabsContent value="register">
                <CardTitle>Create an account</CardTitle>
                <CardDescription>
                  Sign up to start finding or listing rental properties
                </CardDescription>
              </TabsContent>
            </Tabs>
          </CardHeader>
          
          <CardContent>
            {errorMessage && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircleIcon className="h-4 w-4" />
                <AlertDescription>
                  {errorMessage}
                </AlertDescription>
              </Alert>
            )}
            
            {/* Login Form */}
            {activeTab === "login" && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username">Username</Label>
                  <Input
                    id="login-username"
                    name="username"
                    type="text"
                    value={loginForm.username}
                    onChange={handleLoginChange}
                    placeholder="Enter your username"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="login-password">Password</Label>
                    <Button
                      variant="link"
                      className="p-0 h-auto font-normal text-sm"
                      type="button"
                    >
                      Forgot password?
                    </Button>
                  </div>
                  <Input
                    id="login-password"
                    name="password"
                    type="password"
                    value={loginForm.password}
                    onChange={handleLoginChange}
                    placeholder="Enter your password"
                    required
                  />
                </div>
                
                <div className="flex items-center space-x-2 mt-2">
                  <Checkbox
                    id="remember-me"
                    name="rememberMe"
                    checked={loginForm.rememberMe}
                    onCheckedChange={(checked) => 
                      setLoginForm(prev => ({ ...prev, rememberMe: checked === true }))
                    }
                  />
                  <Label htmlFor="remember-me" className="text-sm">Remember me</Label>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? (
                    <>
                      <Loader2Icon className="h-4 w-4 mr-2 animate-spin" />
                      Logging in...
                    </>
                  ) : (
                    "Sign in"
                  )}
                </Button>
              </form>
            )}
            
            {/* Register Form */}
            {activeTab === "register" && (
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="register-fullName">Full Name</Label>
                  <Input
                    id="register-fullName"
                    name="fullName"
                    type="text"
                    value={registerForm.fullName}
                    onChange={handleRegisterChange}
                    placeholder="Enter your full name"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="register-username">Username</Label>
                    <Input
                      id="register-username"
                      name="username"
                      type="text"
                      value={registerForm.username}
                      onChange={handleRegisterChange}
                      placeholder="Choose a username"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="register-email">Email</Label>
                    <Input
                      id="register-email"
                      name="email"
                      type="email"
                      value={registerForm.email}
                      onChange={handleRegisterChange}
                      placeholder="Enter your email"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="register-password">Password</Label>
                    <Input
                      id="register-password"
                      name="password"
                      type="password"
                      value={registerForm.password}
                      onChange={handleRegisterChange}
                      placeholder="Create a password"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="register-confirmPassword">Confirm Password</Label>
                    <Input
                      id="register-confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={registerForm.confirmPassword}
                      onChange={handleRegisterChange}
                      placeholder="Confirm your password"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>I am a:</Label>
                  <div className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="userType-student" 
                        name="userType" 
                        value="student"
                        checked={registerForm.userType === "student"}
                        onChange={handleRegisterChange}
                        className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                      />
                      <Label htmlFor="userType-student">Student</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input 
                        type="radio" 
                        id="userType-owner" 
                        name="userType" 
                        value="owner" 
                        checked={registerForm.userType === "owner"}
                        onChange={handleRegisterChange}
                        className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                      />
                      <Label htmlFor="userType-owner">Property Owner</Label>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 mt-2">
                  <Checkbox
                    id="agree-terms"
                    name="agreeTerms"
                    checked={registerForm.agreeTerms}
                    onCheckedChange={(checked) => 
                      setRegisterForm(prev => ({ ...prev, agreeTerms: checked === true }))
                    }
                    required
                  />
                  <Label htmlFor="agree-terms" className="text-sm">
                    I agree to the <a href="#" className="text-indigo-600 hover:underline">Terms of Service</a> and <a href="#" className="text-indigo-600 hover:underline">Privacy Policy</a>
                  </Label>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={registerMutation.isPending}
                >
                  {registerMutation.isPending ? (
                    <>
                      <Loader2Icon className="h-4 w-4 mr-2 animate-spin" />
                      Creating account...
                    </>
                  ) : (
                    "Create Account"
                  )}
                </Button>
              </form>
            )}
          </CardContent>
          
          <CardFooter>
            <div className="text-center w-full">
              <Button
                variant="link"
                className="p-0 h-auto font-normal text-sm"
                onClick={() => navigate("/")}
              >
                Return to home page
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}