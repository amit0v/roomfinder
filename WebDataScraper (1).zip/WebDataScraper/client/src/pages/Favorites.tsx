import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/MainLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  MapPinIcon, 
  BedDoubleIcon, 
  BathIcon,
  HeartIcon,
  Loader2Icon,
  HomeIcon,
  SearchIcon
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface Property {
  id: number;
  title: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  monthlyRent: number;
  bedrooms: number;
  bathrooms: string;
  propertyType: string;
  status: string;
  images?: { imageUrl: string }[];
}

export default function Favorites() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch favorite properties
  const { 
    data: favorites = [], 
    isLoading, 
    isError, 
    refetch 
  } = useQuery({
    queryKey: ['/api/favorites'],
    queryFn: async () => {
      const res = await fetch('/api/favorites');
      if (!res.ok) {
        if (res.status === 401) {
          navigate('/login');
          throw new Error('Please log in to view your favorite properties');
        }
        throw new Error('Failed to fetch favorites');
      }
      return res.json();
    }
  });

  // Remove from favorites mutation
  const removeFavoriteMutation = useMutation({
    mutationFn: async (propertyId: number) => {
      return apiRequest(`/favorites/${propertyId}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Property removed from favorites",
      });
      refetch();
      queryClient.invalidateQueries({ queryKey: ['/api/properties'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove from favorites",
        variant: "destructive",
      });
    }
  });

  // Handle remove from favorites
  const handleRemoveFavorite = (e: React.MouseEvent, propertyId: number) => {
    e.stopPropagation();
    removeFavoriteMutation.mutate(propertyId);
  };

  // Handle property card click
  const handlePropertyClick = (propertyId: number) => {
    navigate(`/property/${propertyId}`);
  };

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">My Favorite Properties</h1>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <div className="flex justify-between">
                    <Skeleton className="h-5 w-1/4" />
                    <Skeleton className="h-5 w-1/4" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : isError ? (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-md">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg
                  className="h-5 w-5 text-red-500"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                    clipRule="evenodd"
                  />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">
                  Error loading favorites. Please try again later.
                </p>
              </div>
            </div>
          </div>
        ) : favorites.length === 0 ? (
          <div className="text-center py-16 border rounded-lg">
            <div className="mx-auto h-16 w-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
              <HeartIcon className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="mt-2 text-lg font-medium text-gray-900">
              No favorite properties yet
            </h3>
            <p className="mt-1 text-sm text-gray-500 max-w-md mx-auto mb-6">
              Browse properties and click the heart icon to add them to your favorites.
            </p>
            <Button
              onClick={() => navigate("/properties")}
              variant="default"
              className="inline-flex items-center"
            >
              <SearchIcon className="h-4 w-4 mr-2" />
              Browse Properties
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map((item: any) => {
              const property: Property = item.property;
              
              return (
                <Card
                  key={property.id}
                  className="overflow-hidden cursor-pointer group"
                  onClick={() => handlePropertyClick(property.id)}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={property.images?.[0]?.imageUrl || "https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&w=2340&q=80"}
                      alt={property.title}
                      className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <div className="absolute top-0 right-0 p-2">
                      <Button
                        variant="secondary"
                        size="icon"
                        className="rounded-full bg-white/80 hover:bg-white shadow-sm h-8 w-8"
                        onClick={(e) => handleRemoveFavorite(e, property.id)}
                        disabled={removeFavoriteMutation.isPending}
                      >
                        {removeFavoriteMutation.isPending && removeFavoriteMutation.variables === property.id ? (
                          <Loader2Icon className="h-4 w-4 animate-spin text-red-500" />
                        ) : (
                          <HeartIcon className="h-4 w-4 fill-red-500 text-red-500" />
                        )}
                      </Button>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                      <p className="text-white font-bold">${property.monthlyRent}/month</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-lg mb-1 line-clamp-1">{property.title}</h3>
                    <div className="flex items-center text-gray-500 text-sm mb-2">
                      <MapPinIcon className="h-4 w-4 mr-1" />
                      <span className="truncate">{property.address}, {property.city}</span>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <div className="flex items-center text-sm text-gray-600">
                        <BedDoubleIcon className="h-4 w-4 mr-1" />
                        <span>{property.bedrooms} {property.bedrooms === 1 ? "Bed" : "Beds"}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <BathIcon className="h-4 w-4 mr-1" />
                        <span>{property.bathrooms} {property.bathrooms === "1" ? "Bath" : "Baths"}</span>
                      </div>
                      <Badge variant="outline" className="text-xs bg-gray-50">
                        {property.propertyType}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
}