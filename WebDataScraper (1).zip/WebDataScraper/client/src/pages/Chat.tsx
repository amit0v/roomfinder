import { useState, useEffect, useRef } from "react";
import { useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/MainLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  SendIcon,
  LoaderIcon,
  MessageSquareIcon,
  HomeIcon,
  CheckCircleIcon,
  PlusCircleIcon,
  UserIcon,
  AlertCircleIcon,
  ChevronLeftIcon,
} from "lucide-react";
import { useWebSocket } from "@/lib/websocket";

interface ChatMessage {
  id: number;
  chatRoomId: number;
  senderId: number;
  message: string;
  createdAt: string;
  isRead: boolean;
  sender?: {
    id: number;
    username: string;
    fullName: string;
    profileImage: string | null;
  };
}

interface ChatRoom {
  id: number;
  propertyId: number;
  ownerId: number;
  studentId: number;
  lastMessageAt: string;
  createdAt: string;
  owner?: {
    id: number;
    username: string;
    fullName: string;
    profileImage: string | null;
  };
  student?: {
    id: number;
    username: string;
    fullName: string;
    profileImage: string | null;
  };
  property?: {
    id: number;
    title: string;
    address: string;
    city: string;
    images?: { imageUrl: string }[];
  };
  messages?: ChatMessage[];
}

export default function Chat() {
  const [, params] = useRoute("/chat/:id");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const [messageText, setMessageText] = useState("");
  const [currentUser, setCurrentUser] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const selectedChatId = params?.id ? parseInt(params.id) : null;
  
  // Fetch current user
  const { data: userData } = useQuery({
    queryKey: ['/api/user/profile'],
    queryFn: async () => {
      const res = await fetch('/api/user/profile');
      if (!res.ok) throw new Error('Failed to fetch user profile');
      return res.json();
    }
  });
  
  // Set current user when data is loaded
  useEffect(() => {
    if (userData) {
      setCurrentUser(userData);
    }
  }, [userData]);
  
  // Fetch chat rooms
  const { 
    data: chatRooms = [], 
    isLoading: isLoadingChatRooms 
  } = useQuery({
    queryKey: ['/api/chats'],
    queryFn: async () => {
      const res = await fetch('/api/chats');
      if (!res.ok) throw new Error('Failed to fetch chat rooms');
      return res.json();
    }
  });
  
  // Fetch messages for selected chat
  const { 
    data: messages = [], 
    isLoading: isLoadingMessages,
    refetch: refetchMessages
  } = useQuery({
    queryKey: ['/api/chats', selectedChatId, 'messages'],
    queryFn: async () => {
      if (!selectedChatId) return [];
      const res = await fetch(`/api/chats/${selectedChatId}/messages`);
      if (!res.ok) throw new Error('Failed to fetch messages');
      return res.json();
    },
    enabled: !!selectedChatId
  });
  
  // Get selected chat room
  const selectedChat = selectedChatId 
    ? chatRooms.find((room: ChatRoom) => room.id === selectedChatId) 
    : null;
  
  // Handle WebSocket messages
  useWebSocket<ChatMessage>(
    (data) => {
      if (data.chatRoomId === selectedChatId) {
        refetchMessages();
      }
      // Refetch chat rooms to update last message
      queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
    },
    (error) => {
      console.error('WebSocket error:', error);
    }
  );
  
  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { message: string }) => {
      if (!selectedChatId) throw new Error('No chat selected');
      return apiRequest(`/chats/${selectedChatId}/messages`, {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      setMessageText("");
      refetchMessages();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message",
        variant: "destructive",
      });
    }
  });
  
  // Handle send message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    
    sendMessageMutation.mutate({ message: messageText });
  };
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Format date to readable time
  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  // Format date to readable date
  const formatMessageDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return "Today";
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return date.toLocaleDateString([], { 
        month: 'short', 
        day: 'numeric', 
        year: date.getFullYear() !== today.getFullYear() ? 'numeric' : undefined 
      });
    }
  };
  
  // Group messages by date
  const groupMessagesByDate = (messages: ChatMessage[]) => {
    const groups: { [key: string]: ChatMessage[] } = {};
    
    messages.forEach(message => {
      const date = new Date(message.createdAt).toDateString();
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(message);
    });
    
    return Object.entries(groups).map(([date, msgs]) => ({
      date,
      formattedDate: formatMessageDate(msgs[0].createdAt),
      messages: msgs
    }));
  };
  
  const groupedMessages = groupMessagesByDate(messages as ChatMessage[]);
  
  // Get the other person in the chat
  const getOtherUser = (chat: ChatRoom) => {
    if (!currentUser) return null;
    return currentUser.userType === 'owner' ? chat.student : chat.owner;
  };
  
  return (
    <MainLayout>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row h-[calc(100vh-240px)] lg:h-[600px] gap-6">
          {/* Chat List */}
          <div className="lg:w-1/3 h-full flex flex-col border rounded-lg overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <h2 className="font-semibold text-lg">Messages</h2>
            </div>
            
            {isLoadingChatRooms ? (
              <div className="flex-1 overflow-y-auto p-2 space-y-2">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="flex items-start space-x-3 p-3 rounded-lg border">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1">
                      <Skeleton className="h-4 w-24 mb-2" />
                      <Skeleton className="h-3 w-full" />
                    </div>
                  </div>
                ))}
              </div>
            ) : chatRooms.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-4 text-center">
                <MessageSquareIcon className="h-12 w-12 text-gray-300 mb-2" />
                <h3 className="font-medium text-gray-900">No messages yet</h3>
                <p className="text-sm text-gray-500 mt-1 mb-4">
                  Start a conversation with a property owner or browse properties to inquire about them.
                </p>
                <Button
                  onClick={() => navigate('/properties')}
                  variant="outline"
                >
                  <HomeIcon className="h-4 w-4 mr-2" />
                  Browse Properties
                </Button>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto">
                {chatRooms.map((chatRoom: ChatRoom) => {
                  const otherUser = getOtherUser(chatRoom);
                  const lastMessage = chatRoom.messages?.[0];
                  const hasUnread = chatRoom.messages?.some(
                    (msg: ChatMessage) => !msg.isRead && msg.senderId !== currentUser?.id
                  );
                  
                  return (
                    <div
                      key={chatRoom.id}
                      className={`border-b p-3 hover:bg-gray-50 cursor-pointer ${
                        selectedChatId === chatRoom.id ? "bg-gray-50" : ""
                      }`}
                      onClick={() => navigate(`/chat/${chatRoom.id}`)}
                    >
                      <div className="flex items-start space-x-3">
                        <Avatar>
                          <AvatarImage src={otherUser?.profileImage || undefined} />
                          <AvatarFallback className="bg-indigo-100 text-indigo-600">
                            {otherUser?.fullName?.charAt(0) || otherUser?.username?.charAt(0) || "U"}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start">
                            <p className="font-medium truncate">
                              {otherUser?.fullName || otherUser?.username || "User"}
                            </p>
                            {lastMessage && (
                              <span className="text-xs text-gray-500">
                                {formatMessageTime(lastMessage.createdAt)}
                              </span>
                            )}
                          </div>
                          
                          <p className="text-sm text-gray-500 truncate">
                            {chatRoom.property?.title || "Unknown Property"}
                          </p>
                          
                          <div className="mt-1 flex items-center justify-between">
                            <p className="text-sm truncate max-w-[180px] text-gray-600">
                              {lastMessage?.message || "No messages yet"}
                            </p>
                            
                            {hasUnread && (
                              <Badge className="ml-1" variant="default">
                                New
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          
          {/* Chat Messages */}
          <div className="lg:w-2/3 h-full flex flex-col border rounded-lg overflow-hidden">
            {selectedChat ? (
              <>
                {/* Chat Header */}
                <div className="p-4 bg-gray-50 border-b flex justify-between items-center">
                  <div className="flex items-center">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="lg:hidden mr-2" 
                      onClick={() => navigate('/chat')}
                    >
                      <ChevronLeftIcon className="h-5 w-5" />
                    </Button>
                    
                    <Avatar className="h-8 w-8 mr-2">
                      <AvatarImage src={getOtherUser(selectedChat)?.profileImage || undefined} />
                      <AvatarFallback className="bg-indigo-100 text-indigo-600">
                        {getOtherUser(selectedChat)?.fullName?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div>
                      <h3 className="font-medium text-sm">
                        {getOtherUser(selectedChat)?.fullName || getOtherUser(selectedChat)?.username || "User"}
                      </h3>
                      <p className="text-xs text-gray-500">
                        {selectedChat.property?.title || "Discussion about property"}
                      </p>
                    </div>
                  </div>
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate(`/property/${selectedChat.propertyId}`)}
                  >
                    <HomeIcon className="h-4 w-4 mr-2" />
                    <span className="hidden sm:inline">View Property</span>
                  </Button>
                </div>
                
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-6">
                  {isLoadingMessages ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className={`flex ${i % 2 === 0 ? 'justify-end' : ''}`}>
                          <div className={`max-w-[80%] ${i % 2 === 0 ? 'bg-indigo-50' : 'bg-gray-100'} rounded-lg p-2`}>
                            <Skeleton className="h-4 w-32 mb-1" />
                            <Skeleton className="h-10 w-48" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-4">
                      <MessageSquareIcon className="h-12 w-12 text-gray-300 mb-2" />
                      <h3 className="font-medium text-gray-900">No messages yet</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        Send a message to start the conversation about this property.
                      </p>
                    </div>
                  ) : (
                    groupedMessages.map((group, groupIndex) => (
                      <div key={groupIndex} className="space-y-4">
                        <div className="relative flex items-center justify-center">
                          <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-gray-200"></div>
                          </div>
                          <div className="relative bg-white px-4">
                            <span className="text-sm text-gray-500">{group.formattedDate}</span>
                          </div>
                        </div>
                        
                        {group.messages.map((message: ChatMessage) => {
                          const isCurrentUser = message.senderId === currentUser?.id;
                          
                          return (
                            <div 
                              key={message.id} 
                              className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
                            >
                              {!isCurrentUser && (
                                <Avatar className="h-8 w-8 mr-2 mt-1">
                                  <AvatarImage 
                                    src={getOtherUser(selectedChat)?.profileImage || undefined} 
                                  />
                                  <AvatarFallback className="bg-indigo-100 text-indigo-600">
                                    {getOtherUser(selectedChat)?.fullName?.charAt(0) || "U"}
                                  </AvatarFallback>
                                </Avatar>
                              )}
                              
                              <div 
                                className={`max-w-[75%] p-3 rounded-lg ${
                                  isCurrentUser 
                                    ? 'bg-indigo-500 text-white' 
                                    : 'bg-gray-100 text-gray-800'
                                }`}
                              >
                                <p>{message.message}</p>
                                <div 
                                  className={`text-xs mt-1 flex justify-end items-center ${
                                    isCurrentUser ? 'text-indigo-100' : 'text-gray-500'
                                  }`}
                                >
                                  {formatMessageTime(message.createdAt)}
                                  {isCurrentUser && message.isRead && (
                                    <CheckCircleIcon className="h-3 w-3 ml-1" />
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </div>
                
                {/* Message Input */}
                <div className="p-3 border-t">
                  <form onSubmit={handleSendMessage} className="flex space-x-2">
                    <Input
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder="Type your message..."
                      className="flex-1"
                    />
                    <Button 
                      type="submit" 
                      disabled={!messageText.trim() || sendMessageMutation.isPending}
                    >
                      {sendMessageMutation.isPending ? (
                        <LoaderIcon className="h-4 w-4 animate-spin" />
                      ) : (
                        <SendIcon className="h-4 w-4" />
                      )}
                      <span className="ml-2 hidden sm:inline">Send</span>
                    </Button>
                  </form>
                </div>
              </>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-6 text-center">
                <div className="h-16 w-16 rounded-full bg-indigo-50 flex items-center justify-center mb-4">
                  <MessageSquareIcon className="h-8 w-8 text-indigo-500" />
                </div>
                <h2 className="text-xl font-semibold mb-2">Your Messages</h2>
                <p className="text-gray-500 mb-6 max-w-md">
                  {chatRooms.length > 0 
                    ? "Select a conversation from the list to view messages" 
                    : "Start a conversation with a property owner by browsing properties"}
                </p>
                {chatRooms.length === 0 && (
                  <Button
                    onClick={() => navigate("/properties")}
                  >
                    <HomeIcon className="h-4 w-4 mr-2" />
                    Browse Properties
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}