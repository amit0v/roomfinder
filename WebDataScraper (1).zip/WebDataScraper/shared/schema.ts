import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// User schema for validation
export const insertUserSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  email: (schema) => schema.email("Must provide a valid email"),
}).pick({
  username: true,
  password: true,
  email: true,
});

// Verification documents table for property owners
export const verificationDocuments = pgTable("verification_documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  documentType: text("document_type").notNull(), // "id", "utility_bill", "deed", etc.
  documentUrl: text("document_url").notNull(),
  isVerified: boolean("is_verified").default(false),
  verifiedAt: timestamp("verified_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Verification documents schema for validation
export const insertVerificationDocumentSchema = createInsertSchema(verificationDocuments, {
  documentType: (schema) => schema.min(2, "Document type must be specified"),
  documentUrl: (schema) => schema.min(5, "Document URL must be valid"),
}).pick({
  userId: true,
  documentType: true,
  documentUrl: true,
});

// Properties table
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zipCode: text("zip_code").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 6 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 6 }).notNull(),
  propertyType: text("property_type").notNull(), // "apartment", "house", "room", "studio"
  monthlyRent: integer("monthly_rent").notNull(),
  securityDeposit: integer("security_deposit"),
  bedrooms: integer("bedrooms").notNull(),
  bathrooms: decimal("bathrooms", { precision: 3, scale: 1 }).notNull(),
  squareFeet: integer("square_feet"),
  isFurnished: boolean("is_furnished").default(false),
  hasParking: boolean("has_parking").default(false),
  petsAllowed: boolean("pets_allowed").default(false),
  availableFrom: timestamp("available_from").notNull(),
  availableUntil: timestamp("available_until"),
  status: text("status").notNull().default("available"), // "available", "rented", "pending", "inactive"
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Property schema for validation
export const insertPropertySchema = createInsertSchema(properties, {
  title: (schema) => schema.min(5, "Title must be at least 5 characters"),
  description: (schema) => schema.min(20, "Description must be at least 20 characters"),
  address: (schema) => schema.min(5, "Address must be at least 5 characters"),
}).pick({
  ownerId: true,
  title: true,
  description: true,
  address: true,
  city: true,
  state: true,
  zipCode: true,
  latitude: true,
  longitude: true,
  propertyType: true,
  monthlyRent: true,
  securityDeposit: true,
  bedrooms: true,
  bathrooms: true,
  squareFeet: true,
  isFurnished: true,
  hasParking: true,
  petsAllowed: true,
  availableFrom: true,
  availableUntil: true,
  status: true,
});

// Property images table
export const propertyImages = pgTable("property_images", {
  id: serial("id").primaryKey(),
  propertyId: integer("property_id").references(() => properties.id).notNull(),
  imageUrl: text("image_url").notNull(),
  isFeatured: boolean("is_featured").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Property images schema for validation
export const insertPropertyImageSchema = createInsertSchema(propertyImages, {
  imageUrl: (schema) => schema.min(5, "Image URL must be valid"),
}).pick({
  propertyId: true,
  imageUrl: true,
  isFeatured: true,
});

// Property amenities table
export const propertyAmenities = pgTable("property_amenities", {
  id: serial("id").primaryKey(),
  propertyId: integer("property_id").references(() => properties.id).notNull(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Property amenities schema for validation
export const insertPropertyAmenitySchema = createInsertSchema(propertyAmenities, {
  name: (schema) => schema.min(2, "Amenity name must be at least 2 characters"),
}).pick({
  propertyId: true,
  name: true,
});

// Chat rooms table
export const chatRooms = pgTable("chat_rooms", {
  id: serial("id").primaryKey(),
  propertyId: integer("property_id").references(() => properties.id).notNull(),
  studentId: integer("student_id").references(() => users.id).notNull(),
  ownerId: integer("owner_id").references(() => users.id).notNull(),
  lastMessageAt: timestamp("last_message_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Chat rooms schema for validation
export const insertChatRoomSchema = createInsertSchema(chatRooms).pick({
  propertyId: true,
  studentId: true,
  ownerId: true,
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  chatRoomId: integer("chat_room_id").references(() => chatRooms.id).notNull(),
  senderId: integer("sender_id").references(() => users.id).notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Chat messages schema for validation
export const insertChatMessageSchema = createInsertSchema(chatMessages, {
  message: (schema) => schema.min(1, "Message cannot be empty"),
}).pick({
  chatRoomId: true,
  senderId: true,
  message: true,
});

// Favorites table
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  propertyId: integer("property_id").references(() => properties.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Favorites schema for validation
export const insertFavoriteSchema = createInsertSchema(favorites).pick({
  userId: true,
  propertyId: true,
});

// Settings table
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull().unique(),
  notificationsEnabled: boolean("notifications_enabled").default(true),
  emailAlerts: boolean("email_alerts").default(true),
  darkMode: boolean("dark_mode").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Settings schema for validation
export const insertSettingsSchema = createInsertSchema(settings).pick({
  userId: true,
  notificationsEnabled: true,
  emailAlerts: true,
  darkMode: true,
});

// Property reviews table
export const propertyReviews = pgTable("property_reviews", {
  id: serial("id").primaryKey(),
  propertyId: integer("property_id").references(() => properties.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  rating: integer("rating").notNull(),
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Property reviews schema for validation
export const insertPropertyReviewSchema = createInsertSchema(propertyReviews, {
  rating: (schema) => schema.min(1, "Rating must be at least 1").max(5, "Rating cannot exceed 5"),
}).pick({
  propertyId: true,
  userId: true,
  rating: true,
  comment: true,
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  properties: many(properties, { relationName: "owner" }),
  verificationDocuments: many(verificationDocuments),
  favorites: many(favorites),
  settings: many(settings),
  sentMessages: many(chatMessages, { relationName: "sender" }),
  studentChatRooms: many(chatRooms, { relationName: "student" }),
  ownerChatRooms: many(chatRooms, { relationName: "owner" }),
  propertyReviews: many(propertyReviews),
}));

export const verificationDocumentsRelations = relations(verificationDocuments, ({ one }) => ({
  user: one(users, { fields: [verificationDocuments.userId], references: [users.id] }),
}));

export const propertiesRelations = relations(properties, ({ one, many }) => ({
  owner: one(users, { fields: [properties.ownerId], references: [users.id] }),
  images: many(propertyImages),
  amenities: many(propertyAmenities),
  chatRooms: many(chatRooms),
  favorites: many(favorites),
  reviews: many(propertyReviews),
}));

export const propertyImagesRelations = relations(propertyImages, ({ one }) => ({
  property: one(properties, { fields: [propertyImages.propertyId], references: [properties.id] }),
}));

export const propertyAmenitiesRelations = relations(propertyAmenities, ({ one }) => ({
  property: one(properties, { fields: [propertyAmenities.propertyId], references: [properties.id] }),
}));

export const chatRoomsRelations = relations(chatRooms, ({ one, many }) => ({
  property: one(properties, { fields: [chatRooms.propertyId], references: [properties.id] }),
  student: one(users, { fields: [chatRooms.studentId], references: [users.id], relationName: "student" }),
  owner: one(users, { fields: [chatRooms.ownerId], references: [users.id], relationName: "owner" }),
  messages: many(chatMessages),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  chatRoom: one(chatRooms, { fields: [chatMessages.chatRoomId], references: [chatRooms.id] }),
  sender: one(users, { fields: [chatMessages.senderId], references: [users.id], relationName: "sender" }),
}));

export const favoritesRelations = relations(favorites, ({ one }) => ({
  user: one(users, { fields: [favorites.userId], references: [users.id] }),
  property: one(properties, { fields: [favorites.propertyId], references: [properties.id] }),
}));

export const settingsRelations = relations(settings, ({ one }) => ({
  user: one(users, { fields: [settings.userId], references: [users.id] }),
}));

export const propertyReviewsRelations = relations(propertyReviews, ({ one }) => ({
  property: one(properties, { fields: [propertyReviews.propertyId], references: [properties.id] }),
  user: one(users, { fields: [propertyReviews.userId], references: [users.id] }),
}));

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export type VerificationDocument = typeof verificationDocuments.$inferSelect;
export type InsertVerificationDocument = typeof verificationDocuments.$inferInsert;

export type Property = typeof properties.$inferSelect;
export type InsertProperty = typeof properties.$inferInsert;

export type PropertyImage = typeof propertyImages.$inferSelect;
export type InsertPropertyImage = typeof propertyImages.$inferInsert;

export type PropertyAmenity = typeof propertyAmenities.$inferSelect;
export type InsertPropertyAmenity = typeof propertyAmenities.$inferInsert;

export type ChatRoom = typeof chatRooms.$inferSelect;
export type InsertChatRoom = typeof chatRooms.$inferInsert;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = typeof favorites.$inferInsert;

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = typeof settings.$inferInsert;

export type PropertyReview = typeof propertyReviews.$inferSelect;
export type InsertPropertyReview = typeof propertyReviews.$inferInsert;
